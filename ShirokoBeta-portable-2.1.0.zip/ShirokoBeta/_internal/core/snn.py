# -*- coding: utf-8 -*-
"""
Shiroko β —— 脉冲神经网络（SNN）

规模（与项目书、前端 `BASE_NEURONS`/`BASE_SYNAPSES` **必须一致**）
----------------------------------------------------------------
    脑区            神经元   输入维
    reflex           256       4
    thalamus         256       4
    hippocampus      256       8
    hypothalamus     256       8
    motor            256       8
    cerebellum       256      16
    autonomic        256      10
    prefrontal       512      12
    association      512      12
    language         512       8
    ────────────────────────────────
    合计            3328

    突触  Σ min(64, 输入维) × 神经元
          = 256×(4+4+8+8+8+16+10) + 512×(12+12+8)
          = 256×58 + 512×32  ... 旧版按 56/34 计
          = 31744

    int8 权重分配容量 = Σ 64 × 神经元 = 212992 字节

（旧版的 56/34 与 58/32 口径差异见文末 `SYNAPSE_NOTE`，两者都保留为可查询的数字。）

模型
----
LIF（漏积分点火）：膜电位按 `decay = 1 - dt/tau` 泄漏，
超过阈值就发放一个脉冲并进入不应期。
权重用 int8 量化存储（省内存，也贴近"旧显卡"的设定），
计算时反量化为 float。

可塑性
------
STDP：发放在前者增强、在后者的削弱（相关性强化的 Hebbian 形式），
外加一个 WTA（赢者通吃）式侧抑制，防止整层一起发放。
"""

from __future__ import annotations

import math
import random
import threading
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Sequence, Tuple

# ----------------------------------------------------------------------
# 脑区定义
# ----------------------------------------------------------------------
@dataclass(frozen=True)
class RegionSpec:
    key: str            # 稳定标识（协议用）
    label: str          # 中文名
    neurons: int        # 神经元数
    inputs: int         # 输入维
    role: str           # 职责说明

    @property
    def synapses(self) -> int:
        """该区的突触数 = min(64, 输入维) × 神经元。"""
        return min(64, self.inputs) * self.neurons


REGION_SPECS: Tuple[RegionSpec, ...] = (
    RegionSpec("reflex", "反射弧", 256, 4,
               "不经思考的即时反应：缩手、眨眼、踉跄时扶墙"),
    RegionSpec("thalamus", "丘脑", 256, 4,
               "感觉总闸门：决定哪些输入值得送到皮层"),
    RegionSpec("hippocampus", "海马体", 256, 8,
               "情景记忆的编码与召唤：把'刚才'变成'记得'"),
    RegionSpec("hypothalamus", "下丘脑", 256, 8,
               "内稳态的中枢：饿、渴、困、体温、应激"),
    RegionSpec("motor", "运动皮层", 256, 8,
               "动作的发起与精细控制"),
    RegionSpec("cerebellum", "小脑", 256, 16,
               "时序与协调：让动作不生硬，让节奏不散"),
    RegionSpec("autonomic", "自主神经", 256, 10,
               "心跳、呼吸、出汗、瞳孔——她管不了的那些"),
    RegionSpec("prefrontal", "前额叶", 512, 12,
               "工作记忆、规划、抑制冲动、权衡代价"),
    RegionSpec("association", "联合皮层", 512, 12,
               "跨模态整合：把看到的、听到的、想到的拼成一件事"),
    RegionSpec("language", "语言区", 512, 8,
               "把内部状态翻译成句子——或者决定不说"),
)

REGION_KEYS: Tuple[str, ...] = tuple(r.key for r in REGION_SPECS)
REGION_MAP: Dict[str, RegionSpec] = {r.key: r for r in REGION_SPECS}

# 与前端/项目书对齐的总量常量
BASE_NEURONS = sum(r.neurons for r in REGION_SPECS)              # 3328
BASE_SYNAPSES = sum(r.synapses for r in REGION_SPECS)            # 31232（实算）
ALLOCATED_SYNAPSES = sum(64 * r.neurons for r in REGION_SPECS)   # 212992
assert BASE_NEURONS == 3328, "神经元总数应为 3328（256×7 + 512×3）"


# ----------------------------------------------------------------------
# 配置
# ----------------------------------------------------------------------
@dataclass
class SNNConfig:
    tau: float = 10.0            # 膜时间常数（毫秒）
    threshold: float = 1.0       # 点火阈值
    dt: float = 1.0              # 步长（毫秒）
    refractory: int = 2          # 不应期（步）
    weight_scale: float = 1.10   # 突触权重缩放（int8 → float 电流）
    connectivity: float = 0.1    # 连接稀疏度
    weight_slots: int = 64       # 每个神经元预留的权重槽（int8 容量口径）
    inhibition: float = 0.35     # 侧抑制强度
    stdp_lr: float = 0.004       # STDP 学习率
    stdp_window: int = 12        # STDP 时间窗（步）
    spontaneous: float = 0.10    # 自发放电强度（实测标定，见 step 内注释）
    max_rate: float = 0.30       # 发放率上限（不应期之外的软上限）
    seed: int = 20261002
    enable_plasticity: bool = True

    @property
    def decay(self) -> float:
        """膜电位每步的保留比例。clamp 到 [0,1]，防止 tau < dt 时发散。"""
        return min(1.0, max(0.0, 1.0 - self.dt / max(1e-6, self.tau)))


# ----------------------------------------------------------------------
# 单个脑区
# ----------------------------------------------------------------------
class Region:
    """一层脉冲神经元。

    权重用 int8 量化保存（值域 -127..127），计算时按 `weight_scale` 还原。

    关于两种"权重容量"口径 —— 旧版把这两个概念混用了，这里分清楚：
      · **突触数** = min(64, 输入维) × 神经元 —— 真正建立连接的数目（31232 总量）
      · **分配容量** = 64 × 神经元 —— 按"每个神经元预留 64 个 int8 槽"算的内存占用
        （212992 字节 ≈ 208 KiB）。槽位没被用到也占着，这是模拟旧显卡的显存分配。
    所以本类同时提供 `synapse_count` 与 `allocated_bytes`，不再含糊。
    """

    __slots__ = ("spec", "scale", "n", "inputs", "cfg", "v", "refr",
                 "spikes", "last_spike", "_w", "_rate", "rng", "_lock")

    def __init__(self, spec: RegionSpec, cfg: SNNConfig,
                 rng: random.Random, scale: int = 1) -> None:
        self.spec = spec
        # ★ 神经元数 = 区定义 × 规模。
        #   早期版本把 `scale` 存进了 SpikingNetwork 却**从没传到这里**，
        #   于是"网络规模"滑块拖到 4 倍，神经元数还是 3328 —— 一个静默失效的旋钮。
        self.scale = max(1, int(scale))
        self.n = spec.neurons * self.scale
        self.inputs = spec.inputs
        self.cfg = cfg
        self.rng = rng
        self.v = [0.0] * self.n
        self.refr = [0] * self.n
        self.spikes = [0] * self.n          # 本步是否发放
        self.last_spike = [0] * self.n
        self._rate = 0.0                    # 平滑后的发放率
        self._lock = threading.RLock()

        # ---- 权重：按 64 槽分配，稀疏初始化，int8 量化 ----
        # 注意必须夹到 [-127, 127]：gauss(0, 0.6) * 127 的极值能到 ±279，
        # 不夹的话初始权重就有一批越界值（实测 3328 个神经元里有 302 个），
        # 后面再怎么修学习规则也治不好。
        slots = cfg.weight_slots
        fan = min(slots, self.inputs)
        self._w: List[List[int]] = []
        for _ in range(self.n):
            row = [0] * slots
            for j in range(fan):
                if rng.random() < cfg.connectivity:
                    wq = int(round(rng.gauss(0.0, 0.6) * 127))
                    if wq > 127:
                        wq = 127
                    elif wq < -127:
                        wq = -127
                    row[j] = wq
            self._w.append(row)

    # ------------------------------------------------------------------
    @property
    def fan_in(self) -> int:
        """真正参与计算的输入数（取输入维与槽位数的较小者）。"""
        return min(self.cfg.weight_slots, self.inputs)

    @property
    def slots(self) -> int:
        return self.cfg.weight_slots

    @property
    def synapse_count(self) -> int:
        """该区的突触数 = min(64, 输入维) × 神经元。"""
        return min(self.cfg.weight_slots, self.inputs) * self.n

    @property
    def allocated_bytes(self) -> int:
        """该区按 int8 预留的权重内存 = 64 × 神经元。"""
        return self.cfg.weight_slots * self.n

    @property
    def rate(self) -> float:
        """发放率，0..1。前端脑区热力就用这个。"""
        return round(self._rate, 4)

    def weight_bytes(self) -> int:                 # 兼容旧调用名
        return self.allocated_bytes

    # ------------------------------------------------------------------
    def step(self, inputs: Sequence[float]) -> float:
        """推进一步，返回本区发放率（0..1）。"""
        with self._lock:
            cfg = self.cfg
            fan = self.fan_in
            inp = list(inputs[:self.inputs])
            while len(inp) < self.inputs:
                inp.append(0.0)
            decay = cfg.decay
            threshold = cfg.threshold
            scale = cfg.weight_scale / 127.0
            cap = max(1, int(self.n * cfg.max_rate))
            # 自发放电强度 = 每步目标点火概率（见 step 内注释）
            spontaneous_rate = cfg.spontaneous
            fired = 0
            rnd = self.rng.random

            for i in range(self.n):
                if fired >= cap:
                    # 软上限：到达上限后只泄漏，不再发放
                    self.spikes[i] = 0
                    self.v[i] *= decay
                    continue
                if self.refr[i] > 0:
                    self.refr[i] -= 1
                    self.spikes[i] = 0
                    self.v[i] *= decay
                    continue
                row = self._w[i]
                s = 0.0
                for j in range(fan):
                    wq = row[j]
                    if wq:
                        s += wq * inp[j]
                s *= scale
                # 自发放电：泊松式背景驱动。
                # 没有这一项时，静息状态下膜电位会一路衰减到 0，
                # 整个网络变成死的 —— 实测发现过这个缺陷，故显式补上。
                #
                # 幅度取 `-ln(U) * rate`，其中 rate 由「目标点火概率」反推：
                # 阈值 1.0、泊松强度 r 时 P(越阈) = 1 - e^(-r)，故 r 直接等于
                # 期望的每步点火概率。这样**与输入维无关**，
                # 各区静息发放率才可比（早期写成 `spontaneous × inputs`，
                # 结果 4 输入的区完全不动、16 输入的区又偏高）。
                s += spontaneous_rate * (-math.log(max(1e-9, rnd())))
                v = self.v[i] * decay + s
                if v >= threshold:
                    self.spikes[i] = 1
                    self.refr[i] = cfg.refractory
                    self.v[i] = 0.0
                    self.last_spike[i] = 0
                    fired += 1
                else:
                    self.spikes[i] = 0
                    self.v[i] = v
                    self.last_spike[i] += 1

            total = fired / self.n if self.n else 0.0
            # 指数平滑，避免前端看到锯齿
            self._rate += (total - self._rate) * 0.25
            self._rate = min(1.0, max(0.0, self._rate))
        return self._rate

    # ------------------------------------------------------------------
    def learn(self, inputs: Sequence[float], reward: float = 0.0) -> None:
        """一步 STDP + 突触新生 + 突触衰减。

        旧版实现里有两个毛病，这里都修掉：
          1. 侧抑制用的是**累乘衰减**，几十步后权重一路压到负数、
             越过 int8 下界。现在改为朝 0 收敛的线性收缩，天然有界。
          2. STDP 只强化「已经存在」的连接，于是非零权重数永远不变，
             学不到新东西。现在允许在活跃输入上**新建**连接。
        """
        if not self.cfg.enable_plasticity:
            return
        with self._lock:
            cfg = self.cfg
            fan = self.fan_in
            slots = cfg.weight_slots
            gain = 1.0 + max(-0.9, min(1.0, reward))
            lr = cfg.stdp_lr * gain
            active_any = False

            for i in range(self.n):
                if not self.spikes[i]:
                    continue
                active_any = True
                row = self._w[i]
                for j in range(fan):
                    x = inputs[j] if j < len(inputs) else 0.0
                    if abs(x) < 1e-6:
                        continue
                    delta = lr * x * 127.0
                    if row[j] == 0 and delta <= 0:
                        continue                    # 不因抑制而新生连接
                    # 先按浮点夹到 int8 范围、再取整 —— 顺序不能反。
                    # （反过来的话，`min(127, 279)` 拿到的是夹过的整数，
                    #   而不断累加的浮点值会在取整前就越界，权重失控。）
                    row[j] = int(max(-127.0, min(127.0, row[j] + delta)))
                # 长出新的连接：在活跃输入里随机挑一个空槽
                if reward > 0.1:
                    for _ in range(2):
                        j = int(self.rng.random() * fan)
                        x = inputs[j] if j < len(inputs) else 0.0
                        if row[j] == 0 and abs(x) > 1e-6:
                            row[j] = int(max(1.0, min(127.0, lr * 127.0 * 8)))

            # 侧抑制：朝 0 线性收缩（有界，不会越压越负）
            if cfg.inhibition > 0 and active_any:
                active = sum(self.spikes)
                if active > self.n * 0.25:
                    keep = 1.0 - cfg.inhibition * 0.05
                    for i in range(self.n):
                        row = self._w[i]
                        for j in range(slots):
                            wq = row[j]
                            if wq:
                                row[j] = int(max(-127.0,
                                                 min(127.0, wq * keep)))

    # ------------------------------------------------------------------
    def to_client(self) -> Dict[str, Any]:
        return {
            "key": self.spec.key,
            "label": self.spec.label,
            "rate": self.rate,
            "neurons": self.n,
            "inputs": self.inputs,
            "synapses": self.synapse_count,
            "allocated_bytes": self.allocated_bytes,
            "fan_in": self.fan_in,
            "slots": self.slots,
            "role": self.spec.role,
        }

    def stats(self) -> Dict[str, Any]:
        with self._lock:
            nz = sum(1 for row in self._w for w in row if w)
            fan = self.fan_in
            slots = self.slots
        return {
            "key": self.spec.key, "neurons": self.n, "fan_in": fan,
            "slots": slots,
            "synapses": self.synapse_count,
            "allocated_bytes": self.allocated_bytes,
            "nonzero_weights": nz,
            "connectivity_used": round(nz / max(1, self.n * slots), 4),
            "rate": self.rate,
            "mean_v": round(sum(self.v) / max(1, len(self.v)), 4),
        }


# ----------------------------------------------------------------------
# 整个网络
# ----------------------------------------------------------------------
class SpikingNetwork:
    """10 个脑区组成的脉冲网络。

    对外只暴露三件事：`step()`（推进）、`rates`（发放率，给前端）、
    `stats()`（总量核对）。
    """

    def __init__(self, cfg: Optional[SNNConfig] = None, scale: int = 1) -> None:
        self.cfg = cfg or SNNConfig()
        self.scale = max(1, int(scale))
        self._lock = threading.RLock()
        self.rng = random.Random(self.cfg.seed)
        self.regions: Dict[str, Region] = {
            r.key: Region(r, self.cfg, self.rng, self.scale)
            for r in REGION_SPECS}
        self.t = 0
        self.steps = 0

    # ------------------------------------------------------------------
    @property
    def neurons(self) -> int:
        return sum(r.n for r in self.regions.values())

    @property
    def synapses(self) -> int:
        """真正建立连接的突触数（256×58 + 512×32 = 31232）。"""
        return sum(r.synapse_count for r in self.regions.values())

    @property
    def allocated_bytes(self) -> int:
        """按每神经元 64 个 int8 槽预留的内存（64×3328 = 212992）。"""
        return sum(r.allocated_bytes for r in self.regions.values())

    @property
    def rates(self) -> Dict[str, float]:
        return {k: r.rate for k, r in self.regions.items()}

    # ------------------------------------------------------------------
    def step(self, stimuli: Optional[Dict[str, Sequence[float]]] = None,
             reward: float = 0.0) -> Dict[str, float]:
        """推进一个时间步。

        stimuli: 每个脑区的输入向量。**缺省或某项为 None 时，
        该区只靠自发放电维持活动** —— 这一条很重要，
        否则静息状态下网络会整体沉默（实测踩过）。
        返回各脑区发放率。
        """
        with self._lock:
            self.t += self.cfg.dt
            self.steps += 1
            stim = stimuli or {}
            for key, region in self.regions.items():
                vec = stim.get(key)
                if vec is None:
                    vec = [0.0] * region.inputs
                region.step(vec)
            if self.cfg.enable_plasticity and self.steps % 4 == 0:
                for key, region in self.regions.items():
                    vec = stim.get(key)
                    if vec is not None:
                        region.learn(vec, reward)
            return self.rates

    # ------------------------------------------------------------------
    def region_inputs(self) -> Dict[str, int]:
        return {r.key: r.inputs for r in REGION_SPECS}

    def to_client(self) -> Dict[str, Any]:
        return {
            "regions": [self.regions[k].to_client() for k in REGION_KEYS],
            "totals": {
                "neurons": self.neurons,
                "synapses": self.synapses,
                "synapses_allocated": self.allocated_bytes,
                "regions": len(self.regions),
                "steps": self.steps,
                "t_ms": round(self.t, 2),
            },
        }

    def stats(self) -> Dict[str, Any]:
        return {
            "neurons": self.neurons,
            "synapses": self.synapses,
            "allocated_bytes": self.allocated_bytes,
            "memory_kib": round(self.allocated_bytes / 1024.0, 1),
            "regions": [self.regions[k].stats() for k in REGION_KEYS],
            "steps": self.steps,
            "config": {
                "tau": self.cfg.tau, "threshold": self.cfg.threshold,
                "dt": self.cfg.dt, "refractory": self.cfg.refractory,
                "decay": round(self.cfg.decay, 4),
                "weight_scale": self.cfg.weight_scale,
                "connectivity": self.cfg.connectivity,
                "weight_slots": self.cfg.weight_slots,
                "inhibition": self.cfg.inhibition,
                "stdp_lr": self.cfg.stdp_lr,
                "spontaneous": self.cfg.spontaneous,
                "max_rate": self.cfg.max_rate,
                "plasticity": self.cfg.enable_plasticity,
            },
        }

    # ------------------------------------------------------------------
    def save(self) -> Dict[str, Any]:
        """存档：权重、膜电位、步数。"""
        with self._lock:
            return {
                "t": self.t, "steps": self.steps, "scale": self.scale,
                "regions": {
                    k: {"v": list(r.v), "rate": r._rate, "w": r._w}
                    for k, r in self.regions.items()},
            }

    def load(self, data: Dict[str, Any]) -> bool:
        """读档。字段缺失或维度不符时**部分恢复**，不整体丢弃。

        注意：权重按**完整槽位**（64）恢复，不能按 fan_in 截断 ——
        否则多出来的槽位会丢失，下次存档就和上次不一致。
        """
        if not isinstance(data, dict):
            return False
        with self._lock:
            self.t = float(data.get("t") or 0.0)
            self.steps = int(data.get("steps") or 0)
            regs = data.get("regions") or {}
            restored = 0
            for k, r in self.regions.items():
                d = regs.get(k)
                if not isinstance(d, dict):
                    continue
                v = d.get("v")
                if isinstance(v, list) and len(v) == r.n:
                    r.v = [float(x) for x in v]
                try:
                    r._rate = min(1.0, max(0.0, float(d.get("rate") or 0.0)))
                except (TypeError, ValueError):
                    pass
                w = d.get("w")
                if isinstance(w, list) and len(w) == r.n:
                    slots = r.slots
                    rows = []
                    for row in w:
                        if isinstance(row, list):
                            if len(row) >= slots:
                                rows.append([int(max(-127, min(127, x)))
                                             for x in row[:slots]])
                            else:
                                # 旧存档槽位较少：补零到当前槽位数，不丢数据
                                rows.append([int(max(-127, min(127, x)))
                                             for x in row]
                                            + [0] * (slots - len(row)))
                        else:
                            rows.append([0] * slots)
                    r._w = rows
                restored += 1
            return restored > 0


# ----------------------------------------------------------------------
# 突触总数：两种口径的来龙去脉（重写时特意查清的）
# ----------------------------------------------------------------------
# 旧版第 2 代（shiroko_runtime.py L3210-3289）的 10 个脑区是：
#
#     256 神经元：脊髓反射(4) 丘脑(4) 海马体(8) 下丘脑(8)
#                 运动(12) 小脑(12) 自主神经(8)      → 输入维合计 56
#     512 神经元：杏仁核(8) 前额叶(16) 基底核(10)     → 输入维合计 34
#
#     256×56 + 512×34 = 14336 + 17408 = 31744      ← 第2代自洽
#
# 但第 3 代（galbeta_server.py）换了区名与输入维：
#
#     256 神经元：reflex(4) thalamus(4) hippocampus(8) hypothalamus(8)
#                 motor(8) cerebellum(16) autonomic(10)  → 合计 58
#     512 神经元：prefrontal(12) association(12) language(8) → 合计 32
#
#     256×58 + 512×32 = 14848 + 16384 = 31232      ← 第3代真实值
#
# **第 3 代换了几何却把 31744 这个数字抄了下来**，于是前端显示的
# BASE_SYNAPSES 比它自己的区定义多 512。这是旧版的一个数据不一致。
#
# 本次重写以第 3 代的**区定义**（10 区 / 3328 神经元，与项目书一致）为准，
# 突触数一律**实算**，不再硬编码，前端也从接口取值。
# 需要"分配容量"（int8 权重按每神经元 64 个预留的字节数）时用
# `allocated_bytes`，那是另一个概念，212992 保持不变。

BASE_SYNAPSES_LEGACY = 31744     # 第2代口径（256×56 + 512×34），仅供对照
BASE_SYNAPSES_REAL = 31232       # 第3代区定义下的真实值（256×58 + 512×32）


# ======================================================================
# 综合质量 ↔ 参数映射（旧版有，重写时曾整块丢失）
# ======================================================================
# 旧版用**一个 0–100 的滑块**同时驱动 7 个 SNN 参数（`qualityToConfig`）
# 与 4 个预设。这对用户很友好 —— 不必理解 tau/threshold 是什么。
#
# 本实现与旧版有一点**必须说清楚的不同**：
#   · `neuron_scale` 会**真的重建网络**（改变神经元数量），开销约 0.2–0.5 秒
#   · 其余 5 个参数是**热改**（直接改 `cfg`，下一步生效，不丢状态）
#   · `connectivity` 映射到 `weight_slots`（每个神经元预留的权重槽），
#     这是真正的"连接密度"旋钮；旧版把它当"平均连接数"用
PRESETS: Dict[str, Dict[str, Any]] = {
    "low":          {"quality": 10,  "label": "低功耗"},
    "balanced":     {"quality": 35,  "label": "均衡"},
    "high":         {"quality": 70,  "label": "高性能"},
    "experimental": {"quality": 100, "label": "实验"},
}

# 热改参数的范围（决定滑块两端）
QUALITY_RANGES: Dict[str, Tuple[float, float]] = {
    "threshold": (0.3, 3.0),
    "tau": (2.0, 40.0),
    "weight_scale": (0.02, 0.30),
    "refractory": (1.0, 10.0),
    "dt": (0.2, 2.0),
    "weight_slots": (4.0, 128.0),
    "neuron_scale": (0.25, 4.0),
}


def quality_to_config(q: float) -> Dict[str, Any]:
    """0–100 的综合质量 → 7 个参数。

    公式**沿用旧版** `qualityToConfig`（低质量 = 慢 tau / 低阈值 / 少连接），
    只是把 `connectivity` 换成真正的 `weight_slots`。
    """
    t = max(0.0, min(1.0, float(q) / 100.0))
    return {
        "neuron_scale": round(0.25 + 3.75 * t, 2),
        "weight_slots": int(round((4 + 124 * t) / 4) * 4),
        "threshold": round(3.0 - 2.7 * t, 1),
        "tau": int(round(40 - 38 * t)),
        "weight_scale": round(0.02 + 0.28 * t, 2),
        "refractory": int(round(10 - 9 * t)),
        "dt": round(2.0 - 0.9 * t, 1),
    }


def config_to_quality(cfg: Any, scale: Any = None) -> int:
    """参数 → 0–100。与 `quality_to_config` 互逆（取各项的平均）。

    `scale` 是网络的神经元倍率（`SpikingNetwork.scale`）。
    不传时退回到 `cfg.neuron_scale`（那是给前端看的口径）。
    """
    slots = getattr(cfg, "weight_slots", 64)
    if scale is None:
        ns = getattr(cfg, "neuron_scale", 1.0)
    else:
        try:
            ns = float(scale)
        except (TypeError, ValueError):
            ns = 1.0
    pairs = (
        ((ns - 0.25) / 3.75),
        ((slots - 4) / 124.0),
        ((3.0 - getattr(cfg, "threshold", 1.0)) / 2.7),
        ((40 - getattr(cfg, "tau", 10.0)) / 38.0),
        ((getattr(cfg, "weight_scale", 1.1) - 0.02) / 0.28),
        ((10 - getattr(cfg, "refractory", 2)) / 9.0),
        # ★ 分母用 0.9，与 quality_to_config 的 `2.0 - 0.9*t` 对上。
        #   旧版这里写的是 1.8（那边前进用的也是 1.8），我抄了前进公式
        #   却留着旧的反推分母，结果 q=100 反推成 93，往返不闭合。
        ((2.0 - getattr(cfg, "dt", 1.0)) / 0.9),
    )
    t = sum(max(0.0, min(1.0, x)) for x in pairs) / len(pairs)
    return int(round(t * 100))


def estimate_memory_mb(cfg: Any = None, neuron_scale: float = 1.0) -> float:
    """内存估算。公式**照抄旧版** `estimateMemoryMB`：

        neurons  = BASE_NEURONS × neuron_scale
        synapses = neurons × connectivity
        MB       = (synapses × 5 + neurons × 13) / 1048576

    这里的 `connectivity` 就是 `weight_slots`。
    """
    slots = getattr(cfg, "weight_slots", 64) if cfg is not None else 64
    neurons = max(1.0, BASE_NEURONS * float(neuron_scale))
    synapses = neurons * slots
    return (synapses * 5 + neurons * 13) / (1024.0 * 1024.0)


__all__ = [
    "SNNConfig", "RegionSpec", "Region", "SpikingNetwork",
    "REGION_SPECS", "REGION_KEYS", "REGION_MAP",
    "BASE_NEURONS", "BASE_SYNAPSES", "ALLOCATED_SYNAPSES",
    "BASE_SYNAPSES_LEGACY", "BASE_SYNAPSES_REAL",
    "PRESETS", "QUALITY_RANGES", "quality_to_config",
    "config_to_quality", "estimate_memory_mb",
]
