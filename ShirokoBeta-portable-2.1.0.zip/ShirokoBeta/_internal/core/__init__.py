# -*- coding: utf-8 -*-
"""Shiroko β —— 核心引擎包。

模块划分
--------
    llm.py         大模型接入（DeepSeek 现行 API，标准库实现）
    geo.py         环境几何：房间、地标、坐标换算（小地图的唯一数据源）
    snn.py         脉冲神经网络（LIF + WTA + STDP）
    fep.py         自由能原理（预测误差、惊奇、复杂度）
    homeo.py       内稳态 26 维生理模拟
    memory.py      记忆系统（工作记忆 / 情景记忆 / 睡眠 / 梦境）
    persona.py     人格引擎（白子 / 渐进酱的语言与行为）
    life.py        数字生命：把上面几者组装成一个活着的个体
    runtime.py     世界运行时：多生命、时间推进、存档
    server.py      HTTP + WebSocket 服务
"""

__all__ = ["llm", "geo", "snn", "fep", "homeo", "memory", "persona",
           "life", "runtime", "server"]

VERSION = "2.1.0"
CODENAME = "Abydos"
APP_NAME = "Shiroko \u03b2"
PROJECT_NAME = "\u6e10\u8fdb\u7ebf\u8ba1\u5212 \u00b7 Abydos Digital Life Project"
