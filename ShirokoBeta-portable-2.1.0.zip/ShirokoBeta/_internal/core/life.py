# -*- coding: utf-8 -*-
"""
Shiroko β —— 数字生命

把 SNN / FEP / 内稳态 / 记忆 / 人格 / 环境 组装成一个**活着的个体**。
一次 `tick()` 就是她的一瞬间：

    感知 → 编码 → SNN 发放 → FEP → 注意力 → 情绪 → 决策(EFE) → 门控
        → 执行动作 → 更新生理 → 写记忆 → 生成语言

恢复的"第3代砍掉的功能"（都在本模块）
------------------------------------
1. **注意力显著性打分**（6 通道公式）—— 第3代只剩比大小，
   于是"饿了会注意食物""渴了会注意水源"这些行为全没了。
2. **反射判据**（三条）—— 疼痛/强光/强压应不经思考直接触发缩回。
3. **基底核门控否决权** —— 第3代只影响 SNN 输入，不再能否决动作。
4. **动态寻路** —— 按地标距离找最近的座位/水源，而非硬编码地标名。
5. **真·EFE 决策** —— 见 core/fep.py。
6. **情景记忆 importance 公式 + 标签 + strength**（见 core/memory.py）。
7. **LanguageSystem 的内稳态→语言提示**（见 build_state_brief）。
"""

from __future__ import annotations

import math
import random
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Sequence, Tuple

from . import fep as fep_mod
from . import geo, homeo as homeo_mod, memory as mem_mod, persona as persona_mod
from . import snn as snn_mod

# ----------------------------------------------------------------------
# 注意力：基础显著性（第2代 L4857，原样保留）
# ----------------------------------------------------------------------
SALIENCY_BASE: Dict[str, float] = {
    "vision": 0.30, "auditory": 0.20, "tactile": 0.05,
    "proprioception": 0.10, "olfactory": 0.02, "gustatory": 0.02,
}
ATTENTION_CHANNELS = tuple(SALIENCY_BASE)
# 第2代没有这一路，第3代加了内感受（饿/渴/痛本身就是一种注意力来源）
ATTENTION_CHANNELS_FULL = ATTENTION_CHANNELS + ("interoception",)

# 反射判据阈值（第2代 L5020-5042）
REFLEX_TEMP_C = 45.0          # 触觉温度超过这个值 → 缩手
REFLEX_PRESSURE_KPA = 100.0
REFLEX_PAIN = 0.75
REFLEX_BRIGHTNESS = 0.98      # 强光刺眼

# 决策节流（前额叶不每 tick 都跑，太费）
PREFRONTAL_MIN_INTERVAL = 4.0

# 主动发言记录上限（给界面回看"她自己说过什么"）
MAX_SPOKEN = 120

# 开口的最短间隔（秒）。
# ★ 这不是"到点就说"的定时器 —— 它只是让 `speak` **有资格进入候选集**。
#   要不要说由 EFE 决定（认知价值随时长上升，和看窗外、喝水一起比）。
#   刚说完话时认知价值接近 0，本来也选不上，这个下限只是省掉无谓计算。
SPEAK_MIN_GAP = 60.0

# 动作的"驻留时长"（真实秒）：决定之后先做一会儿，不每 4 秒重挑一次。
# ★ 没有它的话她会永远在"看窗→看门→看黑板"之间跳 ——
#   实测 look_window 占 51.6%，不是因为想看，是因为没有延续性。
#   真实的注意力是会驻留的（不随意注意的抑制返回）。
ENGAGE_SECONDS: Dict[str, float] = {
    "look_window": 45.0, "look_at_board": 35.0, "look_door": 25.0,
    "do_nothing": 30.0, "relax": 60.0, "sit_down": 90.0,
    "stand_up": 8.0, "eat_snack": 40.0, "drink_water": 25.0,
    "sleep": 120.0, "move_to_seat": 20.0, "move_to_water": 20.0,
    # speak 也要驻留：不驻留 `self.plan` 会一直粘在 "speak" 上，
    # 而节流块每 4 秒才进一次，SPEAK_MIN_GAP 门控就没机会生效
    "speak": 20.0,
}
# 动作计划表（第3代版，含地标目标）
PLAN_ACTIONS: Dict[str, List[Dict[str, Any]]] = {
    "sit_down": [{"op": "sit_down"}],
    "stand_up": [{"op": "stand_up"}],
    "look_at_board": [{"op": "stand_up"},
                      {"op": "move_to", "landmark": "board"}],
    "look_window": [{"op": "stand_up"},
                    {"op": "move_to", "landmark": "window"}],
    "look_door": [{"op": "stand_up"},
                  {"op": "move_to", "landmark": "door"}],
    "sleep": [{"op": "sit_down"}],
    "relax": [{"op": "sit_down"}],
    "do_nothing": [],
    "eat_snack": [{"op": "eat_snack"}],
    "drink_water": [{"op": "drink_water"}],
    "move_to_seat": [{"op": "move_to", "has_seat": True},
                     {"op": "sit_down"}],
    "move_to_water": [{"op": "move_to", "has_water": True},
                      {"op": "drink_water"}],
    "wake_up": [{"op": "stand_up"}],
    "reflex_withdraw": [{"op": "relax"}],
}

MOVE_SPEED = 0.30             # 米/步（move_to）
RUN_SPEED = 0.55
ARRIVE_EPS = 0.05


# ----------------------------------------------------------------------
# 感官数据（第2代是 6 个 dataclass，第3代退化成裸 dict —— 这里恢复 dataclass）
# ----------------------------------------------------------------------
@dataclass
class Vision:
    brightness: float = 0.7
    objects_detected: List[Dict[str, Any]] = field(default_factory=list)
    dominant_color: str = "unknown"
    scene_type: str = "indoor"

    def to_dict(self) -> Dict[str, Any]:
        return {"brightness": round(self.brightness, 4),
                "objects_detected": self.objects_detected,
                "dominant_color": self.dominant_color,
                "scene_type": self.scene_type}


@dataclass
class Auditory:
    loudness_db: float = 25.0
    sound_source: str = "none"        # none | human | rain | wind | clock
    direction_azimuth_deg: float = 0.0
    distance_estimate: float = 5.0

    def to_dict(self) -> Dict[str, Any]:
        return {"loudness_db": round(self.loudness_db, 2),
                "sound_source": self.sound_source,
                "direction_azimuth_deg": round(self.direction_azimuth_deg, 2),
                "distance_estimate": round(self.distance_estimate, 2)}


@dataclass
class Tactile:
    body_part: str = "right_hand"
    pressure_kpa: float = 0.0
    temperature_celsius: float = 35.0
    vibration_freq_hz: float = 0.0
    material: str = "unknown"

    def to_dict(self) -> Dict[str, Any]:
        return {"body_part": self.body_part,
                "pressure_kpa": round(self.pressure_kpa, 3),
                "temperature_celsius": round(self.temperature_celsius, 2),
                "vibration_freq_hz": round(self.vibration_freq_hz, 2),
                "material": self.material}


@dataclass
class Olfactory:
    scent: str = "none"
    intensity: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        return {"scent": self.scent, "intensity": round(self.intensity, 3)}


@dataclass
class Gustatory:
    taste: str = "none"
    intensity: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        return {"taste": self.taste, "intensity": round(self.intensity, 3)}


@dataclass
class Proprioception:
    student_state: str = "standing"      # standing | sitting | sleeping | walking
    position: Tuple[float, float] = (0.0, 0.0)
    hip_angle: float = 0.0
    knee_angle: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        return {"student_state": self.student_state,
                "position": [round(self.position[0], 3),
                             round(self.position[1], 3)],
                "hip_angle": round(self.hip_angle, 1),
                "knee_angle": round(self.knee_angle, 1)}


@dataclass
class Interoception:
    """内感受：第3代新增的第 7 通道。"""

    hunger: float = 0.0
    thirst: float = 0.0
    fatigue: float = 0.0
    pain: float = 0.0
    temperature: float = 37.0
    heart_rate: float = 72.0

    def to_dict(self) -> Dict[str, Any]:
        return {"hunger": round(self.hunger, 3), "thirst": round(self.thirst, 3),
                "fatigue": round(self.fatigue, 3), "pain": round(self.pain, 3),
                "temperature": round(self.temperature, 2),
                "heart_rate": round(self.heart_rate, 1)}


@dataclass
class SensoryBuffer:
    """一帧感官。"""

    vision: Vision = field(default_factory=Vision)
    auditory: Auditory = field(default_factory=Auditory)
    tactile: Tactile = field(default_factory=Tactile)
    olfactory: Olfactory = field(default_factory=Olfactory)
    gustatory: Gustatory = field(default_factory=Gustatory)
    proprioception: Proprioception = field(default_factory=Proprioception)
    interoception: Interoception = field(default_factory=Interoception)

    def to_dict(self) -> Dict[str, Any]:
        return {"vision": self.vision.to_dict(),
                "auditory": self.auditory.to_dict(),
                "tactile": self.tactile.to_dict(),
                "olfactory": self.olfactory.to_dict(),
                "gustatory": self.gustatory.to_dict(),
                "proprioception": self.proprioception.to_dict(),
                "interoception": self.interoception.to_dict()}

    def summary(self) -> str:
        v, a = self.vision, self.auditory
        return ("亮度 %.2f，看到 %d 个物体；%s %.0f dB；"
                "压力 %.1f kPa；姿势 %s"
                % (v.brightness, len(v.objects_detected), a.sound_source,
                   a.loudness_db, self.tactile.pressure_kpa,
                   self.proprioception.student_state))


# ----------------------------------------------------------------------
# 感官编码器（10 个，第2代有、第3代照抄 —— 保留）
# ----------------------------------------------------------------------
BASAL_PLANS = ["sit_down", "stand_up", "move_to_seat", "move_to_water",
               "eat_snack", "drink_water", "sleep", "relax",
               "look_at_board", "look_window"]
MOTOR_PLANS = ["sit_down", "stand_up", "look_at_board", "look_window",
               "look_door", "sleep", "wake_up", "move_to_seat",
               "move_to_water", "eat_snack", "drink_water", "relax"]


class SensoryEncoder:
    """把感官/生理/记忆编码成各脑区的输入向量。"""

    def __init__(self, rng: Optional[random.Random] = None) -> None:
        self.rng = rng or random.Random(20261002)

    def _bern(self, p: float, n: int) -> List[float]:
        r = self.rng.random
        return [1.0 if r() < max(0.0, min(1.0, p)) else 0.0 for _ in range(n)]

    def encode_reflex(self, s: SensoryBuffer) -> List[float]:
        """反射弧：硬阈值，不经采样。"""
        t = s.tactile
        return [
            1.0 if t.temperature_celsius > REFLEX_TEMP_C else 0.0,
            1.0 if t.pressure_kpa > REFLEX_PRESSURE_KPA else 0.0,
            1.0 if t.temperature_celsius < 10.0 else 0.0,
            1.0 if t.vibration_freq_hz > 50.0 else 0.0,
        ]

    def encode_thalamus(self, s: SensoryBuffer, attention: str = "vision",
                        attention_level: float = 0.5) -> List[float]:
        v, a = s.vision, s.auditory
        p_vis = 0.30 + 0.10 * len(v.objects_detected)
        p_aud = 0.20 + 0.10 * (a.loudness_db / 50.0)
        p_tac = 0.6 if s.tactile.pressure_kpa > 1.0 else 0.05
        changed = 0.5 if s.proprioception.student_state else 0.2
        return [
            p_vis * (0.4 + 0.6 * attention_level),
            p_aud, p_tac, changed,
        ]

    def encode_hippocampus(self, thal: Sequence[float],
                           reflex: Sequence[float],
                           memory_hint: float = 0.0) -> List[float]:
        out = list(thal[:4]) + list(reflex[:2]) + [memory_hint]
        out.append(self.rng.random() * 0.3)
        return out[:8]

    def encode_amygdala(self, s: SensoryBuffer,
                        h: Dict[str, float]) -> List[float]:
        return [
            s.vision.brightness,
            s.auditory.loudness_db / 100.0,
            s.tactile.pressure_kpa / 50.0,
            _c(h.get("pain_level")),
            _c(h.get("hunger")),
            _c(h.get("muscle_fatigue")),
            _c(h.get("sleep_pressure")),
            _c(h.get("adrenaline")) / 2.0,
        ]

    def encode_hypothalamus(self, h: Dict[str, float]) -> List[float]:
        return [
            _c(h.get("hunger")), _c(h.get("thirst")),
            _c(h.get("muscle_fatigue")), _c(h.get("sleep_pressure")),
            _c(h.get("pain_level")),
            (_f(h.get("core_temp"), 37.0) - 36.0) / 3.0,
            1.0 - _f(h.get("total_energy_kcal"), 2000.0) / 2500.0,
            abs(_f(h.get("electrolyte_balance"))) * 2.0,
        ]

    def encode_prefrontal(self, s: SensoryBuffer, h: Dict[str, float],
                          attention: str, plan: str,
                          memory_hint: float = 0.0) -> List[float]:
        onehot = [1.0 if attention == ch else 0.0
                  for ch in ATTENTION_CHANNELS_FULL[:6]]
        while len(onehot) < 6:
            onehot.append(0.0)
        return onehot + [
            _c(h.get("hunger")), _c(h.get("thirst")),
            _c(h.get("muscle_fatigue")), _c(h.get("sleep_pressure")),
            _c(h.get("adrenaline")) / 2.0,
            _c(h.get("cortisol")) / 40.0,
            1.0 if memory_hint > 0.1 else 0.3,
            min(1.0, len(s.vision.objects_detected) / 8.0),
            min(1.0, s.auditory.loudness_db / 100.0),
            1.0 if plan != "relax" else 0.3,
        ]

    def encode_basal(self, h: Dict[str, float], plan: str) -> List[float]:
        """基底核：候选动作 one-hot，带疲劳/疼痛/饥饿的门控。"""
        vec = [0.0] * len(BASAL_PLANS)
        if plan in BASAL_PLANS:
            vec[BASAL_PLANS.index(plan)] = 1.0
        fatigue = _c(h.get("muscle_fatigue"))
        pain = _c(h.get("pain_level"))
        hunger = _c(h.get("hunger"))
        if fatigue > 0.8 or pain > 0.5:
            # 高耗动作被抑制（sit_down/stand_up/move_to_seat 的位置）
            for i in (0, 1, 2):
                vec[i] = 0.0
        if hunger > 0.85:
            vec[BASAL_PLANS.index("eat_snack")] = 1.0
        return vec

    def encode_motor(self, h: Dict[str, float], plan: str) -> List[float]:
        vec = [0.0] * len(MOTOR_PLANS)
        if plan in MOTOR_PLANS:
            vec[MOTOR_PLANS.index(plan)] = 1.0
        vec[-1] = min(0.5, _c(h.get("muscle_fatigue")) * 0.5)
        return vec

    def encode_cerebellum(self, motor: Sequence[float]) -> List[float]:
        """小脑：运动指令的时序微调（旧版是直通截断，这里补上真正的延迟缓冲）。"""
        out = list(motor[:12])
        while len(out) < 12:
            out.append(0.0)
        if self._prev_motor:
            # 与上一拍混合 —— 这才是"时序协调"该有的样子
            out = [0.7 * a + 0.3 * b for a, b in zip(out, self._prev_motor)]
        self._prev_motor = list(out)
        return out

    _prev_motor: Optional[List[float]] = None

    def encode_autonomic(self, h: Dict[str, float], s: SensoryBuffer,
                         amy_rate: float, hypo_rate: float) -> List[float]:
        return [
            _c(h.get("adrenaline")) / 2.0,
            _c(h.get("cortisol")) / 40.0,
            _f(h.get("heart_rate"), 72.0) / 150.0,
            _f(h.get("core_temp"), 37.0) / 40.0,
            _c(h.get("pain_level")),
            amy_rate, hypo_rate,
            self.rng.random() * 0.2,
        ]

    def encode_all(self, s: SensoryBuffer, h: Dict[str, float],
                   attention: str = "vision", plan: str = "relax",
                   memory_hint: float = 0.0,
                   attention_level: float = 0.5,
                   rates: Optional[Dict[str, float]] = None) -> Dict[str, List[float]]:
        r = rates or {}
        reflex = self.encode_reflex(s)
        thal = self.encode_thalamus(s, attention, attention_level)
        return {
            "reflex": reflex,
            "thalamus": thal,
            "hippocampus": self.encode_hippocampus(thal, reflex, memory_hint),
            "amygdala": self.encode_amygdala(s, h),
            "hypothalamus": self.encode_hypothalamus(h),
            "motor": self.encode_motor(h, plan),
            "cerebellum": self.encode_cerebellum(self.encode_motor(h, plan)),
            "autonomic": self.encode_autonomic(h, s,
                                               r.get("amygdala", 0.2),
                                               r.get("hypothalamus", 0.2)),
            "prefrontal": self.encode_prefrontal(s, h, attention, plan,
                                                 memory_hint),
            "association": self.encode_prefrontal(s, h, attention, plan,
                                                  memory_hint),
            "language": self.encode_hypothalamus(h),
        }


# ----------------------------------------------------------------------
class DigitalLife:
    """一个数字生命。"""

    def __init__(self, *, name: str = persona_mod.SHIROKO_NAME,
                 env: Optional[geo.Environment] = None,
                 seed: int = 20261002,
                 scale: int = 1,
                 life_id: str = "") -> None:
        self.rng = random.Random(seed)
        self.name = name
        self.persona = persona_mod.PersonaEngine(name, self.rng)
        # ★ `life_id` 是**真实身份**，由 Runtime 在登记时设定，
        #   `char_id` 只是它没设定时的推算结果。
        #   早期只有推算版本，于是"字典键是 default-2、对象自称 default"
        #   这种自相矛盾的状态会真的出现（新建角色顶掉默认角色那次）。
        self.life_id = life_id or self._infer_id(name)
        self.homeo = homeo_mod.Homeostasis(seed=seed)
        self.memory = mem_mod.MemorySystem(self.rng)
        self.snn = snn_mod.SpikingNetwork(scale=scale) if scale else None
        self.fep = fep_mod.FEPNetwork()
        self.encoder = SensoryEncoder(self.rng)
        self.env = env or geo.classroom()

        # 位置与姿态
        self.pos: Tuple[float, float] = self.env.spawn
        self.state = "standing"
        self.plan = "relax"
        self.attention = "vision"
        self.attention_level = 0.5
        self.last_rates: Dict[str, float] = {k: 0.0 for k in snn_mod.REGION_KEYS}
        self.efe = fep_mod.EFEChoice()

        # 内部状态
        self.valence = 0.0
        self.arousal = 0.0
        self.tick_count = 0
        self.sim_clock = 8.0                 # 模拟时钟（小时）
        self._last_prefrontal = -999.0
        self._last_reflex = ""
        self._prev_vision_count = 0
        self._prev_state = "standing"
        self._policy = "hybrid_snn"
        self._homeostasis_enabled = True
        self._lock = threading.RLock()
        # 主动发言的计时（真实秒）
        self._last_spoke = 0.0
        self._last_user_input = 0.0
        self._speak_ready_at = 0.0
        self._engage_until = 0.0
        self._spoken: deque = deque(maxlen=MAX_SPOKEN)
        # 最近选过的动作（算新鲜度用）
        self._recent_actions: deque = deque(maxlen=30)
        # 每个动作上次做是什么时候（新鲜度按时间衰减）
        self._last_done: Dict[str, float] = {}

    # ==================================================================
    # 感知
    # ==================================================================
    def sense(self, user_text: str = "") -> SensoryBuffer:
        """生成一帧感官。数值由环境与生理共同决定，不是纯随机。"""
        e = self.env
        amb = e.ambient
        r = self.rng
        asleep = self.memory.is_asleep

        # 视觉：亮度来自环境光照 × 昼夜 × 睡眠
        bright = _c(amb.get("lighting", 0.6))
        bright += r.uniform(-0.04, 0.04)
        if asleep:
            bright *= 0.15
        bright = max(0.0, min(1.0, bright))

        # 可见地标（按距离）
        objs = []
        for lm in e.visible(self.pos, max_dist=6.0):
            item = {"name": lm.name, "label": lm.label, "kind": lm.kind,
                    "distance": round(lm.distance_to(self.pos), 2)}
            if lm.kind in ("seat", "bed"):
                item["has_seat"] = True
            if lm.kind == "equipment" and "ac" in lm.name:
                item["has_water"] = True
            if lm.name in ("water_cooler", "tap", "fountain"):
                item["has_water"] = True
            if lm.name in ("snack", "food", "desk") and "food" in lm.name:
                item["has_food"] = True
            objs.append(item)

        # 听觉：天气底噪 + 环境声 + 用户说话
        base_db = {"sunny": 35.0, "cloudy": 33.0, "rainy": 48.0,
                   "windy": 52.0, "snowy": 28.0, "foggy": 30.0,
                   "indoor": 30.0}.get(str(amb.get("weather")), 32.0)
        src = "none"
        db = base_db + r.uniform(-4.0, 4.0)
        if user_text:
            db = max(db, 55.0 + r.uniform(-5.0, 5.0))
            src = "human"
        elif "windy" in str(amb.get("weather")):
            src = "wind"
        elif "rainy" in str(amb.get("weather")):
            src = "rain"

        # 触觉：坐下有压力，手里拿到东西有压力
        near = e.nearest(self.pos, 1.2)
        pressure = 2.5 if near else 0.5
        pressure += r.uniform(-0.3, 0.3)
        temp_c = _f(amb.get("temperature"), 22.0) + 12.0 + r.uniform(-1.0, 1.0)
        if near and near.kind == "equipment":
            temp_c += 8.0                      # 机柜是热的
        vib = abs(r.uniform(-6.0, 6.0)) + (55.0 if src == "wind" else 8.0)

        h = self.homeo.state
        buf = SensoryBuffer(
            vision=Vision(brightness=bright, objects_detected=objs,
                          scene_type=e.scene_type),
            auditory=Auditory(loudness_db=max(15.0, min(90.0, db)),
                              sound_source=src,
                              distance_estimate=3.0 if user_text else 5.0),
            tactile=Tactile(pressure_kpa=max(0.0, min(130.0, pressure)),
                            temperature_celsius=temp_c,
                            vibration_freq_hz=max(0.0, min(120.0, vib)),
                            material=(near.label if near else "unknown")),
            olfactory=Olfactory(
                scent=(e.sensory_smells[0] if e.sensory_smells else "none"),
                intensity=0.05 + (0.2 if asleep else 0.0)),
            gustatory=Gustatory(taste="none", intensity=0.0),
            proprioception=Proprioception(
                student_state=self.state, position=self.pos,
                hip_angle=(90.0 if self.state == "sitting" else 0.0),
                knee_angle=(90.0 if self.state == "sitting" else 0.0)),
            interoception=Interoception(
                hunger=h.hunger, thirst=h.thirst, fatigue=h.muscle_fatigue,
                pain=h.pain_level, temperature=h.core_temp,
                heart_rate=h.heart_rate),
        )
        return buf

    # ==================================================================
    # 注意力显著性（★ 恢复第3代丢掉的那个公式）
    # ==================================================================
    def select_attention(self, s: SensoryBuffer,
                         h: Dict[str, float]) -> Tuple[str, float, Dict[str, float]]:
        """6+1 通道显著性打分。

        第3代只剩 `brightness / dB/80 / (hunger+thirst+pain) / 0.3` 四个数比大小，
        于是"饿了会注意食物""渴了会注意水源"这些行为全丢了。
        这里恢复第2代的完整公式，并补上第3代的 interoception 通道。
        """
        sal: Dict[str, float] = {}

        # ---- 视觉 ----
        v = s.vision
        sc = SALIENCY_BASE["vision"] + 0.10 * len(v.objects_detected)
        if abs(len(v.objects_detected) - self._prev_vision_count) > 1:
            sc += 0.30                                  # 画面变化大 → 更值得看
        if _f(h.get("hunger")) > 0.6 and any(
                o.get("has_food") for o in v.objects_detected):
            sc += 0.40                                  # 饿了会注意食物
        if _f(h.get("thirst")) > 0.5 and any(
                o.get("has_water") for o in v.objects_detected):
            sc += 0.40                                  # 渴了会注意水源
        sal["vision"] = sc
        self._prev_vision_count = len(v.objects_detected)

        # ---- 听觉 ----
        a = s.auditory
        sc = SALIENCY_BASE["auditory"] + 0.10 * (a.loudness_db / 50.0)
        if a.sound_source == "human":
            sc += 0.40                                  # 有人说话最值得听
        elif a.sound_source in ("rain", "wind"):
            sc += 0.05
        sal["auditory"] = sc

        # ---- 触觉 ----
        sal["tactile"] = (0.60 if s.tactile.pressure_kpa > 1.0
                          else SALIENCY_BASE["tactile"])

        # ---- 本体感觉 ----
        sal["proprioception"] = (0.50
                                 if s.proprioception.student_state
                                 != self._prev_state
                                 else SALIENCY_BASE["proprioception"])

        # ---- 嗅觉 / 味觉 ----
        sal["olfactory"] = SALIENCY_BASE["olfactory"] + \
            0.3 * _f(s.olfactory.intensity)
        sal["gustatory"] = SALIENCY_BASE["gustatory"] + \
            0.3 * _f(s.gustatory.intensity)

        # ---- 内感受（第3代新增：身体不适本身会抢注意力）----
        drive = (_f(h.get("hunger")) * 0.5 + _f(h.get("thirst")) * 0.5
                 + _f(h.get("pain_level")) * 0.8)
        sal["interoception"] = 0.10 + 0.6 * min(1.0, drive)

        best = max(sal, key=sal.get)
        # 归一化成 0..1 的"注意力强度"
        level = min(1.0, sal[best] / 1.2)
        return best, level, sal

    # ==================================================================
    # 反射（★ 恢复第3代丢掉的三条判据）
    # ==================================================================
    def check_reflex(self, s: SensoryBuffer, h: Dict[str, float]) -> str:
        """疼痛 / 强压 / 强光 / 极端温度 → 不经思考直接缩回。"""
        t = s.tactile
        if t.temperature_celsius > REFLEX_TEMP_C:
            return "太烫"
        if t.pressure_kpa > REFLEX_PRESSURE_KPA:
            return "被压住"
        if _f(h.get("pain_level")) > REFLEX_PAIN:
            return "太疼"
        if s.vision.brightness > REFLEX_BRIGHTNESS:
            return "晃眼"
        return ""

    # ==================================================================
    # 决策
    # ==================================================================
    def decide(self, s: SensoryBuffer, now: float) -> str:
        """决定动作计划。

        优先级：睡眠 > 反射 > 求生（吃/喝/躲痛）> EFE 主动推理 > 兜底
        """
        h = self.homeo.state_dict

        # 睡眠中：只有醒来这一件事
        if self.memory.is_asleep:
            return "sleep"

        # 反射优先于一切思考
        reason = self.check_reflex(s, h)
        if reason:
            self._last_reflex = reason
            self.memory.working.log("Reflex", "反射触发：%s" % reason)
            return "reflex_withdraw"

        # 极端睡眠压力
        if _f(h.get("sleep_pressure")) > 0.90 and \
                _f(h.get("central_fatigue")) > 0.70:
            return "sleep"

        # ★ EFE 主动推理（前额叶，节流）
        if (now - self._last_prefrontal) >= PREFRONTAL_MIN_INTERVAL:
            self._last_prefrontal = now
            allowed = ["do_nothing", "relax", "sit_down",
                       "look_at_board", "look_window", "look_door",
                       "eat_snack", "drink_water", "sleep", "stand_up"]
            # 地标在附近才允许"走过去"
            if self._find_landmark(has_seat=True):
                allowed += ["move_to_seat"]
            if self._find_landmark(has_water=True):
                allowed += ["move_to_water"]
            # ★ "开口"也是一个候选动作 —— 和看窗外、去喝水一视同仁，
            #   由 EFE 决定要不要说。不是定时器逼她说的。
            if (not self.memory.is_asleep
                    and (now - self._last_spoke) >= SPEAK_MIN_GAP):
                allowed.append("speak")
            # "多久没和人交流"取**她上次开口**与**上次被搭话**里更近的那个 ——
            # 刚被问过就不用再去确认对方还在不在。
            social_gap = max(0.0, now - max(self._last_spoke,
                                            self._last_user_input))
            self.efe = self.fep.expected_free_energy(
                h, allowed=allowed, social_gap=social_gap,
                # 人设差异：她给"确认对方还在"这件事估多少价
                epistemic_scale=self.speak_gain(),
                novelty=self._novelty(now))
            # ★ 已经决定要做的事，就**做一会儿**再重新考虑。
            #   每 4 秒重挑一次的话，她会永远在"看窗→看门→看黑板"之间跳 ——
            #   实测 look_window 占 51.6%，不是因为想看，是因为没有延续性。
            #   真实的注意力是会驻留的（不随意注意的抑制返回）。
            if now < self._engage_until:
                return self.plan or "relax"

            plan = self.efe.action
            # ★ 基底核门控：否决权（第3代丢了，这里恢复）
            plan = self._basal_gate(plan, h)
            self._note_action(plan, now)
            # 说出口是一次性的，但也要驻留一小段 ——
            # ★ 不驻留的话 `self.plan` 会一直粘在 "speak" 上：
            #   节流块每 4 秒才进一次，中间那三拍走的是"沿用上次计划"的兜底，
            #   于是 decide() 的 SPEAK_MIN_GAP 门控根本没机会生效，
            #   实测会连着 4 拍连说 4 句。
            self._engage_until = now + ENGAGE_SECONDS.get(plan, 12.0)
            return plan

        # ★ 前额叶节流中：沿用上一次的计划。
        #   这个兜底 `return` 一度被我编辑时挤进了 `_note_action()` 里，
        #   于是非决策 tick 的 decide() 返回 None，
        #   而 `None or "relax"` 也一起没了 —— 实测 75% 的 tick 计划是空的。
        return self.plan or "relax"

    # ---- 动作新鲜度 -------------------------------------------------
    # ★ 为什么需要：认知价值原本是固定常数，于是"看一成不变的窗外"
    #   每 4 秒都能拿到同样的 0.08 —— 实测她 98.7% 的时间都在看窗。
    #   真实的主动推理里，同一件事看第二遍的信息量是递减的。
    NOVELTY_HALFLIFE = 150.0     # 信息量的半衰期（真实秒）
    NOVELTY_FLOOR = 0.15         # 衰减到底就是它
    REDUNDANT_SCALE = 0.10       # "已经在那儿了"时信息量降到这个比例
    REACHED_DIST = 1.2           # 到这个距离内算"已经在那儿了"

    def _novelty(self, now: float) -> Dict[str, float]:
        """每个候选动作的"新鲜度"（0–1）。刚做过的低，久没做的回升。

        ★ 用**时间**衰减，不是"最近 N 次决策里的占比"。
          按占比算的时候窗口是 30 次决策 —— 而她每 20–60 秒才决策一次，
          等于记了 20 分钟。于是"刚看过窗外"几乎不占份量，
          她就会一直重复同一批动作（实测 look_window 稳在 27%）。
          信息量应该随时间回升，那才是"看久了会想再看看"的意思。
        """
        out: Dict[str, float] = {}
        for a in fep_mod.CANDIDATE_ACTIONS:
            if a == "speak":
                continue    # speak 的价值已经由 social_gap 表达
            last = self._last_done.get(a)
            if last is None:
                out[a] = 1.0
            else:
                age = max(0.0, now - last)
                nov = 0.5 ** (age / self.NOVELTY_HALFLIFE)
                out[a] = max(self.NOVELTY_FLOOR, nov)
        # ★ 已经在座位/水源旁边时，"走过去"不产生任何新信息。
        #   不打这个折扣的话她会一遍遍走去自己已经在的地方。
        for act, lm in (("move_to_seat", self._find_landmark(has_seat=True)),
                        ("move_to_water", self._find_landmark(has_water=True))):
            if lm is None:
                continue
            if lm.distance_to(self.pos) <= self.REACHED_DIST:
                out[act] = min(out.get(act, 1.0), self.REDUNDANT_SCALE)
        return out

    def _note_action(self, plan: str, now: float = 0.0) -> None:
        if not plan:
            return              # 不该发生；发生也不要把空值记进新鲜度
        self._last_done[plan] = now
        self._recent_actions.append(plan)
        if len(self._recent_actions) > 30:
            self._recent_actions.pop(0)

    def _basal_gate(self, plan: str, h: Dict[str, float]) -> str:
        """基底核门控：累/痛的时候不许做高耗动作，极饿时强制去觅食。

        第3代把这个逻辑降级成"只影响 SNN 输入"，不再能否决动作，
        于是累到 0.9 还会站起来走。这里恢复否决权。
        """
        fatigue = _f(h.get("muscle_fatigue"))
        pain = _f(h.get("pain_level"))
        hunger = _f(h.get("hunger"))
        high_cost = {"stand_up", "move_to_seat", "move_to_water"}
        if not plan:
            return "relax"      # 防御：空计划不该往下传

        if (fatigue > 0.8 or pain > 0.5) and plan in high_cost:
            self.memory.working.log(
                "Basal", "否决 %s（疲劳 %.2f 疼痛 %.2f）→ relax"
                % (plan, fatigue, pain))
            return "relax"
        if hunger > 0.85 and plan not in ("eat_snack", "move_to_seat"):
            self.memory.working.log("Basal", "极饿，强制觅食（原计划 %s）" % plan)
            return "move_to_seat" if self._find_landmark(has_seat=True) \
                else "eat_snack"
        if _f(h.get("thirst")) > 0.85 and plan not in ("drink_water",
                                                       "move_to_water"):
            return "move_to_water" if self._find_landmark(has_water=True) \
                else "drink_water"
        return plan

    # ==================================================================
    # 动态寻路（★ 第3代改成硬编码地标名，这里恢复按距离找）
    # ==================================================================
    def _find_landmark(self, *, has_seat: bool = False,
                       has_water: bool = False,
                       kind: str = "") -> Optional[geo.Landmark]:
        best, best_d = None, 1e9
        for lm in self.env.landmarks:
            ok = True
            if has_seat and lm.kind not in ("seat", "bed"):
                ok = False
            if has_water and lm.name not in ("water_cooler", "tap", "fountain",
                                             "precision_ac") \
                    and "water" not in lm.name:
                ok = False
            if kind and lm.kind != kind:
                ok = False
            if not ok:
                continue
            d = lm.distance_to(self.pos)
            if d < best_d:
                best, best_d = lm, d
        return best

    def _find_by_kind(self, kind: str) -> Optional[geo.Landmark]:
        """按类别找最近的地标（look_at_board / look_window / look_door 用）。"""
        want = {"board": ("board",), "window": ("window",),
                "door": ("door",)}.get(kind, (kind,))
        best, best_d = None, 1e9
        for lm in self.env.landmarks:
            if lm.kind not in want:
                continue
            d = lm.distance_to(self.pos)
            if d < best_d:
                best, best_d = lm, d
        return best

    # ==================================================================
    # 执行动作
    # ==================================================================
    def execute(self, plan: str, dt: float = 1.0) -> Dict[str, Any]:
        """执行一个计划，返回本步的动作报告。"""
        acts = PLAN_ACTIONS.get(plan, [])
        log: List[str] = []
        motor_intensity = 0.0

        for act in acts:
            op = act.get("op")
            if op == "move_to":
                target = None
                if act.get("landmark"):
                    target = self._find_by_kind(act["landmark"])
                elif act.get("has_seat"):
                    target = self._find_landmark(has_seat=True)
                elif act.get("has_water"):
                    target = self._find_landmark(has_water=True)
                if target is None:
                    log.append("找不到目标地标")
                    continue
                moved = self._step_toward(target.pos,
                                          RUN_SPEED if plan == "run"
                                          else MOVE_SPEED)
                motor_intensity = max(motor_intensity, 0.30)
                log.append("走向 %s（剩余 %.2f 米）"
                           % (target.label, target.distance_to(self.pos)))
                if moved:
                    self.state = "walking"
            elif op == "sit_down":
                self.state = "sitting"
                log.append("坐下")
            elif op == "stand_up":
                self.state = "standing"
                log.append("站起来")
            elif op == "eat_snack":
                self.homeo.eat_snack()
                motor_intensity = max(motor_intensity, 0.05)
                log.append("吃了点东西")
                self.memory.working.push_message("系统", "（吃了一份零食）")
            elif op == "drink_water":
                self.homeo.drink_water()
                motor_intensity = max(motor_intensity, 0.05)
                log.append("喝了水")

        self.plan = plan
        if not acts:
            self.state = self.state if self.state == "sitting" else "standing"
        return {"plan": plan, "actions": log,
                "motor_intensity": motor_intensity, "state": self.state}

    def _step_toward(self, target: Tuple[float, float], speed: float) -> bool:
        tx, ty = target
        x, y = self.pos
        dx, dy = tx - x, ty - y
        dist = math.hypot(dx, dy)
        if dist <= ARRIVE_EPS:
            return False
        step = min(speed, dist)
        x += dx / dist * step
        y += dy / dist * step
        self.pos = self.env.clamp(x, y, margin=0.25)
        return True

    # ==================================================================
    # 主循环
    # ==================================================================
    def tick(self, user_text: str = "", dt: float = 1.0,
             wall_now: Optional[float] = None) -> Dict[str, Any]:
        """推进一瞬间。返回一帧状态。"""
        with self._lock:
            now = wall_now if wall_now is not None else time.time()
            self.tick_count += 1
            self.sim_clock = (self.sim_clock + dt / 60.0) % 24.0

            # ---- 1) 感知 ----
            sensory = self.sense(user_text)

            # ---- 2) 注意力 ----
            h0 = self.homeo.state_dict
            att, level, sal = self.select_attention(sensory, h0)
            self.attention, self.attention_level = att, level
            self._prev_state = sensory.proprioception.student_state

            # ---- 3) 编码 + SNN ----
            mem_hint = self.memory.load_factor()
            if self.snn is not None and self._policy != "pure_llm":
                stim = self.encoder.encode_all(
                    sensory, h0, att, self.plan, mem_hint, level,
                    self.last_rates)
                self.last_rates = self.snn.step(stim)

            # ---- 4) FEP ----
            self.fep.step(self.last_rates, h0)

            # ---- 5) 情绪（SNN + 生理共同决定）----
            self._update_emotion(h0)

            # ---- 6) 决策 ----
            plan = self.decide(sensory, now)

            # ---- 7) 执行 ----
            if self.memory.is_asleep:
                report = {"plan": "sleep", "actions": [], "motor_intensity": 0.0,
                          "state": self.state}
            else:
                report = self.execute(plan, dt)

            # ---- 8) 生理推进 ----
            if self._homeostasis_enabled:
                # ★ dt 是**模拟秒**，必须乘以 60。
                #   `tick(dt=1.0)` 的 1.0 = **1 模拟分钟**
                #   （WorldClock：1 真实秒 = 1 模拟分钟），
                #   而 `homeo.update()` 收的是模拟秒。
                #
                #   不乘 60 的后果：生理慢 **60 倍** ——
                #   实测一整天（1440 拍）睡压只从 0.20 升到 0.22，
                #   饥饿/口渴完全不动，于是"饿了会自己去吃"永不发生。
                #   那正是"内稳态像假的"的根因（值在动，但动得看不出来）。
                #
                #   乘 60 的前提：`homeo.update()` 里所有"向定点指数趋近"
                #   都必须走 `_approach(k, dt)`（dt 无关系数）。
                #   否则 `0.05 * 60 = 3.0` 会振荡发散，把体温推到 41°C。
                self.homeo.update(dt=dt * 60.0,
                                  motor_intensity=report["motor_intensity"],
                                  env_temp=_f(self.env.ambient.get("temperature"),
                                              22.0),
                                  asleep=self.memory.is_asleep)

            # ---- 9) 睡眠 / 梦境 ----
            self._update_sleep(now, dt)

            # ---- 9b) 主动发言 ----
            # plan 是 decide() 用 EFE 选出来的；如果她权衡后选了 speak，
            # 这里才真的开口。不是定时器。
            if user_text:
                self._last_user_input = now
            self._maybe_speak_up(now)

            # ---- 10) 记忆 ----
            if not self.memory.is_asleep and report["actions"]:
                self.memory.append_episode(
                    "；".join(report["actions"]), plan=plan,
                    attention=att, valence=self.valence,
                    arousal=self.arousal, homeo=self.homeo.state)

            return self.frame(sensory, sal)

    # ------------------------------------------------------------------
    def _update_emotion(self, h: Dict[str, float]) -> None:
        """情绪由 SNN 的杏仁核发放率与生理共同决定。"""
        amy = self.last_rates.get("amygdala", 0.2)
        syn = self.last_rates.get("association", 0.2)
        self.arousal = _c(0.4 * amy + 0.3 * _f(h.get("adrenaline")) / 2.0
                          + 0.3 * syn)
        # 效价：舒服为正，难受为负
        v = (0.35 * (1.0 - _f(h.get("hunger")))
             + 0.35 * (1.0 - _f(h.get("pain_level")))
             + 0.30 * (1.0 - _f(h.get("muscle_fatigue")))
             ) - 0.5
        self.valence = max(-1.0, min(1.0, v))

    def _update_sleep(self, now: float, dt: float = 1.0) -> None:
        h = self.homeo.state
        if self.memory.is_asleep:
            # ★ 睡眠计时由 dt 驱动（模拟秒），和生理同一套时钟。
            if self.memory.tick_sleep(dt * 60.0):
                w = self.memory.wake_up(h)
                self.homeo.state.sleep_pressure = max(
                    0.0, h.sleep_pressure - 0.55)
                if w.get("memory"):
                    self.memory.working.log("Sleep", w["memory"])
            else:
                self.memory.update_dream(h)
        else:
            if self.homeo.state.sleep_pressure > mem_mod.SLEEP_THRESHOLD \
                    and self.plan == "sleep":
                self.memory.enter_sleep(h)

    # ------------------------------------------------------------------
    def frame(self, sensory: Optional[SensoryBuffer] = None,
              saliency: Optional[Dict[str, float]] = None) -> Dict[str, Any]:
        """给前端的一帧。字段与旧版 BRIDGE_JS 的契约对齐。"""
        h = self.homeo.state
        d = self.homeo.state_dict
        e = self.env
        fepd = self.fep.to_dict()
        return {
            "name": self.name,
            "charId": self.life_id,
            "lifeId": self.life_id,
            "who": self.persona.who,
            "system_prompt": self.persona.system_prompt,
            "homeo": d,
            "fep": fepd,
            "emo": {"v": round(self.valence, 4),
                    "a": round(self.arousal, 4),
                    "label": self.homeo.mood_label},
            "rates": dict(self.last_rates),
            "snn_rates": dict(self.last_rates),
            "pos": [round(self.pos[0], 3), round(self.pos[1], 3)],
            "position": {"x": round(self.pos[0], 3),
                         "y": round(self.pos[1], 3)},
            "state": self.state,
            "plan": self.plan,
            "timeOfDay": self.time_of_day,
            "time_of_day": self.time_of_day,
            "weather": str(e.ambient.get("weather", "sunny")),
            "lighting": round(_f(e.ambient.get("lighting"), 0.6), 3),
            "temperature_ambient": round(
                _f(e.ambient.get("temperature"), 22.0), 1),
            "attention": self.attention,
            "attention_level": round(self.attention_level, 4),
            "attention_saliency": ({k: round(v, 4)
                                    for k, v in (saliency or {}).items()}),
            "asleep": self.memory.is_asleep,
            "asleep_stage": self.memory.sleep_stage,
            "sleep_remaining": round(self.memory.sleep_remaining(), 1),
            "dream": self.memory.dream.to_dict()
            if self.memory.dream.content else None,
            "neuro": {"da": round(h.da, 3), "ne": round(h.ne, 3),
                      "ht5": round(h.ht5, 3), "ach": round(h.ach, 3)},
            "action_scores": {k: round(v, 4)
                              for k, v in self.efe.scores.items()},
            "efe": self.efe.to_dict(),
            "mood": self.homeo.mood(),
            "critical": self.homeo.is_critical(),
            "homeostasis_enabled": self._homeostasis_enabled,
            "policy": self._policy,
            "env": e.to_client(),
            "memory": self.memory.stats(),
            "clock": round(self.sim_clock, 3),
            "tick": self.tick_count,
        }

    # ------------------------------------------------------------------
    @staticmethod
    def _infer_id(name: str) -> str:
        """没被 Runtime 登记时，从名字推算一个 id。"""
        return "kaka" if ("渐进" in str(name) or "卡" in str(name)) \
            else "default"

    @property
    def char_id(self) -> str:
        """给前端用的角色 id。等同于 `life_id`。"""
        return self.life_id

    @property
    def time_of_day(self) -> str:
        h = self.sim_clock
        if h < 5 or h >= 20:
            return "night"
        if h < 11:
            return "morning"
        if h < 17:
            return "afternoon"
        return "evening"

    # ------------------------------------------------------------------
    # 对话
    # ------------------------------------------------------------------
    def reply(self, text: str, *, use_llm: bool = False,
              llm_call: Optional[Any] = None) -> persona_mod.Reply:
        """回应一句话。默认走本地人格引擎，有 LLM 时可升级。"""
        h = self.homeo.state_dict
        h["valence"] = self.valence
        h["arousal"] = self.arousal

        self.memory.working.push_dialogue("user", text)
        self.memory.working.push_message("用户", text)

        if self.memory.is_asleep:
            # 睡着时她不会好好回话
            return persona_mod.Reply(
                text="……（她睡着了，没有回应）", tone="silent",
                silent=True, char_ms=40, gap_ms=800)

        rep = self.persona.compose(
            h, text, surprise=self.fep.surprise,
            pre_react=True)

        # 跨角色状态感知：偶尔插一句关心对方的话
        other = self._other_homeo
        if not rep.silent and other is not None and self.rng.random() < 0.25:
            line = self.persona.other_status_line(other, self.env.to_spec())
            if line:
                rep.text = (rep.text + " " + line).strip()

        if rep.silent:
            reason = "太累" if _f(h.get("sleep_pressure")) > 0.6 else "不想说"
            self.memory.push_unspoken("（想回一句，但没开口。）", reason)
        else:
            self.memory.working.push_dialogue("char", rep.text, self.name)
            # 有情绪波动的事才值得记住
            if abs(self.valence) > 0.25 or self.fep.surprise > 0.5:
                self.memory.append_episode(
                    "对方说「%s」，我回了「%s」" % (text[:30], rep.text[:30]),
                    plan=self.plan, attention=self.attention,
                    valence=self.valence, arousal=self.arousal,
                    homeo=self.homeo.state)
        return rep

    _other_homeo: Optional[Any] = None

    # ==================================================================
    # 主动发言
    # ------------------------------------------------------------------
    # ★ 这不是"定时触发"，而是**她权衡之后的选择**：
    #   `speak` 是 EFE 的候选动作之一（见 core/fep.py），
    #   EFE 三项里：
    #     · complexity 0.12  —— 开口有代价（要组织语言、可能被无视）
    #     · epistemic       —— 随"多久没交流"上升（对方还在不在的不确定）
    #     · pragmatic       —— 说话本身不改变生理目标，所以是 0
    #   `decide()` 把它和前额叶的其他候选（看窗外、坐下、去喝水）一起比，
    #   谁 EFE 最小就做谁。所以她是**想过之后决定开口**。
    #
    #   人设差异体现在两处：
    #     · `speak_gain`：她给"确认对方还在"这件事的估价
    #       （渐进酱 1.0，白子 0.62 —— 白子没那么需要确认）
    #     · `silence_chance`：极累/发烧/低血糖时干脆不说
    # ==================================================================
    SPEAK_GAIN = {"渐进酱": 1.0, "砂狼白子": 0.62}

    def speak_gain(self) -> float:
        """她给"主动开口"这件事的估价。"""
        return self.SPEAK_GAIN.get(self.name, 0.8)

    def speak_up(self, now: Optional[float] = None) -> Optional[persona_mod.Reply]:
        """她**自己**开口说一句。不想说就返回 None。

        与 `reply()` 的区别：这个没有人在问她，是她主动搭话。
        """
        h = self.homeo.state_dict
        h["valence"] = self.valence
        h["arousal"] = self.arousal

        # 睡着的人不会突然说话
        if self.memory.is_asleep:
            return None

        rep = self.persona.idle_line(h)
        if rep is None:
            return None

        # 跨角色状态感知：自己也聊到对方
        other = self._other_homeo
        if other is not None and self.rng.random() < 0.2:
            line = self.persona.other_status_line(other, self.env.to_spec())
            if line:
                rep.text = (rep.text + " " + line).strip()

        self.memory.working.push_dialogue("char", rep.text, self.name)
        self.memory.working.push_message(self.name, rep.text)
        # 主动说的话也进情景记忆（重要度略低，因为是自发的）
        self.memory.append_episode(
            "我随口说了句「%s」" % rep.text[:30],
            plan=self.plan, attention=self.attention,
            valence=self.valence, arousal=self.arousal,
            homeo=self.homeo.state)
        return rep

    def _maybe_speak_up(self, now: float) -> None:
        """她**决定**开口时才真正说话。

        ★ 判断依据是 `decide()` 选出来的 plan —— 也就是说
          "要不要说话"已经由 EFE 权衡过了，这里只负责执行。

        ★★ 但**门控必须在这一点**，不能在 `decide()` 里。
          `decide()` 有 4 秒节流，而且计划会驻留一段时间；
          `tick()` 却是每拍都调这里。把间隔判断放在 `decide()` 里时，
          计划一旦是 "speak" 就会在整个驻留期内每拍都触发 ——
          实测连着 20 拍说了 20 句。
        """
        if self.plan != "speak":
            return
        # 说完一次就重新等；驻留期内不会重复开口
        if now < self._speak_ready_at:
            return
        rep = self.speak_up(now)
        self._last_spoke = now
        self._speak_ready_at = now + SPEAK_MIN_GAP
        if rep is not None:
            # ★ 记下说话节奏，前端打字机效果要用它。
            #   漏了 char_ms 前端只能吃默认值，"白子慢、渐进酱快"的差别就没了。
            self._spoken.append({"t": now, "text": rep.text,
                                 "tone": rep.tone,
                                 "charMs": getattr(rep, "char_ms", 22),
                                 "gapMs": getattr(rep, "gap_ms", 400)})

    def recent_spoken(self, limit: int = 20) -> List[Dict[str, Any]]:
        """她最近主动说过的话（给界面用）。"""
        with self._lock:
            return list(self._spoken)[-limit:]

    def set_other(self, other_homeo: Any) -> None:
        """注册另一个角色的生理状态（跨角色感知用）。"""
        self._other_homeo = other_homeo

    # ------------------------------------------------------------------
    # 系统提示词（给 LLM 的完整上下文）
    # ------------------------------------------------------------------
    def build_state_brief(self, user_text: str = "") -> str:
        """这段时间她的"内心状态"摘要 —— 喂给大模型。

        第2代有 7 条内稳态语言规则，第3代只剩状态简述。
        这里两层都做：既有数值简报，也有"生理怎么影响说话"的规则说明。
        """
        h = self.homeo.state
        parts = [
            self.persona.system_prompt,
            "",
            self.homeo.describe_for_llm(),
            self.env.describe_for_llm(),
        ]
        fepd = self.fep.to_dict()
        parts.append("【自由能】F=%.3f ΔF=%+.3f 惊奇=%.3f"
                     % (fepd["free_energy"], fepd["fe_delta"],
                        fepd["surprise"]))
        parts.append("【情绪】%s（效价 %+.2f，唤醒 %.2f）"
                     % (self.homeo.mood_label, self.valence, self.arousal))
        parts.append("【注意力】%s（强度 %.2f）" % (self.attention,
                                                  self.attention_level))
        parts.append("【当前计划】%s · 姿态 %s · 位置 (%.1f, %.1f)"
                     % (self.plan, self.state, self.pos[0], self.pos[1]))
        top = sorted(self.last_rates.items(), key=lambda kv: -kv[1])[:3]
        parts.append("【最活跃脑区】" + "、".join(
            "%s %.2f" % (snn_mod.REGION_MAP[k].label, v) for k, v in top))

        # ★ 生理 → 语言的规则（第2代有、第3代丢了）
        rules = []
        if h.hunger > 0.6:
            rules.append("你有点饿，回话会更短、更直接")
        if h.thirst > 0.5:
            rules.append("你口渴，注意力容易飘向水源")
        if h.muscle_fatigue > 0.6:
            rules.append("你身体很累，不想做大动作")
        if h.sleep_pressure > 0.7:
            rules.append("你很困——可以真的不回")
        if h.adrenaline > 0.5:
            rules.append("你处于应激状态，语速会变快")
        if h.pain_level > 0.3:
            rules.append("你在疼，不太想说话")
        if rules:
            parts.append("【生理对说话的影响】")
            parts.extend("  · " + r for r in rules)

        mem = self.memory.describe_for_llm(user_text)
        if mem:
            parts.append(mem)

        # ★★ 说话方式（放在**最末尾** —— 提示词里最后出现的要求权重最高）。
        #    用户反馈三条：① 老拿括号写动作 ② 一次说一大段 ③ 不像真人聊天。
        #    这里明确刹车：短、口语、不要括号动作、不要复述数值。
        parts.append(
            "【怎么说话 —— 这一条优先于上面所有设定】\n"
            "· 像在聊天软件上发消息：一次 1～2 句，通常不超过 40 个字。"
            "别写小作文，也别一次把话说完。\n"
            "· **不要写括号里的动作、神态、心理描写**"
            "（例如「（歪头）」「（笑）」「（轻轻叹气）」都不行）。"
            "真需要动作时，用一句白描写进正文，而且只在必要时。\n"
            "· 不要复述上面给你的数值（温度 / 心率 / 自由能 / 脑区…），"
            "把它们变成感受和口气。\n"
            "· 别每句都反问「你呢」；轮到你说话就自然接一句、或者只回应情绪。\n"
            "· 保持人物设定：称呼、口癖、语气都像她本人 —— 但别演，"
            "就像你真的在打字。"
        )
        return "\n".join(p for p in parts if p)

    # ------------------------------------------------------------------
    # 存档
    # ------------------------------------------------------------------
    def snapshot(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "life_id": self.life_id,
            "char_id": self.life_id,
            "pos": list(self.pos),
            "state": self.state,
            "plan": self.plan,
            "attention": self.attention,
            "valence": round(self.valence, 4),
            "arousal": round(self.arousal, 4),
            "tick": self.tick_count,
            "sim_clock": round(self.sim_clock, 4),
            "homeo": self.homeo.state.to_dict_full(),
            "memory": self.memory.to_dict(),
            "env": self.env.to_spec(),
            "snn": self.snn.save() if self.snn else None,
            "policy": self._policy,
            "homeostasis_enabled": self._homeostasis_enabled,
            "saved_at": time.time(),
        }

    def restore(self, d: Any) -> bool:
        if not isinstance(d, dict):
            return False
        with self._lock:
            # ★ 名字与人格必须显式还原。
            #   DigitalLife.__init__ 默认就是白子，不还原的话**两个角色读档后
            #   会双双变成白子**（实测踩过：kaka 恢复成了砂狼白子）。
            nm = str(d.get("name") or "").strip()
            if nm and nm != self.name:
                self.name = nm
                self.persona = persona_mod.PersonaEngine(nm, self.rng)
            lid = str(d.get("life_id") or d.get("char_id") or "").strip()
            if lid:
                self.life_id = lid
            elif not self.life_id:
                self.life_id = self._infer_id(self.name)
            if d.get("env"):
                self.env = geo.build_from_spec(d["env"],
                                               source=d["env"].get("source",
                                                                   "user"))
            if d.get("homeo"):
                self.homeo.state = homeo_mod.State.from_dict(d["homeo"])
            if d.get("memory"):
                self.memory.load_dict(d["memory"])
            if self.snn and isinstance(d.get("snn"), dict):
                self.snn.load(d["snn"])
            p = d.get("pos")
            if isinstance(p, list) and len(p) >= 2:
                self.pos = self.env.clamp(float(p[0]), float(p[1]), margin=0.2)
            for k, cast in (("state", str), ("plan", str),
                            ("attention", str)):
                if d.get(k):
                    setattr(self, k, cast(d[k]))
            for k in ("valence", "arousal", "sim_clock"):
                if isinstance(d.get(k), (int, float)):
                    setattr(self, k, float(d[k]))
            if isinstance(d.get("tick"), int):
                self.tick_count = d["tick"]
            if d.get("policy"):
                self._policy = str(d["policy"])
            if "homeostasis_enabled" in d:
                self._homeostasis_enabled = bool(d["homeostasis_enabled"])
            return True

    # ------------------------------------------------------------------
    def set_environment(self, env: geo.Environment) -> None:
        """换环境。位置会夹进新房间，避免跑到墙外。"""
        with self._lock:
            self.env = env
            self.pos = env.clamp(self.pos[0], self.pos[1], margin=0.3)
            self.memory.append_episode("环境变了：%s" % env.scene_name,
                                       plan="look_window", importance=0.5,
                                       tags=["env"])
            self.memory.working.log("Env", "环境切换 → %s" % env.scene_name)

    def set_policy(self, policy: str) -> None:
        """hybrid_snn 或 pure_llm（第2代有、第3代丢了）。"""
        self._policy = policy if policy in ("hybrid_snn", "pure_llm") \
            else "hybrid_snn"
        self.memory.working.log("System", "策略切换 → %s" % self._policy)

    def set_homeostasis(self, enabled: bool) -> None:
        self._homeostasis_enabled = bool(enabled)

    def apply_action(self, action: str) -> str:
        """远程动作（第3代有，保留）。"""
        a = str(action or "").strip().lower()
        if a == "sleep":
            self.memory.enter_sleep(self.homeo.state)
            return "已进入睡眠"
        if a == "wake":
            self.memory.wake_up(self.homeo.state)
            return "已唤醒"
        if a == "eat":
            self.homeo.eat_snack()
            return "吃了点东西"
        if a == "drink":
            self.homeo.drink_water()
            return "喝了水"
        if a == "dream":
            d = self.memory.update_dream(self.homeo.state, force=True)
            return ("梦：%s" % d.content) if d else "她没在睡"
        return "未知动作：%s" % action


def _c(v: Any) -> float:
    """夹到 0..1。"""
    try:
        f = float(v or 0.0)
    except (TypeError, ValueError):
        return 0.0
    return 0.0 if f < 0.0 else (1.0 if f > 1.0 else f)


def _f(v: Any, default: float = 0.0) -> float:
    if isinstance(v, bool):
        return default
    if isinstance(v, (int, float)):
        return float(v)
    return default


__all__ = [
    "DigitalLife", "SensoryBuffer", "SensoryEncoder", "Vision", "Auditory",
    "Tactile", "Olfactory", "Gustatory", "Proprioception", "Interoception",
    "SALIENCY_BASE", "ATTENTION_CHANNELS", "ATTENTION_CHANNELS_FULL",
    "PLAN_ACTIONS", "BASAL_PLANS", "MOTOR_PLANS",
    "REFLEX_TEMP_C", "REFLEX_PRESSURE_KPA", "REFLEX_PAIN", "REFLEX_BRIGHTNESS",
    "PREFRONTAL_MIN_INTERVAL", "MOVE_SPEED", "RUN_SPEED",
]
