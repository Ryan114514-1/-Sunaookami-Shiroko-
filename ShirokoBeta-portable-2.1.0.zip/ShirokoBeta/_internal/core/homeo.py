# -*- coding: utf-8 -*-
"""
Shiroko β —— 内稳态（26 维生理模拟）

这一层是"她真的会累、会饿、会热"的来源。脑区发放率、语言长短、
沉默概率都由它驱动，所以数值必须落在生理合理区间且**稳定**。

标定说明（重要）
----------------
旧版第 2 代是原版，但有几个变量的固定点落在区间外，长期跑会钉在钳位上：

    体温     heat_loss = 0.1·(T−25)  →  平衡点 ≈25.5°C，core_temp 被钉在 35.0
    皮质醇   产生 0.02 / 清除 0.05   →  固定点 0.76，被钉在下限 3.0
    胰高血糖素 清除 0.005            →  钉在 0.0
    血糖     消耗基数 0.05           →  单调爬到上限 11.99
    疲劳     acc = ex·0.05 + 0.01·m² →  自催化，永远饱和
    游离脂肪酸 update() 里根本没更新  →  26 维实际只演化 25 维

本模块采用第 3 代的标定修正版（把上面每一条都修好），并补齐第 2 代有、
第 3 代丢掉的东西：`is_critical()`、`apply_hunger()`、`apply_thirst()`、
9 分类 `Mood`、`get_delta()`。

单位与常值区间见每个字段的注释。
"""

from __future__ import annotations

import math
import random
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

# ----------------------------------------------------------------------
# 26 维字段定义（顺序与前端/备份文件一致，不要随意调整）
# ----------------------------------------------------------------------
@dataclass(frozen=True)
class FieldSpec:
    key: str
    label: str          # 中文名（界面与备份用）
    default: float
    lo: float
    hi: float
    unit: str = ""
    normal: str = ""    # 生理常值区间

    def clamp(self, v: float) -> float:
        return self.lo if v < self.lo else (self.hi if v > self.hi else v)


HOMEOSTATIC_FIELDS: Tuple[FieldSpec, ...] = (
    FieldSpec("glucose", "血糖", 5.0, 2.0, 12.0, "mM", "4.0–6.0"),
    FieldSpec("liver_glycogen", "肝糖原", 100.0, 0.0, 200.0, "g", "60–120"),
    FieldSpec("free_fatty_acids", "游离脂肪酸", 0.5, 0.05, 1.6, "mM", "0.3–0.8"),
    FieldSpec("insulin", "胰岛素", 10.0, 0.0, 60.0, "μU/mL", "5–15"),
    FieldSpec("glucagon", "胰高血糖素", 5.0, 0.0, 40.0, "pg/mL", "3–10"),
    FieldSpec("total_energy_kcal", "可用能量", 2000.0, 1200.0, 2800.0,
              "kcal", "1800–2400"),
    FieldSpec("blood_osmolarity", "血浆渗透压", 290.0, 275.0, 330.0,
              "mOsm/kg", "285–295"),
    FieldSpec("adh", "抗利尿激素", 2.0, 1.0, 12.0, "pg/mL", "1–5"),
    FieldSpec("thirst", "口渴", 0.1, 0.0, 1.0, "", ""),
    FieldSpec("electrolyte_balance", "电解质平衡", 0.0, -0.5, 0.5, "", ""),
    FieldSpec("core_temp", "核心体温", 37.0, 34.0, 41.0, "°C", "36.5–37.5"),
    FieldSpec("skin_temp", "体表温度", 33.0, 28.0, 39.0, "°C", "32–34"),
    FieldSpec("sweating_rate", "出汗率", 0.0, 0.0, 1.0, "", ""),
    FieldSpec("cortisol", "皮质醇", 10.0, 3.0, 45.0, "μg/dL", "5–25"),
    FieldSpec("adrenaline", "肾上腺素", 0.1, 0.0, 2.5, "ng/mL", "0.05–0.5"),
    FieldSpec("noradrenaline", "去甲肾上腺素", 0.2, 0.05, 2.0, "ng/mL",
              "0.1–0.5"),
    FieldSpec("muscle_fatigue", "肌肉疲劳", 0.1, 0.0, 1.0, "", ""),
    FieldSpec("central_fatigue", "中枢疲劳", 0.1, 0.0, 1.0, "", ""),
    FieldSpec("hunger", "饥饿", 0.3, 0.0, 1.0, "", ""),
    FieldSpec("sleep_pressure", "睡眠压力", 0.2, 0.0, 1.0, "", ""),
    FieldSpec("pain_level", "疼痛", 0.0, 0.0, 1.0, "", ""),
    FieldSpec("heart_rate", "心率", 72.0, 40.0, 180.0, "bpm", "60–90"),
    FieldSpec("respiratory_rate", "呼吸频率", 16.0, 6.0, 40.0, "次/分",
              "12–20"),
    FieldSpec("blood_pressure_sys", "收缩压", 120.0, 70.0, 200.0, "mmHg",
              "110–130"),
    FieldSpec("blood_pressure_dia", "舒张压", 80.0, 40.0, 130.0, "mmHg",
              "70–85"),
    FieldSpec("blood_ph", "血液 pH", 7.40, 7.20, 7.60, "", "7.35–7.45"),
)

FIELD_MAP: Dict[str, FieldSpec] = {f.key: f for f in HOMEOSTATIC_FIELDS}
FIELD_KEYS: Tuple[str, ...] = tuple(f.key for f in HOMEOSTATIC_FIELDS)
FIELD_COUNT = len(HOMEOSTATIC_FIELDS)          # 26

# ----------------------------------------------------------------------
# 分组
# ----------------------------------------------------------------------
# 旧版前端有一套分组（`HOMEOSTASIS_GROUPS`，7 组），用于"26 行全量数值"
# 与"高级面板的 26 个滑块"。那份分组有两个问题：
#   · 只有 25 个字段（漏了新加的 `blood_ph`）
#   · `thirst` 在两个组里各出现一次（Fluid 与 Drive），重复计数
# 这里按生理学重新分组，26 个字段**每项恰好属于一组**。
#
# 注意 `thirst` 归到"体液 Fluid"：口渴首先是一个体液渗透压信号，
# "内驱力"那组只留 `hunger`，避免同一个滑块出现两次。
FIELD_GROUPS: Tuple[Tuple[str, str, Tuple[str, ...]], ...] = (
    ("metabolism", "代谢 Metabolism", (
        "glucose", "liver_glycogen", "free_fatty_acids", "insulin",
        "glucagon", "total_energy_kcal")),
    ("fluid", "体液 Fluid", (
        "blood_osmolarity", "adh", "thirst", "electrolyte_balance",
        "blood_ph")),
    ("thermal", "体温 Thermal", (
        "core_temp", "skin_temp", "sweating_rate")),
    ("stress", "应激 Stress", (
        "cortisol", "adrenaline", "noradrenaline")),
    ("fatigue", "疲劳 Fatigue", (
        "muscle_fatigue", "central_fatigue", "sleep_pressure",
        "pain_level")),
    ("cardio", "循环 Cardiovascular", (
        "heart_rate", "respiratory_rate", "blood_pressure_sys",
        "blood_pressure_dia")),
    ("drive", "内驱力 Drive", ("hunger",)),
)

GROUP_LABELS: Dict[str, str] = {g[0]: g[1] for g in FIELD_GROUPS}


def fields_in_group(group: str) -> Tuple[FieldSpec, ...]:
    for key, _, members in FIELD_GROUPS:
        if key == group:
            return tuple(FIELD_MAP[m] for m in members if m in FIELD_MAP)
    return ()


def fields_schema() -> List[Dict[str, Any]]:
    """给前端的字段字典：中文名 / 单位 / 范围 / 正常区间 / 分组。

    前端拿它就能渲染"26 行全量数值"与"26 个滑块"，
    不必再自己维护一份字段表（旧版前端各自维护，两边会漂移）。
    """
    out: List[Dict[str, Any]] = []
    for key, label, members in FIELD_GROUPS:
        items = []
        for m in members:
            f = FIELD_MAP.get(m)
            if f is None:
                continue
            items.append({
                "key": f.key, "label": f.label, "unit": f.unit,
                "lo": f.lo, "hi": f.hi, "default": f.default,
                "normal": f.normal,
            })
        out.append({"key": key, "label": label, "fields": items})
    return out

# 运动强度映射（取 max，不累加）
MOTOR_INTENSITY: Dict[str, float] = {
    "move_to": 0.30, "move_to_seat": 0.30, "move_to_water": 0.30,
    "stand_up": 0.20, "sit_down": 0.20,
    "run": 0.70, "jump": 0.70,
    "eat_snack": 0.05, "drink_water": 0.05,
    "sleep": 0.0, "relax": 0.0, "do_nothing": 0.0,
    "look_at_board": 0.02, "look_window": 0.02, "look_door": 0.02,
}

# 进食 / 饮水的即时效果
SNACK_GLUCOSE_GAIN = 1.2
SNACK_GLYCOGEN_GAIN = 5.0
SNACK_KCAL_GAIN = 120.0
SNACK_HUNGER_REDUCTION = 0.4
WATER_THIRST_REDUCTION = 0.5
WATER_OSMOLARITY_REDUCTION = 2.5

# ----------------------------------------------------------------------
# 生理时间常数（单位：模拟秒）
# ----------------------------------------------------------------------
# 旧版最大的问题是**没有时间常数概念**：所有变量都用"每步加一个小量"来写，
# 于是推进几千步之后就集体漂到钳位边界（睡眠压力 83 分钟就满、肝糖原涨到上限）。
# 这里给每个慢变量一个真实生理时间常数，用「向定点指数趋近」写，
# 这样无论推进多久都停在合理区间内。
TAU_SLEEP = 18 * 3600.0        # 睡眠压力：清醒 18 小时到 0.63（≈16h 到 0.55）
TAU_MUSCLE_FATIGUE = 30 * 60.0  # 肌肉疲劳恢复 30 分钟
TAU_CENTRAL_FATIGUE = 90 * 60.0  # 中枢疲劳恢复 90 分钟
TAU_GLYCOGEN = 4 * 3600.0      # 肝糖原缓冲 4 小时
TAU_KCAL = 20 * 3600.0         # 总能量池 20 小时
TAU_THIRST = 6 * 3600.0        # 口渴定点 6 小时
TAU_ELECTROLYTE = 3 * 3600.0   # 电解质平衡 3 小时
TAU_SKIN_TEMP = 120.0          # 体表温度跟随 2 分钟

# 基础热导（W/kg/°C）。这个值决定**调定点落在哪里**：
# 静息产热 0.05 ÷ (37 − 22 环境温差 ≈ 6) ≈ 0.0083，
# 于是环境 22°C 时 37.0 恰好是热平衡点。推导见 update()。
BASE_HEAT_LOSS = 0.0083

# 定点
SETPOINT_SLEEP_MIN = 0.02
SETPOINT_SLEEP_MAX = 0.98
SETPOINT_GLYCOGEN = 100.0
SETPOINT_KCAL = 2000.0
SETPOINT_THIRST = 0.12
SETPOINT_ELECTROLYTE = 0.0


# ----------------------------------------------------------------------
# 情绪（第2代有 9 分类，第3代丢了，这里恢复）
# ----------------------------------------------------------------------
MOODS: Tuple[str, ...] = (
    "calm", "alert", "tired", "hungry", "thirsty", "irritated",
    "content", "anxious", "sleepy",
)
MOOD_LABELS: Dict[str, str] = {
    "calm": "平静", "alert": "警觉", "tired": "疲惫", "hungry": "饿",
    "thirsty": "渴", "irritated": "烦躁", "content": "满足",
    "anxious": "焦虑", "sleepy": "困",
}


@dataclass
class State:
    """一个内稳态快照。字段名与 HOMEOSTATIC_FIELDS 一一对应。"""

    glucose: float = 5.0
    liver_glycogen: float = 100.0
    free_fatty_acids: float = 0.5
    insulin: float = 10.0
    glucagon: float = 5.0
    total_energy_kcal: float = 2000.0
    blood_osmolarity: float = 290.0
    adh: float = 2.0
    thirst: float = 0.1
    electrolyte_balance: float = 0.0
    core_temp: float = 37.0
    skin_temp: float = 33.0
    sweating_rate: float = 0.0
    cortisol: float = 10.0
    adrenaline: float = 0.1
    noradrenaline: float = 0.2
    muscle_fatigue: float = 0.1
    central_fatigue: float = 0.1
    hunger: float = 0.3
    sleep_pressure: float = 0.2
    pain_level: float = 0.0
    heart_rate: float = 72.0
    respiratory_rate: float = 16.0
    blood_pressure_sys: float = 120.0
    blood_pressure_dia: float = 80.0
    blood_ph: float = 7.40
    # 递质（第3代新增，不占 26 维，单独放）
    da: float = 0.45
    ne: float = 0.30
    ht5: float = 0.55
    ach: float = 0.40

    # ------------------------------------------------------------------
    def to_dict(self) -> Dict[str, float]:
        """26 维（不含递质）—— 前端与备份都用这个口径。"""
        return {k: round(getattr(self, k), 6) for k in FIELD_KEYS}

    def to_dict_full(self) -> Dict[str, float]:
        d = self.to_dict()
        d.update({k: round(getattr(self, k), 6)
                  for k in ("da", "ne", "ht5", "ach")})
        return d

    @classmethod
    def from_dict(cls, d: Any) -> "State":
        """从字典恢复。未知键忽略、缺失键用默认、越界值夹回。"""
        s = cls()
        if not isinstance(d, dict):
            return s
        for k in FIELD_KEYS + ("da", "ne", "ht5", "ach"):
            if k not in d:
                continue
            try:
                v = float(d[k])
            except (TypeError, ValueError):
                continue
            spec = FIELD_MAP.get(k)
            setattr(s, k, spec.clamp(v) if spec else v)
        return s

    def clamp_all(self) -> None:
        for k in FIELD_KEYS:
            spec = FIELD_MAP[k]
            setattr(self, k, spec.clamp(getattr(self, k)))

    def copy(self) -> "State":
        s = State()
        for k in FIELD_KEYS + ("da", "ne", "ht5", "ach"):
            setattr(s, k, getattr(self, k))
        return s


# ----------------------------------------------------------------------
class Homeostasis:
    """内稳态模拟器。

    用法：
        h = Homeostasis()
        h.update(dt=1.0, motor_intensity=0.3, env_temp=22.0, asleep=False)
        print(h.state.core_temp, h.state.glucose)
    """

    def __init__(self, state: Optional[State] = None,
                 seed: int = 20261002) -> None:
        self.state = state or State()
        self.rng = random.Random(seed)
        self.sympathetic = 0.15        # 交感张力（绝对值）
        self.parasympathetic = 0.70    # 副交感张力
        self._last: Dict[str, float] = self.state.to_dict()

    # ------------------------------------------------------------------
    # 派生量
    # ------------------------------------------------------------------
    @property
    def state_dict(self) -> Dict[str, float]:
        return self.state.to_dict()

    def delta(self) -> Dict[str, float]:
        """相对上一次 `delta()` 的变化率。"""
        now = self.state.to_dict()
        out = {k: round(now[k] - self._last.get(k, now[k]), 5) for k in now}
        self._last = now
        return out

    def mood(self) -> str:
        """9 分类情绪（第2代有、第3代丢了的那个）。"""
        s = self.state
        if s.sleep_pressure >= 0.75 or s.central_fatigue >= 0.80:
            return "sleepy"
        if s.pain_level >= 0.45 or (s.adrenaline >= 1.0
                                    and s.noradrenaline >= 0.9):
            return "alert"
        if s.hunger >= 0.70:
            return "hungry"
        if s.thirst >= 0.60:
            return "thirsty"
        if s.cortisol >= 22.0 or s.muscle_fatigue >= 0.72:
            return "irritated"
        if s.glucose <= 3.6 or s.muscle_fatigue >= 0.55:
            return "tired"
        if s.cortisol >= 16.0 or s.heart_rate >= 100:
            return "anxious"
        if (s.glucose >= 5.2 and s.hunger <= 0.35 and s.sleep_pressure <= 0.40
                and s.cortisol <= 14.0):
            return "content"
        return "calm"

    @property
    def mood_label(self) -> str:
        return MOOD_LABELS.get(self.mood(), "平静")

    def is_critical(self) -> bool:
        """是否处于危险状态（第2代有、第3代丢了的那个）。"""
        s = self.state
        return bool(s.pain_level > 0.7 or s.heart_rate > 150
                    or s.heart_rate < 45 or s.core_temp > 39.0
                    or s.core_temp < 35.5 or s.glucose < 2.8
                    or s.glucose > 10.5)

    def critical_reasons(self) -> List[str]:
        """危险的具体原因（比布尔值更有用）。"""
        s = self.state
        out = []
        if s.pain_level > 0.7:
            out.append("剧痛")
        if s.heart_rate > 150:
            out.append("心动过速")
        if s.heart_rate < 45:
            out.append("心动过缓")
        if s.core_temp > 39.0:
            out.append("高热")
        if s.core_temp < 35.5:
            out.append("失温")
        if s.glucose < 2.8:
            out.append("低血糖")
        if s.glucose > 10.5:
            out.append("高血糖")
        return out

    # ------------------------------------------------------------------
    # 外部注入
    # ------------------------------------------------------------------
    def apply_pain(self, intensity: float) -> None:
        s = self.state
        s.pain_level = min(1.0, s.pain_level + max(0.0, float(intensity)))
        # 疼痛立刻拉起应激轴
        s.adrenaline = FIELD_MAP["adrenaline"].clamp(
            s.adrenaline + 0.25 * intensity)
        s.heart_rate = FIELD_MAP["heart_rate"].clamp(
            s.heart_rate + 12.0 * intensity)

    def apply_hunger(self, delta: float) -> None:
        s = self.state
        s.hunger = FIELD_MAP["hunger"].clamp(s.hunger + float(delta))

    def apply_thirst(self, delta: float) -> None:
        s = self.state
        s.thirst = FIELD_MAP["thirst"].clamp(s.thirst + float(delta))

    def eat_snack(self) -> None:
        s = self.state
        s.glucose = FIELD_MAP["glucose"].clamp(s.glucose + SNACK_GLUCOSE_GAIN)
        s.liver_glycogen = FIELD_MAP["liver_glycogen"].clamp(
            s.liver_glycogen + SNACK_GLYCOGEN_GAIN)
        s.total_energy_kcal = FIELD_MAP["total_energy_kcal"].clamp(
            s.total_energy_kcal + SNACK_KCAL_GAIN)
        s.hunger = FIELD_MAP["hunger"].clamp(s.hunger - SNACK_HUNGER_REDUCTION)

    def drink_water(self) -> None:
        s = self.state
        s.thirst = FIELD_MAP["thirst"].clamp(s.thirst - WATER_THIRST_REDUCTION)
        s.blood_osmolarity = FIELD_MAP["blood_osmolarity"].clamp(
            max(280.0, s.blood_osmolarity - WATER_OSMOLARITY_REDUCTION))

    def configure_random(self) -> None:
        """随机初始生理（第3代有）—— 让每个个体起点不同。"""
        r = self.rng.uniform
        s = self.state
        s.glucose = r(4.6, 5.6)
        s.liver_glycogen = r(85.0, 115.0)
        s.insulin = r(7.0, 13.0)
        s.glucagon = r(3.5, 6.5)
        s.core_temp = r(36.7, 37.2)
        s.skin_temp = s.core_temp - r(3.0, 4.5)
        s.adrenaline = r(0.06, 0.20)
        s.noradrenaline = r(0.12, 0.30)
        s.cortisol = r(7.0, 14.0)
        s.muscle_fatigue = r(0.05, 0.20)
        s.central_fatigue = r(0.05, 0.18)
        s.sleep_pressure = r(0.10, 0.30)
        s.hunger = r(0.15, 0.40)
        s.heart_rate = r(66.0, 80.0)
        s.blood_ph = r(7.38, 7.42)
        s.clamp_all()

    # ------------------------------------------------------------------
    # 主推进
    # ------------------------------------------------------------------
    def update(self, dt: float = 1.0, motor_intensity: float = 0.0,
               env_temp: float = 22.0, asleep: bool = False,
               eating: bool = False) -> Dict[str, float]:
        """推进 dt 秒。

        dt 是**模拟秒**。注意时间尺度：旧版第 3 代 1 模拟分钟 = 1 真实秒，
        所以 1 真实秒对应的 dt 要看调用方怎么折算。
        """
        dt = max(0.01, float(dt))
        s = self.state
        rnd = self.rng.gauss
        ex = max(0.0, min(1.0, float(motor_intensity)))

        # ---- 自律神经张力 ----
        # 交感由去甲肾上腺素与皮质醇驱动，副交感与之拮抗。
        # 定标实测：na 项系数取 0.12 时静息肾上腺素会跑到 1.6（常值 0.05–0.5），
        # 故降到 0.09 并让皮质醇贡献更小。
        self.sympathetic = _clamp(
            0.10 + 0.09 * s.noradrenaline - 0.10 * (s.noradrenaline - 0.40)
            + 0.004 * s.cortisol, 0.0, 1.2)
        self.parasympathetic = _clamp(
            1.0 - 0.8 * self.sympathetic - 0.2 * (1.0 if asleep else 0.0),
            0.0, 1.2)
        if asleep:
            self.parasympathetic = _clamp(self.parasympathetic + 0.3, 0.0, 1.2)
        symp = self.sympathetic
        para = self.parasympathetic

        # ---- 血糖 ----
        # 消耗与当前血糖成比例（旧版是常数基数，会导致静息时单调爬到上限）。
        prod = (0.055 + 0.010 * symp + 0.006 * (s.glucagon / 10.0)
                + 0.012 * (s.cortisol / 20.0))
        cons = (0.05 * (s.glucose / 5.0) + 0.045 * ex * ex
                + 0.008 * (s.insulin / 10.0))
        s.glucose += (prod - cons) * dt
        s.glucose += rnd(-1.0, 1.0) * (0.01 * math.sqrt(dt))

        # ---- 胰岛素 / 胰高血糖素 ----
        # 胰岛素的产生项带基础分泌：写成纯 `0.02·(g−5)` 时，
        # 血糖低于 5.0 右侧恒为负，会被钳到 0（实测跑步时复现）。
        # 生理上运动确实抑制胰岛素分泌，但应表现为"降到低值"而非"归零"。
        insulin_prod = 0.030 + 0.02 * (s.glucose - 5.0)
        s.insulin += (insulin_prod / 0.01 - s.insulin) * _approach(0.01, dt)
        s.insulin = max(0.0, s.insulin)
        # 胰高血糖素：基础分泌 + 低血糖时升高 − 清除。
        # 旧版写成 `0.01·(5−g) − 0.005·glucagon`，血糖一过 5.0 右侧就恒为负，
        # 于是必然钉在 0（实测确认）。加基础分泌项后定点落在常值区间。
        glucagon_prod = 0.035 + 0.05 * max(0.0, 5.0 - s.glucose)
        s.glucagon += (glucagon_prod / 0.010 - s.glucagon) * _approach(0.010, dt)

        # ---- 肝糖原：受控储库 ----
        # 这一整段重写过。旧版用 if/elif 三段（释放 / 存储 / 回归），
        # 段与段之间不连续，长期跑必然撞到某个边界：静息顶到 200、
        # 跑步又清零（实测都复现过）。
        # 现在改成单一连续模型：
        #   定点随血糖走（血糖高就存、低就放），存储速率正比于「离上限还有多远」，
        #   于是定点天然低于上限，不会顶格。
        gly_target = _clamp(
            130.0 + (s.glucose - 5.0) * 55.0 - 60.0 * ex, 15.0, 175.0)
        s.liver_glycogen += (gly_target - s.liver_glycogen) \
            * _approach(1.0 / (TAU_GLYCOGEN), dt)
        # 释放出来的糖回补血液（按克数折算成 mM，系数取小）
        if s.liver_glycogen < gly_target:
            s.glucose += (gly_target - s.liver_glycogen) \
                * _approach(1.0 / (TAU_GLYCOGEN), dt) * 0.010

        # ---- 总能量（定点趋近 + 运动消耗）----
        s.total_energy_kcal += (SETPOINT_KCAL - s.total_energy_kcal) \
            * _approach(1.0 / (TAU_KCAL), dt)
        s.total_energy_kcal -= (0.02 + 0.55 * ex) * dt
        if eating:
            s.total_energy_kcal += SNACK_KCAL_GAIN * 6.0 * dt / 60.0

        # ---- 游离脂肪酸（第2代漏了更新，这里补齐）----
        ffa_target = _clamp(
            0.20 + 0.55 * (s.glucagon / 10.0) + 0.25 * symp
            - 0.30 * _clamp(s.insulin / 20.0, 0.0, 1.0), 0.05, 1.6)
        s.free_fatty_acids += (ffa_target - s.free_fatty_acids) * _approach(0.05, dt)

        # ---- 应激轴 ----
        # 定标实测：系数偏大会让静息肾上腺素固定在 1.6（常值 0.05–0.5）、
        # 去甲肾上腺素顶到上限 2.0 —— 因为 na 又回过头推高交感，形成正反馈。
        # 这里让 na 对自身的净增益小于 1，环路才收敛。
        #  ★★ 用户报"应激不是 2.5 就是 0" —— 根因就在这三行。
        #     原来是 `x += (C + k2·symp − k·x) · dt`，纯欧拉法。
        #     dt=1 时没事；可世界一拍是 **60 模拟秒**，k·dt = 0.16×60 = 9.6 ≫ 1，
        #     每一步都跨过定点撞到另一侧钳位，实测逐拍翻转：
        #         肾上腺素 0 ⇄ 2.5、去甲肾上腺素 0.05 ⇄ 1.73，
        #     还连带把自由能拖成 0.23 ⇄ −0.01 的方波（用户："自由能像假的"）。
        #     改成指数趋近（_approach = 1−e^(−k·dt)）：定点不变、与 dt 无关、不过冲。
        adr_target = (0.006 + 0.28 * symp) / 0.16      # 定点 ≈ 0.33（常值 0.05–0.5）
        s.adrenaline += (adr_target - s.adrenaline) * _approach(0.16, dt)
        s.adrenaline += rnd(-1.0, 1.0) * (0.005 * math.sqrt(dt))
        na_target = (0.012 + 0.16 * symp) / 0.22       # 定点 ≈ 0.18（常值 0.05–2.0）
        s.noradrenaline += (na_target - s.noradrenaline) * _approach(0.22, dt)
        s.noradrenaline += rnd(-1.0, 1.0) * (0.004 * math.sqrt(dt))
        # 皮质醇：定标实测静息交感只有 0.20（不是想当然的 0.35），
        # 按 0.18 的系数算出来定点 3.88，低于常值下限 5，故抬到 0.32 并提高基础项。
        cortisol_prod = (0.10 + 0.32 * symp
                         + 0.04 * max(0.0, 1.0 - s.glucose / 5.0))
        # 皮质醇同理：0.02×60 = 1.2 > 1，实测在 7.4 ⇄ 7.8 之间逐拍翻转。
        s.cortisol += (cortisol_prod / 0.02 - s.cortisol) * _approach(0.02, dt)

        # ---- 体温（调定点模型）----
        # 这一段重写过三次，前两版的毛病记在这里免得再犯：
        #
        #  v1: heat_loss = 0.1·(T−25) ＋ …… 平衡点 25.5°C，体温被钉在 35.0
        #  v2: heat_loss = 0.003·(T−env)，T 高于环境时散热近似恒定 → 只升不降
        #  v3: 去掉寒战项后基础产热只有 0.05，而 5°C 环境散热 0.09，
        #      入不敷出；要靠出汗才能配平，于是 5°C 里寒战与出汗同时开工。
        #
        # 正解是**调定点**：冷环境下调定点本身会上移，产热与散热都围绕它调节。
        #   setpoint = 37.0 + 0.008·(20 − env)   冷环境略高
        #   寒战     = 0.9·(setpoint − T)        需要时才启动，不需要时为零
        #   散热     = 热导·(T − env)·血管舒缩   血管收缩把热导压到 0.22 倍
        #   出汗     = 仅当 T 明显高于调定点      冷环境自然不出汗
        env_eff = max(env_temp, -10.0)
        setpoint = 37.0
        # 皮肤血管收缩会让"感知到的环境温度"回升，而不是抬高调定点。
        # （抬高调定点在寒冷里等于要求更高产热，反而会触发寒战+出汗并存。）

        #   ★ 静息产热与热导是**配平**出来的，不是随手定的。
        #     关系式：静息产热 = BASE_HEAT_LOSS × (37 − 环境温度)
        #     取环境 22°C → 温差 15 → 0.0083 × 15 ≈ 0.125。
        #     这就是静息代谢率（约 2 W/kg，与儿童的实际值同量级）。
        #
        #     修前的错有两处，叠在一起让体温**没有平衡点**：
        #       ① 静息产热写 0.05，而 22°C 下的散热是 0.125
        #          → 真实平衡点其实是 T≈28（低体温），只是被下限钳住看不出来
        #       ② 寒战上限 0.30 + 线性无饱和 → T<37 时产热恒被钳住
        #          → 一路烧到上限 41
        #     现在两处都配平了：产热向 setpoint 收敛且**没有硬上限**
        #     （改为平滑饱和），T=37 就是稳定的平衡点。
        heat_prod = 0.125 + 0.2 * ex + 0.02 * symp
        # 寒战增益。★ 必须和热导同量级，否则会**过冲**：
        #   原来写 1.2，而配平只需要约 0.035 —— 于是 22°C 下产热冲到 0.4，
        #   体温被推过调定点，出汗又启动，出现"一边寒战一边出汗"的荒谬状态
        #   （实测冷环境里 sweating_rate = 0.17）。
        #   0.05 让最冷环境（-5°C，需产热 0.31）的稳态温差约 6°C，可达。
        heat_prod += 0.05 * max(0.0, setpoint - s.core_temp)

        vaso = 1.0
        if env_eff < 20.0:
            vaso = _clamp(1.0 - 0.045 * (20.0 - env_eff), 0.22, 1.0)
        elif env_eff > 28.0:
            vaso = _clamp(1.0 + 0.05 * (env_eff - 28.0), 1.0, 1.35)
        heat_loss = (BASE_HEAT_LOSS
                     * max(0.0, s.core_temp - env_eff) * vaso)

        sweat_target = _clamp(
            0.9 * (s.core_temp - (setpoint + 0.10))
            + max(0.0, env_eff - 29.0) * 0.02, 0.0, 1.0)
        s.sweating_rate += (sweat_target - s.sweating_rate) * _approach(0.05, dt)
        if s.core_temp > 36.9:
            heat_loss += 0.45 * s.sweating_rate * _clamp(
                s.core_temp - 36.9, 0.0, 3.0)

        s.core_temp += (heat_prod - heat_loss) * dt
        s.core_temp += rnd(-1.0, 1.0) * (0.015 * math.sqrt(dt))
        # ★ 单步温度变化限幅。
        #   热方程是**加性**积分（不像趋近式有内在阻尼），
        #   热失衡 0.1 W/kg × dt=60 一步就是 6°C —— 会直接跨过整个生理区间。
        #   真实机体不会这样：热容、血流会把变化率限制住。
        #
        #   ★ 幅度必须**远小于**生理区间宽度。原来写 0.35，
        #     在 37.0 两侧形成了周期 2 的**极限环**（36.650 ⇄ 37.350），
        #     只有两个状态；汗率跟着在 0.011 ⇄ 0.214 之间跳，
        #     于是出现"体温 36.65 却在出汗"的自相矛盾。
        #     0.02/步 让温度平滑趋近平衡点，没有可见振荡。
        _max_step = 0.02
        if s.core_temp > setpoint + _max_step:
            s.core_temp = setpoint + _max_step
        elif s.core_temp < setpoint - _max_step:
            s.core_temp = setpoint - _max_step

        # ---- 体表温度 ----
        # 体表温度由核心温度与环境共同决定，且**永远低于核心**（有梯度）。
        # 旧版写成 `skin += 0.2·(core − skin)·dt`，时间常数只有 5 秒，
        # 长跑之后直接被拉平到与核心相等（实测 37.04 == 37.04）。
        # 出汗已在体温那一段随调定点算好，这里不再重复计算。
        temp_gap = 2.0 + 0.08 * max(0.0, s.core_temp - env_temp)
        skin_target = s.core_temp - temp_gap
        s.skin_temp += (skin_target - s.skin_temp) * _approach(1.0 / (TAU_SKIN_TEMP), dt)

        # ---- 渗透压 / 口渴 / 抗利尿激素 ----
        # 口渴向定点趋近：出汗与不显性失水推高、喝水拉低，长期停在低值。
        thirst_target = SETPOINT_THIRST + 0.35 * s.sweating_rate \
            + 0.02 * max(0.0, env_temp - 28.0)
        s.thirst += (thirst_target - s.thirst) * _approach(1.0 / (TAU_THIRST), dt)
        osm_target = 285.0 + 5.0 * s.thirst
        s.blood_osmolarity += (osm_target - s.blood_osmolarity) * _approach(0.1, dt)
        s.adh = 8.0 if s.thirst > 0.8 else max(1.0, 2.0 - 2.0 * s.thirst)

        # ---- 电解质（向定点回归，不会一直往下掉）----
        s.electrolyte_balance += (-0.001 * s.sweating_rate * dt
                                  + (SETPOINT_ELECTROLYTE
                                     - s.electrolyte_balance)
                                  * _approach(1.0 / (TAU_ELECTROLYTE), dt))

        # ---- 疲劳 ----
        # 旧版 acc 含 0.01·m²（自催化）→ 永远饱和。
        # 这里用「向定点指数趋近」：运动把定点抬高、静息把定点压回 0，
        # 于是既不会瞬间饱和，也不会永远回不来。
        if asleep:
            s.muscle_fatigue += (0.0 - s.muscle_fatigue) * \
                _approach(1.0 / (TAU_MUSCLE_FATIGUE * 0.4), dt)
            s.central_fatigue += (0.0 - s.central_fatigue) * \
                _approach(1.0 / (TAU_CENTRAL_FATIGUE * 0.4), dt)
            s.sleep_pressure += (SETPOINT_SLEEP_MIN - s.sleep_pressure) * \
                _approach(1.0 / (TAU_SLEEP * 0.35), dt)
        else:
            m_target = _clamp(ex * 0.85, 0.0, 1.0)
            s.muscle_fatigue += (m_target - s.muscle_fatigue) * \
                _approach(1.0 / (TAU_MUSCLE_FATIGUE * 0.35), dt)
            c_target = _clamp(ex * 0.6 + s.sleep_pressure * 0.3, 0.0, 1.0)
            s.central_fatigue += (c_target - s.central_fatigue) * \
                _approach(1.0 / (TAU_CENTRAL_FATIGUE * 0.35), dt)
            s.sleep_pressure += (SETPOINT_SLEEP_MAX - s.sleep_pressure) * \
                _approach(1.0 / TAU_SLEEP, dt)

        # ---- 饥饿 ----
        hunger_target = max(
            0.0, 1.0 - (s.glucose + s.liver_glycogen / 200.0) / 6.0) \
            + 0.2 * (1.0 - s.total_energy_kcal / 2500.0)
        s.hunger += (hunger_target - s.hunger) * _approach(0.15, dt)
        if eating:
            s.hunger -= 0.5

        # ---- 疼痛自行消退 ----
        s.pain_level -= s.pain_level * _approach(0.05, dt)

        # ---- 循环系统（第2代是硬赋值，这里带惯性并钳位）----
        # ★ 常数项 64.5 是**配平**出来的，不是试数：
        #   实测静息时 symp≈0.169、para≈0.865，
        #   要落在默认值 72 bpm 就需要 72 − 70×0.169 + 5×0.865 = 64.5。
        #   之前写 57（注释说"交感定标是 0.20"）→ 静息心率只有 58，
        #   掉到正常区间 60~80 之外。注释里的 0.20 与实测的 0.169 不符，
        #   而且当时抬系数后没复测。
        hr_target = (64.5 + 70.0 * symp + 30.0 * ex - 5.0 * para
                     + 10.0 * _clamp(s.core_temp - 37.0, -2.0, 2.0))
        if asleep:
            hr_target -= 8.0
        s.heart_rate += (hr_target - s.heart_rate) * _approach(0.05, dt)
        s.heart_rate += rnd(-1.0, 1.0) * (0.4 * math.sqrt(dt))

        rr_target = 16.0 + 5.0 * symp + 8.0 * ex - 3.0 * para
        s.respiratory_rate += (rr_target - s.respiratory_rate) * _approach(0.08, dt)

        sys_target = _clamp(120.0 + 10.0 * symp + 5.0 * ex, 80.0, 190.0)
        dia_target = _clamp(80.0 + 5.0 * symp, 50.0, 120.0)
        s.blood_pressure_sys += (sys_target - s.blood_pressure_sys) * _approach(0.08, dt)
        s.blood_pressure_dia += (dia_target - s.blood_pressure_dia) * _approach(0.08, dt)

        # ---- 血液 pH ----
        ph_target = 7.40 - 0.03 * ex + 0.005 * (1.0 - s.hunger)
        s.blood_ph += (ph_target - s.blood_ph) * _approach(0.02, dt)

        # ---- 递质（第3代新增）----
        da_target = _clamp(0.35 + 0.5 * (1.0 - s.central_fatigue)
                           - 0.25 * s.sleep_pressure, 0.0, 1.0)
        s.da += (da_target - s.da) * _approach(0.06, dt)
        ne_target = _clamp(0.15 + 0.7 * _clamp(symp, 0.0, 1.0), 0.0, 1.0)
        s.ne += (ne_target - s.ne) * _approach(0.08, dt)
        ht5_target = _clamp(0.75 - 0.45 * s.sleep_pressure, 0.0, 1.0)
        s.ht5 += (ht5_target - s.ht5) * _approach(0.05, dt)
        ach_target = _clamp(0.30 + 0.5 * (1.0 - s.central_fatigue), 0.0, 1.0)
        s.ach += (ach_target - s.ach) * _approach(0.06, dt)

        s.clamp_all()
        # 递质单独夹
        s.da = _clamp(s.da, 0.0, 1.0)
        s.ne = _clamp(s.ne, 0.0, 1.0)
        s.ht5 = _clamp(s.ht5, 0.0, 1.0)
        s.ach = _clamp(s.ach, 0.0, 1.0)
        return s.to_dict()

    # ------------------------------------------------------------------
    def drive(self, plan: Optional[str] = None) -> float:
        """把动作计划折算成运动强度（取 max 语义，单次调用即单动作）。"""
        if not plan:
            return 0.0
        return MOTOR_INTENSITY.get(str(plan), 0.0)

    def summary(self) -> Dict[str, Any]:
        """给前端/LLM 的一份摘要。"""
        s = self.state
        return {
            "mood": self.mood(),
            "mood_label": self.mood_label,
            "critical": self.is_critical(),
            "critical_reasons": self.critical_reasons(),
            "sympathetic": round(self.sympathetic, 3),
            "parasympathetic": round(self.parasympathetic, 3),
            "state": s.to_dict(),
            "neuro": {"da": round(s.da, 3), "ne": round(s.ne, 3),
                      "ht5": round(s.ht5, 3), "ach": round(s.ach, 3)},
        }

    def describe_for_llm(self) -> str:
        """把身体状态翻译成句子（给大模型看的"此刻的身体"）。"""
        s = self.state
        lines = ["【此刻的身体】"]
        lines.append("  血糖 %.1f mM（常值 4–6）· 体温 %.1f°C · 心率 %.0f bpm"
                     % (s.glucose, s.core_temp, s.heart_rate))
        lines.append("  饥饿 %.2f · 口渴 %.2f · 肌肉疲劳 %.2f · 中枢疲劳 %.2f"
                     % (s.hunger, s.thirst, s.muscle_fatigue,
                        s.central_fatigue))
        lines.append("  睡眠压力 %.2f · 疼痛 %.2f · 皮质醇 %.1f · 肾上腺素 %.2f"
                     % (s.sleep_pressure, s.pain_level, s.cortisol,
                        s.adrenaline))
        lines.append("  情绪：%s · 交感张力 %.2f" % (self.mood_label,
                                                    self.sympathetic))
        return "\n".join(lines)


def _clamp(v: float, lo: float, hi: float) -> float:
    return lo if v < lo else (hi if v > hi else v)


def _approach(rate: float, dt: float) -> float:
    """指数逼近的**dt 无关**系数。

    `x += (target − x) · k · dt` 是欧拉法：`k·dt > 1` 时会**过冲并振荡发散**。
    原来 dt 是 1，所以 `0.05·dt` 看着没问题；但生理的正确 dt 是 60 模拟秒
    （1 拍 = 1 模拟分钟），`0.05 × 60 = 3.0` —— 汗率直接炸掉，
    再通过散热项把核心体温推到 41°C。

    `1 − e^(−k·dt)` 与欧拉法在 `k·dt → 0` 时**完全等价**（都是 `k·dt`），
    但对任何 dt 都落在 [0,1) 内，**永不过冲**。
    公式本身没变，变的只是积分方式。
    """
    x = rate * dt
    if x <= 1e-9:
        return x
    if x > 40.0:            # e^-40 已经小到可以忽略，避免溢出
        return 1.0
    return -math.expm1(-x)


__all__ = [
    "Homeostasis", "State", "FieldSpec", "HOMEOSTATIC_FIELDS", "FIELD_MAP",
    "FIELD_KEYS", "FIELD_COUNT", "MOTOR_INTENSITY", "MOODS", "MOOD_LABELS",
    "SNACK_GLUCOSE_GAIN", "SNACK_GLYCOGEN_GAIN", "SNACK_KCAL_GAIN",
    "SNACK_HUNGER_REDUCTION", "WATER_THIRST_REDUCTION",
    "WATER_OSMOLARITY_REDUCTION",
]
