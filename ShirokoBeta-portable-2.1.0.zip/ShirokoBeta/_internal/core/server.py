# -*- coding: utf-8 -*-
"""
Shiroko β —— HTTP / WebSocket 服务

前端与后端之间**只有这一条通道**，契约都在这里。

页面
----
    GET  /                    主页面（单文件前端，注入 BOOT）
    GET  /static/{path}       静态资源
    GET  /avatar/{name}       角色立绘

状态（前端轮询或首屏用）
------------------------
    GET  /api/health          存活、版本、生命列表、连接状态
    GET  /api/config          配置（Key 打码，前端据此决定跳过注册）
    GET  /api/state           当前帧
    GET  /api/geometry        ★ 小地图几何（唯一来源，跟着环境变）
    GET  /api/regions         10 个脑区（真实规模与发放率）
    GET  /api/memory          情景记忆 / 没说出口的话 / 梦境
    GET  /api/models          可用模型列表（真调 /models）
    GET  /api/backups         备份列表
    GET  /api/logs            事件日志

动作
----
    POST /api/config          保存配置（Key 只在非空时覆盖）
    POST /api/chat            对讲机（支持 stream=1 流式）
    POST /api/test_key        ★ 真的测连通性（第5代前端这个是假的）
    POST /api/generate_env    用环境描述生成场景（真调 API）
    POST /api/action          远程动作：sleep / wake / eat / drink / dream
    POST /api/environment     直接设置环境 spec
    POST /api/life            新建 / 删除数字生命
    POST /api/reset           重启某角色（清运行态，保留记忆）
    POST /api/backup          立刻备份

接入方式
--------
    GET  /api/bridge          QQ 桥接状态
    POST /api/bridge          切换 internal / qq 并配置
    WS   /ws                  实时帧推送
"""

from __future__ import annotations

import asyncio
import json
import logging
import mimetypes
import time
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Set

from . import VERSION as _APP_VERSION
from . import geo, llm as llm_mod, onebot as onebot_mod, persona as persona_mod
from . import runtime as rt_mod, snn as snn_mod

log = logging.getLogger("shiroko.server")

try:
    from aiohttp import WSMsgType, web
    HAVE_AIOHTTP = True
except ImportError:                                          # pragma: no cover
    HAVE_AIOHTTP = False
    web = None                                               # type: ignore
    WSMsgType = None                                         # type: ignore

BOOT_PLACEHOLDER = "<!--SHIROKO_BOOT-->"


# ======================================================================
def _json_ok(data: Any = None, **kw) -> "web.Response":
    body = {"ok": True}
    if isinstance(data, dict):
        body.update(data)
    elif data is not None:
        body["data"] = data
    body.update(kw)
    return web.json_response(body, dumps=lambda o: json.dumps(
        o, ensure_ascii=False))


def _json_err(msg: str, status: int = 400, **kw) -> "web.Response":
    body = {"ok": False, "error": str(msg)[:400]}
    body.update(kw)
    return web.json_response(body, status=status,
                             dumps=lambda o: json.dumps(o, ensure_ascii=False))


def _int(v: Any, default: int = 0) -> int:
    try:
        return int(v)
    except (TypeError, ValueError):
        return default


_UNSAFE_PATH = ("..", "\\", "\x00")


def _safe_rel(rel: str) -> Optional[str]:
    """把请求路径变成本地相对路径，任何可疑成分一律拒绝。

    要点（早期版本三种穿越都没拦住）：
      · aiohttp 会把 `%2e%2e%2f` 解码后再匹配路由，所以拿到手的可能就是 `..`
      · 只查 `".." in name.split("/")` 挡不住 `..\\` 与 `....//`
      · Windows 上 `\\` 也是分隔符，必须一并拒绝
    """
    raw = str(rel or "")
    if not raw:
        return None
    # 先做一次百分号解码 —— 路由可能把原文原样交给通配符
    try:
        from urllib.parse import unquote
        dec = unquote(raw)
        if dec != raw:
            raw = dec
    except Exception:                                            # noqa: BLE001
        pass
    name = raw.replace("\\", "/").lstrip("/")
    if not name:
        return None
    for bad in _UNSAFE_PATH:
        if bad in name:
            return None
    # 逐段检查：空段、`.`、`..` 全不要
    parts = [p for p in name.split("/") if p]
    if not parts or any(p in (".", "..") for p in parts):
        return None
    # 盘符（`C:`）与 UNC（`//server`）也拒绝
    if ":" in parts[0]:
        return None
    return "/".join(parts)


def _resolve_under(base: Path, name: str) -> Optional[Path]:
    """把 name 解析到 base 之内，越界返回 None。"""
    rel = _safe_rel(name)
    if rel is None:
        return None
    try:
        b = base.resolve()
        p = (b / rel).resolve()
        p.relative_to(b)
    except (ValueError, OSError):
        return None
    return p


class ShirokoServer:
    """把 Runtime 挂到 aiohttp 上。"""

    def __init__(self, runtime: "rt_mod.Runtime", *, host: str = "127.0.0.1",
                 port: int = 8000, static_dir: Optional[Path] = None,
                 avatar_dir: Optional[Path] = None) -> None:
        if not HAVE_AIOHTTP:
            raise RuntimeError("缺少 aiohttp，无法启动服务")
        self.rt = runtime
        self.host = host
        self.port = port
        self.static_dir = Path(static_dir) if static_dir else None
        self.avatar_dir = Path(avatar_dir) if avatar_dir else None
        self._clients: Set["web.WebSocketResponse"] = set()
        self._runner: Optional["web.AppRunner"] = None
        self._site: Optional["web.TCPSite"] = None
        self._started_at = time.time()
        self.app = self._build_app()
        self.rt.set_broadcast(self.broadcast)

    # ==================================================================
    # 应用与路由
    # ==================================================================
    def _build_app(self) -> "web.Application":
        app = web.Application(client_max_size=32 * 1024 * 1024,
                              middlewares=[self._errors])
        r = app.router
        r.add_get("/", self.h_index)
        r.add_get("/index.html", self.h_index)
        r.add_get("/favicon.ico", self.h_favicon)

        r.add_get("/api/health", self.h_health)
        r.add_get("/api/config", self.h_get_config)
        r.add_post("/api/config", self.h_post_config)
        r.add_get("/api/state", self.h_state)
        r.add_get("/api/geometry", self.h_geometry)
        r.add_get("/api/regions", self.h_regions)
        r.add_get("/api/homeo", self.h_homeo)
        r.add_get("/api/snn", self.h_snn)
        r.add_post("/api/snn", self.h_snn_set)
        r.add_get("/api/memory", self.h_memory)
        r.add_get("/api/models", self.h_models)
        r.add_get("/api/personas", self.h_personas)
        r.add_get("/api/backups", self.h_backups)
        r.add_get("/api/logs", self.h_logs)
        r.add_get("/api/bridge", self.h_get_bridge)
        r.add_post("/api/bridge", self.h_post_bridge)

        r.add_post("/api/chat", self.h_chat)
        r.add_post("/api/test_key", self.h_test_key)
        r.add_post("/api/generate_env", self.h_generate_env)
        r.add_post("/api/action", self.h_action)
        r.add_post("/api/homeo", self.h_homeo_set)
        r.add_post("/api/homeo_reset", self.h_homeo_reset)
        r.add_post("/api/environment", self.h_environment)
        r.add_post("/api/life", self.h_life)
        r.add_post("/api/reset", self.h_reset)
        r.add_post("/api/backup", self.h_backup)
        r.add_post("/api/enqueue", self.h_enqueue)

        r.add_get("/ws", self.h_ws)
        r.add_get("/avatar/{name}", self.h_avatar)
        r.add_get("/static/{path:.*}", self.h_static)
        r.add_get("/{path:.*}", self.h_spa)
        return app

    # ==================================================================
    # 中间件
    # ==================================================================
    @web.middleware
    async def _errors(self, request: "web.Request", handler: Any
                      ) -> "web.Response":
        """统一兜异常。

        没有这层时，aiohttp 在路由匹配阶段抛的 `HTTPBadRequest`
        （例如客户端把 `/..%2f..` 归一化后送进来）会变成 500 页，
        既难看又给了攻击者"服务器内部出错"的信号。这里统一成 404。
        """
        try:
            return await handler(request)
        except web.HTTPException as e:
            if e.status >= 500 or e.status in (400, 404):
                log.debug("请求被拒：%s %s（%d）", request.method,
                          request.path, e.status)
                if request.path.startswith("/api/"):
                    return _json_err(e.reason or "请求无效", e.status)
                return web.Response(status=404 if e.status == 400 else e.status)
            raise
        except asyncio.CancelledError:
            raise
        except Exception as e:                                   # noqa: BLE001
            log.error("处理 %s %s 出错：%s", request.method, request.path,
                      __import__("traceback").format_exc(limit=5))
            if request.path.startswith("/api/"):
                return _json_err("服务器内部错误：%s" % str(e)[:160], 500)
            return web.Response(status=500, text="内部错误")

    # ==================================================================
    # 生命周期
    # ==================================================================
    async def start(self) -> None:
        self._runner = web.AppRunner(self.app, access_log=None)
        await self._runner.setup()
        self._site = web.TCPSite(self._runner, self.host, self.port)
        await self._site.start()
        log.info("服务已启动：http://%s:%d", self.host, self.port)

    async def stop(self) -> None:
        for ws in list(self._clients):
            try:
                await ws.close(code=1001, message=b"server shutting down")
            except Exception:                                    # noqa: BLE001
                pass
        self._clients.clear()
        if self._runner is not None:
            await self._runner.cleanup()
            self._runner = None
        log.info("服务已停止")

    @property
    def url(self) -> str:
        return "http://%s:%d" % (self.host, self.port)

    # ==================================================================
    # 广播
    # ==================================================================
    async def broadcast(self, payload: Dict[str, Any]) -> None:
        if not self._clients:
            return
        try:
            text = json.dumps(payload, ensure_ascii=False)
        except (TypeError, ValueError):
            return
        for ws in list(self._clients):
            try:
                await ws.send_str(text)
            except Exception:                                    # noqa: BLE001
                self._clients.discard(ws)

    # ==================================================================
    # 页面与静态资源
    # ==================================================================
    async def h_index(self, request: "web.Request") -> "web.Response":
        page = self._index_path()
        if page is None:
            return web.Response(
                status=500, content_type="text/html", charset="utf-8",
                text="<h1>找不到前端页面</h1><p>缺少 index.html。"
                     "请确认 static 目录存在。</p>")
        try:
            html = page.read_text(encoding="utf-8")
        except OSError as e:
            return web.Response(status=500, text="读取前端失败：%s" % e)
        boot = {
            "host": self.host,
            "port": self.port,
            "wsPath": "/ws",
            "apiBase": "",
            "version": _APP_VERSION,
            "serverTime": time.time(),
            "initialized": bool(self.rt.lives),
            "hasKey": bool(self.rt.config.get("api_key")),
        }
        inject = ("<script>window.__SHIROKO_BOOT__="
                  + json.dumps(boot, ensure_ascii=False) + ";</script>")
        if BOOT_PLACEHOLDER in html:
            html = html.replace(BOOT_PLACEHOLDER, inject)
        elif "</head>" in html:
            html = html.replace("</head>", inject + "\n</head>", 1)
        else:
            html = inject + html
        return web.Response(text=html, content_type="text/html",
                            charset="utf-8",
                            headers={"Cache-Control": "no-store"})

    def _index_path(self) -> Optional[Path]:
        for cand in (self.static_dir, self.static_dir / "web"
                     if self.static_dir else None):
            if cand is None:
                continue
            p = cand / "index.html"
            if p.is_file():
                return p
        here = Path(__file__).resolve().parent.parent / "static"
        p = here / "index.html"
        return p if p.is_file() else None

    async def h_favicon(self, request: "web.Request") -> "web.Response":
        if self.static_dir:
            for nm in ("favicon.ico", "favicon.png", "icon.png"):
                p = self.static_dir / nm
                if p.is_file():
                    return web.FileResponse(p)
        return web.Response(status=204)

    async def h_static(self, request: "web.Request") -> "web.Response":
        return self._serve_file(request.match_info.get("path", ""))

    async def h_spa(self, request: "web.Request") -> "web.Response":
        """未命中的路径：是文件就发文件，否则回主页面。

        注意：**只有解析成功且确实存在的文件才发**。
        早期写法先 `_serve_file` 再判断 `resp.status == 200`，
        但路径穿越会走到这里并被 SPA 回落成首页 200，
        于是"穿越被拒"在测试里表现为"返回了 200 首页"。
        """
        p = request.match_info.get("path", "")
        if p and not p.startswith("api/"):
            rel = _safe_rel(p)
            if rel is None:
                log.debug("SPA 路径被拒：%r", p)
                return web.Response(status=404)
            f = self._serve_file(rel, quiet=True)
            if f is not None:
                return f
        return await self.h_index(request)

    def _serve_file(self, rel: str, quiet: bool = False
                    ) -> Optional["web.Response"]:
        if self.static_dir is None:
            return None if quiet else web.Response(status=404)
        p = _resolve_under(self.static_dir, rel)
        if p is None:
            log.debug("静态路径被拒：%r", rel)
            return None if quiet else web.Response(status=404)
        if not p.is_file():
            return None if quiet else web.Response(status=404)
        ctype, _ = mimetypes.guess_type(str(p))
        return web.FileResponse(
            p, headers={"Cache-Control": "no-cache",
                        "Content-Type": ctype or "application/octet-stream"})

    async def h_avatar(self, request: "web.Request") -> "web.Response":
        name = str(request.match_info.get("name") or "")
        roots = [d for d in (self.avatar_dir, self.static_dir,
                             Path(__file__).resolve().parent.parent / "static")
                 if d is not None]
        for root in roots:
            p = _resolve_under(Path(root), name)
            if p is not None and p.is_file():
                return web.FileResponse(p, headers={
                    "Cache-Control": "public, max-age=3600"})
        log.debug("立绘路径被拒或不存在：%r", name)
        return web.Response(status=404)

    # ==================================================================
    # 请求辅助
    # ==================================================================
    @staticmethod
    async def _body(request: "web.Request") -> Dict[str, Any]:
        """读请求体。空体、坏 JSON、表单都容忍。"""
        try:
            if request.can_read_body:
                ctype = (request.content_type or "").lower()
                if "json" in ctype:
                    d = await request.json()
                    return d if isinstance(d, dict) else {}
                raw = await request.text()
                if not raw.strip():
                    return {}
                try:
                    d = json.loads(raw)
                    return d if isinstance(d, dict) else {}
                except ValueError:
                    return {k: v[0] for k, v in
                            __import__("urllib.parse", fromlist=["parse"])
                            .parse_qs(raw).items()}
        except Exception:                                        # noqa: BLE001
            pass
        return {}

    @staticmethod
    def _char(request: "web.Request", body: Optional[Dict] = None) -> str:
        return str(request.query.get("charId")
                   or (body or {}).get("charId") or "")

    # ==================================================================
    # 状态类
    # ==================================================================
    async def h_health(self, request: "web.Request") -> "web.Response":
        h = self.rt.health()
        h["uptime"] = round(time.time() - self._started_at, 1)
        h["wsClients"] = len(self._clients)
        return _json_ok(h)

    async def h_get_config(self, request: "web.Request") -> "web.Response":
        """★ 前端靠这个决定是否还问 API Key（修"两次让填 Key"）。"""
        cfg = self.rt.to_client_config()
        cfg["initialized"] = bool(self.rt.lives)
        cfg["lives"] = {cid: {"name": lf.name, "who": lf.persona.who}
                        for cid, lf in self.rt.lives.items()}
        cfg["env"] = (self.rt.default_life.env.to_client()
                      if self.rt.default_life else None)
        cfg["needsSetup"] = bool(
            not self.rt.config.get("api_key") and not self.rt.lives)
        return _json_ok(cfg)

    async def h_post_config(self, request: "web.Request") -> "web.Response":
        body = await self._body(request)
        cfg = self.rt.update_config(body)
        # ★ 这里**不再自动建角色**。
        #   首跑应该走欢迎页由用户挑（白子/渐进酱），自动建一个就等于
        #   替用户做了选择，还会把欢迎页整个绕过（实测踩过两次：
        #   `__main__` 里一次、这里一次）。
        #   已经有关卡的老用户不受影响 —— 他们本来就有 lives。
        cfg["initialized"] = bool(self.rt.lives)
        cfg["needsPick"] = bool(self.rt.config.get("api_key")
                                and not self.rt.lives)
        await self.broadcast({"type": "config", "data": cfg})
        return _json_ok(cfg)

    async def h_state(self, request: "web.Request") -> "web.Response":
        f = self.rt.frame_for(self._char(request))
        if f is None:
            # ★ 返回 200 而不是 404。
            #   全新安装时她还没被唤醒（用户还没在欢迎页选角色），
            #   这是**正常状态**不是错误；404 会让前端把它当成故障。
            return _json_ok({"ready": False, "charId": "",
                             "error": "还没有数字生命，请先选择一位"})
        f["ready"] = True
        return _json_ok(f)

    async def h_geometry(self, request: "web.Request") -> "web.Response":
        """★ 小地图几何。默认环境与用户新建环境都从 here 取。"""
        return _json_ok(self.rt.geometry_payload(self._char(request)))

    async def h_regions(self, request: "web.Request") -> "web.Response":
        return _json_ok(self.rt.regions_payload())

    async def h_snn(self, request: "web.Request") -> "web.Response":
        """网络规模与参数（旧版用一个 0–100 滑块驱动 7 个参数）。"""
        return _json_ok(self.rt.snn_payload(self._char(request)))

    async def h_snn_set(self, request: "web.Request") -> "web.Response":
        body = await self._body(request)
        q = body.get("quality")
        params = body.get("params") if isinstance(body.get("params"), dict) else None
        if q is None and params is None:
            # ★ 「网络规模」滑块走的就是这里：前端发的是
            #   {snn_scale: 倍率, snn_memory_bytes: 字节}，**没有 quality/params**。
            #   老实现直接回「需要 quality（0-100）或 params」，
            #   而前端把这条错误静默吞掉了 —— 于是"调网络规模"看着能拖、
            #   实际**从来没生效**（网络没重建，规模一直是旧值）。
            #   这里把它翻译成 neuron_scale 的重建请求。
            if body.get("snn_scale") is not None:
                params = {"neuron_scale": body.get("snn_scale")}
            else:
                return _json_err("需要 quality（0-100）、params 或 snn_scale")
        try:
            q = int(q) if q is not None else None
        except (TypeError, ValueError):
            return _json_err("quality 必须是 0-100 的整数")
        res = await asyncio.to_thread(
            self.rt.apply_quality, q, self._char(request, body),
            params, bool(body.get("rebuild", True)))
        if not res.get("ok"):
            return _json_err(res.get("error", "调整失败"), 400)
        await self.broadcast({"type": "snn", "data": res})
        return _json_ok(res)

    async def h_homeo(self, request: "web.Request") -> "web.Response":
        """26 维的字段字典（中文名 / 单位 / 范围 / 正常区间 / 分组）。

        前端拿它渲染"全量数值面板"与"高级滑块面板"，
        不必自己再维护一份字段表 —— 旧版前端各自维护，两边会漂移。
        """
        from . import homeo as _h
        lf = self.rt.life_for(self._char(request))
        return _json_ok({
            "groups": _h.fields_schema(),
            "count": _h.FIELD_COUNT,
            "values": lf.homeo.state_dict if lf else {},
            "critical": lf.homeo.is_critical() if lf else False,
            "reasons": lf.homeo.critical_reasons() if lf else [],
        })

    async def h_memory(self, request: "web.Request") -> "web.Response":
        d = self.rt.memory_payload(self._char(request))
        if d.get("ok"):
            return _json_ok(d)
        # 同上：还没唤醒不是错误
        return _json_ok({"ready": False, "episodic": [], "unspoken": [],
                         "event_log": [], "dream": None, "is_asleep": False,
                         "stats": {},
                         "error": d.get("error", "还没有数字生命")})

    async def h_personas(self, request: "web.Request") -> "web.Response":
        """两个预设角色的完整定义（给首跑欢迎页用）。

        名字、默认环境与描述、人物 summary、登场白、立绘 —— 全部来自
        旧版前端的 `SHIROKO_CHAR` / `KAKA_CHAR`，不是我编的。
        """
        from . import _persona_data as P
        out = []
        for key, ch in (("shiroko", getattr(P, "SHIROKO_CHAR", {})),
                        ("kaka", getattr(P, "KAKA_CHAR", {}))):
            if not ch:
                continue
            out.append({
                "id": key,
                "name": ch.get("name", ""),
                "envName": ch.get("envName", ""),
                "envDesc": ch.get("envDesc", ""),
                "summary": ch.get("summary", ""),
                "intro": list(ch.get("intro") or []),
                "hasArt": key == "kaka",
            })
        return _json_ok({
            "personas": out,
            "avatars": dict(getattr(P, "AVATARS", {})),
            "default": "kaka",
        })

    async def h_models(self, request: "web.Request") -> "web.Response":        return _json_ok(await asyncio.to_thread(self.rt.list_models))

    async def h_backups(self, request: "web.Request") -> "web.Response":
        return _json_ok({"backups": self.rt.list_backups(),
                         "dir": str(self.rt.backup_dir)})

    async def h_logs(self, request: "web.Request") -> "web.Response":
        lf = self.rt.life_for(self._char(request))
        n = _int(request.query.get("n"), 200)
        return _json_ok({
            "logs": lf.memory.working.recent_log(n) if lf else [],
            "stats": lf.memory.stats() if lf else {}})

    # ==================================================================
    # 对话
    # ==================================================================
    async def h_chat(self, request: "web.Request") -> "web.Response":
        body = await self._body(request)
        text = str(body.get("text") or body.get("message") or "").strip()
        if not text:
            return _json_err("消息为空")
        char_id = self._char(request, body)
        lf = self.rt.life_for(char_id)
        if lf is None:
            return _json_err("没有可用的数字生命", 404)

        stream = str(body.get("stream") or request.query.get("stream") or "") \
            in ("1", "true", "yes")
        # ★ 默认就用大模型：只要配了密钥就该走它。
        #   旧实现要求调用方显式传 llm=true，而前端从来没传过 ——
        #   于是**无论有没有密钥都在跑本地人格引擎**，用户看到的现象
        #   就是"不管选不选演示模式都是演示模式"。现在反过来：
        #   只有显式关掉（llm=0）才强制走本地引擎。
        want = body.get("llm", request.query.get("llm"))
        if want is None:
            use_llm = self.rt.llm_pool.enabled
        else:
            use_llm = (str(want).strip().lower() not in
                       ("0", "false", "no", "off", "none")) \
                and self.rt.llm_pool.enabled

        if stream:
            return await self._chat_stream(request, lf, text, use_llm)

        llm_error = ""
        if use_llm:
            try:
                rep = await asyncio.to_thread(self._llm_reply, lf, text)
            except Exception as e:                               # noqa: BLE001
                # ★ 大模型失败不能把整条对话打成 500 —— 回落本地人格引擎，
                #   并把失败原因带回去（旧实现要求前端显式 llm=1 才走大模型，
                #   于是这个坑一直没人踩到；默认走大模型之后必须兜住）。
                log.warning("大模型回话失败，回落本地人格引擎：%s", e)
                llm_error = str(e)[:200]
                rep = lf.reply(text)
        else:
            rep = lf.reply(text)
        out = {"charId": lf.char_id, "name": lf.name, "who": lf.persona.who,
               "engine": "llm" if rep.source == "llm" else "local",
               "llm_enabled": self.rt.llm_pool.enabled,
               **rep.to_dict()}
        if llm_error:
            out["llm_error"] = llm_error
        await self._forward_qq(lf, rep)
        await self.broadcast({"type": "chat", "charId": lf.char_id,
                              "data": out})
        return _json_ok(out)

    async def _chat_stream(self, request: "web.Request", lf: Any, text: str,
                           use_llm: bool) -> "web.Response":
        """流式回话。

        本地人格引擎本来就是瞬间的，流式主要给 LLM 模式用：
        思维链单独走 `reasoning` 通道，正文走 `text` 通道。

        ★ 写入必须**顺序 await**。早期用 `asyncio.ensure_future(resp.write(...))`
        把写入丢出去不管，`write_eof()` 会抢先关闭响应，得到
        `RuntimeError: Cannot call write() after write_eof()` 且客户端
        只收到一个事件。LLM 的 `on_delta` 是同步回调，所以那里改成入队，
        由异步侧统一排空。
        """
        resp = web.StreamResponse(headers={
            "Content-Type": "text/event-stream; charset=utf-8",
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no"})
        await resp.prepare(request)

        async def send(obj: Dict[str, Any]) -> None:
            await resp.write(("data: " + json.dumps(obj, ensure_ascii=False)
                              + "\n\n").encode("utf-8"))

        try:
            if use_llm:
                msgs = [{"role": "system",
                         "content": lf.build_state_brief(text)}]
                msgs += lf.memory.working.as_messages(8)
                msgs.append({"role": "user", "content": text})

                pending: List[Dict[str, Any]] = []

                def on_delta(kind: str, piece: str) -> None:
                    pending.append({"type": kind, "text": piece})

                client = self.rt.llm_pool.get("language")
                task = asyncio.ensure_future(asyncio.to_thread(
                    client.chat_stream, msgs, on_delta, max_tokens=140,
                    temperature=0.85, effort="none"))
                while not task.done():
                    await asyncio.sleep(0.05)
                    while pending:
                        await send(pending.pop(0))
                while pending:                       # 收尾
                    await send(pending.pop(0))
                res = task.result()
                if not (res.text or "").strip():
                    # ★ 空正文（思考模式吃光预算时会发生）：与非流式一样
                    #   回落本地人格引擎，别让界面上出现一条空气泡。
                    log.warning("大模型回了空正文，回落本地人格引擎")
                    rep0 = lf.reply(text)
                    await send({"type": "text", "text": rep0.text})
                    await send({"type": "done", **rep0.to_dict(),
                                "engine": "local",
                                "llm_error": "大模型返回空正文"})
                else:
                    lf.memory.working.push_dialogue("user", text)
                    lf.memory.working.push_dialogue("char", res.text, lf.name)
                    await send({"type": "done", "text": res.text,
                                "tone": "warm", "model": res.model,
                                "engine": "llm", "source": "llm",
                                "usage": res.usage_line})
            else:
                rep = lf.reply(text)
                if rep.silent:
                    await send({"type": "silent", "tone": "silent",
                                "text": rep.text})
                else:
                    buf = ""
                    for ch in rep.text:
                        buf += ch
                        if len(buf) >= 2:
                            await send({"type": "text", "text": buf})
                            buf = ""
                            await asyncio.sleep(rep.char_ms / 1000.0)
                    if buf:
                        await send({"type": "text", "text": buf})
                await send({"type": "done", **rep.to_dict()})
        except Exception as e:                                   # noqa: BLE001
            log.warning("流式回话失败：%s", e)
            # ★ 大模型挂了不等于她没话说：回落本地人格引擎，
            #   并把失败原因一起交给前端（旧实现只发一条 error，
            #   界面上就是"问了没反应"）。
            try:
                rep = lf.reply(text)
                if rep.silent:
                    await send({"type": "silent", "tone": "silent",
                                "text": rep.text})
                else:
                    await send({"type": "text", "text": rep.text})
                await send({"type": "done", **rep.to_dict(),
                            "engine": "local", "llm_error": str(e)[:200]})
            except Exception:                                    # noqa: BLE001
                try:
                    await send({"type": "error", "error": str(e)[:200]})
                except Exception:                                # noqa: BLE001
                    pass
        try:
            await resp.write_eof()
        except Exception:                                        # noqa: BLE001
            pass
        return resp

    def _llm_reply(self, lf: Any, text: str) -> "persona_mod.Reply":
        """走大模型的回复（同步，供 to_thread 调用）。"""
        client = self.rt.llm_pool.get("language")
        msgs = [{"role": "system", "content": lf.build_state_brief(text)}]
        msgs += lf.memory.working.as_messages(8)
        msgs.append({"role": "user", "content": text})
        res = client.chat(msgs, max_tokens=140, temperature=0.85,
                          effort="none")
        out = (res.text or "").strip()
        if not out:
            return lf.reply(text)               # 空回复 → 回落本地人格
        lf.memory.working.push_dialogue("user", text)
        lf.memory.working.push_dialogue("char", out, lf.name)
        cm, gm = lf.persona.tempo("warm")
        return persona_mod.Reply(text=out, tone="warm", char_ms=cm,
                                 gap_ms=gm, source="llm")

    async def _forward_qq(self, lf: Any, rep: Any) -> None:
        if self.rt.bridge != "qq" or self.rt.onebot is None or rep.silent:
            return
        try:
            self.rt.onebot.send(rep.text)
        except Exception as e:                                   # noqa: BLE001
            log.warning("转发到 QQ 失败：%s", e)

    # ==================================================================
    # 动作类
    # ==================================================================
    async def h_test_key(self, request: "web.Request") -> "web.Response":
        """★ 真的测连通性。第5代前端的同名按钮只弹了个 toast。"""
        body = await self._body(request)
        res = await asyncio.to_thread(
            self.rt.test_api_key, body.get("api_key", ""),
            body.get("api_base", ""), body.get("model", ""))
        return _json_ok(res) if res.get("ok") else _json_err(
            res.get("error", "测试失败"), 200, detail=res)

    async def h_generate_env(self, request: "web.Request") -> "web.Response":
        body = await self._body(request)
        desc = str(body.get("description") or body.get("desc") or "").strip()
        if not desc:
            return _json_err("环境描述为空")
        res = await asyncio.to_thread(self.rt.generate_environment, desc)
        if not res.get("ok"):
            return _json_err(res.get("error", "生成失败"))
        # ★ 生成结果是**给用户看的**：摘要（场景名 / 房间尺寸 / 地标 /
        #   来源 / 是否回落）由 runtime.env_summary 统一给出，
        #   前端会把它摊开显示 —— 旧版只弹一句 toast，
        #   用户于是报"看不见调用 API 生成的结果"。
        await self.broadcast({"type": "geometry", "data": res["spec"]})
        return _json_ok(res)

    async def h_homeo_set(self, request: "web.Request") -> "web.Response":
        """直接干预生理数值（对应旧版的 `homeostasis_set` 单键下发）。

        高级面板的 26 个滑块拖一次发一条；也可以一次发多条。
        数值会被夹到各自的 [lo, hi] 区间，乱填不会把状态打坏。
        """
        from . import homeo as _h
        body = await self._body(request)
        lf = self.rt.life_for(self._char(request, body))
        if lf is None:
            return _json_err("没有可用的数字生命", 404)
        patch = body.get("values") if isinstance(body.get("values"), dict) \
            else body
        applied: Dict[str, float] = {}
        rejected: List[str] = []
        st = lf.homeo.state
        for k, v in patch.items():
            if k in ("charId", "values", "op"):
                continue
            spec = _h.FIELD_MAP.get(k)
            if spec is None:
                rejected.append(k)
                continue
            try:
                f = float(v)
            except (TypeError, ValueError):
                rejected.append(k)
                continue
            if f != f:                                   # NaN
                rejected.append(k)
                continue
            f = spec.clamp(f)
            setattr(st, k, f)
            applied[k] = f
        if applied:
            lf.memory.working.log(
                "Homeo", "外部干预了 %d 项生理数值：%s"
                % (len(applied), "、".join(
                    _h.FIELD_MAP[k].label for k in list(applied)[:5])))
        return _json_ok({"applied": applied, "rejected": rejected,
                         "values": lf.homeo.state_dict})

    async def h_homeo_reset(self, request: "web.Request") -> "web.Response":
        """恢复 26 项为生理默认值（对应旧版 `#adv-reset`）。"""
        from . import homeo as _h
        body = await self._body(request)
        lf = self.rt.life_for(self._char(request, body))
        if lf is None:
            return _json_err("没有可用的数字生命", 404)
        st = lf.homeo.state
        for spec in _h.HOMEOSTATIC_FIELDS:
            setattr(st, spec.key, spec.default)
        lf.memory.working.log("Homeo", "生理数值已恢复默认")
        return _json_ok({"values": lf.homeo.state_dict})

    async def h_action(self, request: "web.Request") -> "web.Response":
        body = await self._body(request)
        act = str(body.get("action") or "").strip()
        if not act:
            return _json_err("缺少 action")
        lf = self.rt.life_for(self._char(request, body))
        if lf is None:
            return _json_err("没有可用的数字生命", 404)
        msg = await asyncio.to_thread(lf.apply_action, act)
        frame = self.rt.frame_for(life=lf) or {}
        await self.broadcast({"type": "frame", "charId": lf.char_id,
                              "name": lf.name, "data": frame})
        return _json_ok({"message": msg, "frame": frame})

    async def h_environment(self, request: "web.Request") -> "web.Response":
        body = await self._body(request)
        spec = body.get("spec") if isinstance(body.get("spec"), dict) else body
        if not isinstance(spec, dict) or not spec:
            return _json_err("缺少环境 spec")
        try:
            g = self.rt.set_environment(
                spec, description=str(body.get("description") or ""))
        except Exception as e:                                   # noqa: BLE001
            return _json_err("环境无法解析：%s" % str(e)[:160])
        await self.broadcast({"type": "geometry", "data": g})
        return _json_ok(g)

    async def h_life(self, request: "web.Request") -> "web.Response":
        body = await self._body(request)
        op = str(body.get("op") or "create").lower()
        if op == "delete":
            cid = self._char(request, body)
            return _json_ok({"removed": self.rt.remove_life(cid)})

        if op == "update":
            # 改名 / 改人物描述（第3代 `#set-char-save`）
            lf = self.rt.life_for(self._char(request, body))
            if lf is None:
                return _json_err("没有可用的数字生命", 404)
            name = str(body.get("name") or "").strip()
            prompt = body.get("prompt")
            if name and name != lf.name:
                lf.name = name
                lf.persona = persona_mod.PersonaEngine(name, lf.rng)
                self.rt._config_dirty = True
            if isinstance(prompt, str) and prompt.strip():
                lf.persona.system_prompt = prompt
            return _json_ok({"name": lf.name, "who": lf.persona.who,
                             "system_prompt": lf.persona.system_prompt})

        name = str(body.get("name") or "").strip()
        spec = body.get("envSpec")
        env = None
        if isinstance(spec, dict) and spec:
            try:
                env = geo.build_from_spec(spec, source="user")
            except Exception:                                    # noqa: BLE001
                env = None
        # ★ 只有**显式**给了 charId 才算指定 id。
        #   用 `self._char()` 会把缺失值回落成空串，再被 create_life 算成
        #   "default"，导致新建角色顶掉默认角色。
        want_id = str(body.get("charId") or "").strip()
        lf = self.rt.create_life(name=name, env=env, char_id=want_id)
        return _json_ok({"charId": lf.char_id, "name": lf.name,
                         "who": lf.persona.who,
                         "env": lf.env.to_client()})

    async def h_reset(self, request: "web.Request") -> "web.Response":
        body = await self._body(request)
        cid = self._char(request, body)
        if not cid and self.rt.default_life is not None:
            cid = self.rt.default_life.char_id      # 没指定就重启默认角色
        okr = self.rt.reset_character(cid)
        return _json_ok({"reset": okr}) if okr else _json_err("角色不存在", 404)

    async def h_backup(self, request: "web.Request") -> "web.Response":
        p = await asyncio.to_thread(self.rt.backup)
        return _json_ok({"file": p.name if p else ""}) if p else \
            _json_err("备份失败", 500)

    async def h_enqueue(self, request: "web.Request") -> "web.Response":
        body = await self._body(request)
        text = str(body.get("text") or "").strip()
        if not text:
            return _json_err("消息为空")
        self.rt.enqueue(text, char_id=self._char(request, body),
                        name=str(body.get("name") or ""),
                        sender=str(body.get("from") or "用户"))
        return _json_ok({"queued": True})

    # ==================================================================
    # 桥接
    # ==================================================================
    async def h_get_bridge(self, request: "web.Request") -> "web.Response":
        return _json_ok(self.rt.to_client_bridge())

    async def h_post_bridge(self, request: "web.Request") -> "web.Response":
        body = await self._body(request)
        res = self.rt.apply_bridge_config(
            str(body.get("bridge") or ""),
            body.get("qq") if isinstance(body.get("qq"), dict) else None)
        if res["bridge"] == "qq":
            await self._ensure_onebot(connect=bool(body.get("connect", True)))
        elif self.rt.onebot is not None:
            await self.rt.onebot.stop()
            self.rt.onebot = None
        out = self.rt.to_client_bridge()
        await self.broadcast({"type": "bridge", "data": out})
        return _json_ok(out)

    async def _ensure_onebot(self, connect: bool = True) -> None:
        qq = self.rt.qq or {}
        if self.rt.onebot is None:
            ob = onebot_mod.OneBotAdapter(
                ws_url=str(qq.get("ws_url") or ""),
                group_id=str(qq.get("group_id") or ""),
                access_token=str(qq.get("access_token") or ""),
                on_message=self._on_qq_message)
            self.rt.onebot = ob
        else:
            self.rt.onebot.configure(
                ws_url=str(qq.get("ws_url") or ""),
                group_id=str(qq.get("group_id") or ""),
                access_token=str(qq.get("access_token") or ""))
        if connect and not self.rt.onebot._running:
            await self.rt.onebot.start()

    def _on_qq_message(self, text: str, sender: str, group_id: str) -> None:
        """QQ 来的消息 → 排队进世界（下个 tick 处理）。"""
        self.rt.enqueue(text, sender=sender)
        lf = self.rt.life_for()
        if lf is not None:
            lf.memory.working.log("QQ", "%s：%s" % (sender, text[:40]))

    # ==================================================================
    # WebSocket
    # ==================================================================
    async def h_ws(self, request: "web.Request") -> "web.WebSocketResponse":
        ws = web.WebSocketResponse(heartbeat=30.0, max_msg_size=2 * 1024 * 1024)
        await ws.prepare(request)
        self._clients.add(ws)
        log.info("前端已连接（当前 %d 个）", len(self._clients))

        try:
            # 握手：把配置与几何一次性给全，前端不必再发一堆请求
            lf = self.rt.default_life
            await ws.send_str(json.dumps({
                "type": "hello",
                "data": {
                    **self.rt.to_client_config(),
                    "clock": self.rt.clock.to_dict(),
                    "geometry": self.rt.geometry_payload(),
                    "regions": self.rt.regions_payload(),
                    "lives": {cid: {"name": x.name, "who": x.persona.who}
                              for cid, x in self.rt.lives.items()},
                    "frame": (self.rt.frame_for(life=lf) or {}) if lf
                    else None,
                    "bridge": self.rt.to_client_bridge(),
                }}, ensure_ascii=False))

            async for msg in ws:
                if msg.type == WSMsgType.TEXT:
                    await self._ws_message(ws, msg.data)
                elif msg.type == WSMsgType.ERROR:
                    break
        except asyncio.CancelledError:
            raise
        except Exception as e:                                   # noqa: BLE001
            log.debug("WS 异常：%s", e)
        finally:
            self._clients.discard(ws)
            log.info("前端已断开（剩余 %d 个）", len(self._clients))
        return ws

    async def _ws_message(self, ws: Any, raw: str) -> None:
        try:
            d = json.loads(raw)
        except (ValueError, TypeError):
            return
        if not isinstance(d, dict):
            return
        t = str(d.get("type") or "")
        if t == "ping":
            await ws.send_str(json.dumps({"type": "pong",
                                          "t": time.time()}))
        elif t == "chat":
            text = str(d.get("text") or "").strip()
            if not text:
                return
            lf = self.rt.life_for(str(d.get("charId") or ""))
            if lf is None:
                return
            # ★ WS 也是对话入口，必须和 /api/chat 走同一套规则：
            #   配了密钥就用大模型，失败回落本地并说明原因。
            #   （原来这里写死 lf.reply()，于是同一个软件两个入口两种行为。）
            engine = "local"
            llm_error = ""
            rep = None
            if self.rt.llm_pool.enabled:
                try:
                    rep = await asyncio.to_thread(self._llm_reply, lf, text)
                    engine = "llm"
                except Exception as e:                           # noqa: BLE001
                    log.warning("WS 大模型回话失败，回落本地：%s", e)
                    llm_error = str(e)[:200]
            if rep is None:
                rep = lf.reply(text)
            data = {"name": lf.name, "engine": engine, **rep.to_dict()}
            if llm_error:
                data["llm_error"] = llm_error
            await ws.send_str(json.dumps(
                {"type": "chat", "charId": lf.char_id, "data": data},
                ensure_ascii=False))
            await self._forward_qq(lf, rep)
        elif t == "subscribe":
            lf = self.rt.life_for(str(d.get("charId") or ""))
            if lf is not None:
                await ws.send_str(json.dumps(
                    {"type": "frame", "charId": lf.char_id, "name": lf.name,
                     "data": self.rt.frame_for(life=lf) or {}}, ensure_ascii=False))
                await ws.send_str(json.dumps(
                    {"type": "geometry",
                     "data": self.rt.geometry_payload()},
                    ensure_ascii=False))
        elif t == "action":
            lf = self.rt.life_for(str(d.get("charId") or ""))
            if lf is not None:
                lf.apply_action(str(d.get("action") or ""))


# ======================================================================
def create_app(runtime: "rt_mod.Runtime", **kw) -> "web.Application":
    return ShirokoServer(runtime, **kw).app


__all__ = ["ShirokoServer", "create_app", "HAVE_AIOHTTP",
           "BOOT_PLACEHOLDER"]
