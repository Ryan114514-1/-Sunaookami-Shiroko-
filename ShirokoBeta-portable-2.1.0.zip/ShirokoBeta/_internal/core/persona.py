# -*- coding: utf-8 -*-
"""
Shiroko β —— 人格引擎

两个角色
--------
    砂狼白子（Sunaookami Shiroko）  阿拜多斯的学生。冷静、话少、有沉默权。
    渐进酱（Kaka）                  机房硬件的整体拟人。话痨、护短、怕热但不抱怨。

关系（设定原文）：「白子是跑在机器里的灵魂，她是机器本身的意识；
白子是住客，她是房子。」—— 两人不是并列的两个聊天对象，是同一台机器的
灵魂与身体。

语言库来源
----------
所有台词、语气分类、硬件词表、护短词表都从旧版前端
`galbeta.html` **原样提取**到 `core/_language_data.py`，不是我编的。
改动语言请改提取脚本或该数据文件。

本模块负责：**从生理状态选语气 → 挑台词 → 填占位符 → 决定说不说**
"""

from __future__ import annotations

import random
import threading
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Sequence, Tuple

from . import _language_data as LANG

SHIROKO_NAME = "砂狼白子"
KAKA_NAME = "渐进酱"

# ----------------------------------------------------------------------
# 人格参数（第3代定标值）
# ----------------------------------------------------------------------
PERSONA_CFG: Dict[str, float] = {
    "heat_core": 37.35,      # 核心温度阈值：超过算"热"
    "heat_sweat": 0.32,      # 出汗率阈值
    "sharpen": 3.0,          # 语气权重幂次（放大差异）
    "glitch_chance": 0.34,   # 渐进酱口误概率
    "silence_base": 0.06,    # 白子基础沉默概率
    "silence_cap": 0.58,     # 沉默概率上限
}

# 单位换算（第1代 `CHARACTER_PROFILE` 的"身体是砖头"设定）
SHIROKO_SILENCE_RULES: Tuple[Tuple[str, float, float], ...] = (
    # (生理字段, 阈值, 沉默概率增量)
    ("sleep_pressure", 0.70, 0.34),
    ("sleep_pressure", 0.55, 0.16),
    ("central_fatigue", 0.70, 0.20),
    ("muscle_fatigue", 0.80, 0.12),
)
SHIROKO_HOT_SILENCE = 0.16      # core_temp ≥ 37.8 时的额外沉默
SHIROKO_LOW_GLUCOSE = 0.10      # glucose ≤ 3.6 时的额外沉默

# 渐进酱语气的时序（字符间隔 ms, 句间停顿 ms）
KAKA_TEMPO: Dict[str, Tuple[int, int]] = {
    "hype": (12, 380), "stress": (16, 210), "guard": (30, 900),
    "tired": (42, 620), "heat": (30, 500),
}
KAKA_TEMPO_DEFAULT = (22, 420)
SHIROKO_CHAR_MS = 34
SHIROKO_GAP_MIN, SHIROKO_GAP_SPAN = 460, 520
SHIROKO_SILENT_GAP = 900


@dataclass
class Reply:
    """一次回复。silent=True 表示她决定不说话。"""

    text: str = ""
    tone: str = "idle"
    silent: bool = False
    guard: bool = False               # 是否触发了"护短"语气
    char_ms: int = 22                 # 每个字的间隔
    gap_ms: int = 420                 # 说完后的停顿
    source: str = "local"             # local | llm
    weights: Dict[str, float] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "text": self.text, "tone": self.tone, "silent": self.silent,
            "guard": self.guard, "charMs": self.char_ms,
            "gapMs": self.gap_ms, "source": self.source,
        }


# ----------------------------------------------------------------------
class PersonaEngine:
    """一个人格实例。每个数字生命持有一个。"""

    # 最近说过的句子（避免重复）。语气库只有 7–8 句，纯随机必然撞车 ——
    # 实测 6 次主动发言里 2 句重复了两遍，读起来很出戏。
    _RECENT_MAX = 6

    def __init__(self, name: str = SHIROKO_NAME,
                 rng: Optional[random.Random] = None) -> None:
        self.name = name or SHIROKO_NAME
        self.rng = rng or random.Random(20261002)
        self._lock = threading.RLock()
        self.system_prompt = self._pick_system_prompt()
        self._recent: List[str] = []

    # ------------------------------------------------------------------
    def pick_fresh(self, bank: Sequence[str]) -> str:
        """从语气库里挑一句**最近没说过的**。

        库比 `_RECENT_MAX` 小的时候（极端情况）退化成纯随机，
        否则会死循环。
        """
        pool = list(bank or ())
        if not pool:
            return ""
        if len(pool) <= 1:
            return pool[0]
        avoid = set(self._recent)
        cands = [s for s in pool if s not in avoid]
        if not cands:                      # 全说过了 → 清空重来
            self._recent.clear()
            cands = pool
        pick = self.rng.choice(cands)
        self._recent.append(pick)
        if len(self._recent) > self._RECENT_MAX:
            self._recent.pop(0)
        return pick

    # ------------------------------------------------------------------
    @property
    def who(self) -> str:
        """'shiroko' 或 'kaka'。"""
        return "kaka" if ("渐进" in self.name or "卡" in self.name) else "shiroko"

    @property
    def is_kaka(self) -> bool:
        return self.who == "kaka"

    def _pick_system_prompt(self) -> str:
        if self.is_kaka:
            return getattr(LANG, "KAKA_PROMPT", "") or ""
        return (getattr(LANG, "SHIROKO_PROMPT", "")
                or getattr(LANG, "DEFAULT_CHAR_PROMPT", "") or "")

    # ==================================================================
    # 白子：沉默权
    # ==================================================================
    def silence_chance(self, h: Dict[str, float]) -> float:
        """她要开口的概率上限由身体决定。

        这是白子最核心的设定：**对讲机响了，她不一定理**。
        """
        p = PERSONA_CFG["silence_base"]
        for key, thr, add in SHIROKO_SILENCE_RULES:
            if _f(h.get(key)) >= thr:
                p += add if thr >= 0.70 or key == "central_fatigue" else add
        if _f(h.get("core_temp"), 37.0) >= 37.8:
            p += SHIROKO_HOT_SILENCE
        if _f(h.get("glucose"), 5.0) <= 3.6:
            p += SHIROKO_LOW_GLUCOSE
        return min(p, PERSONA_CFG["silence_cap"])

    # ==================================================================
    # 白子：语气选择
    # ==================================================================
    @staticmethod
    def _asked(text: str) -> bool:
        t = str(text or "")
        if "?" in t or "？" in t:
            return True
        return any(k in t for k in ("怎么", "为什么", "如何", "能不能",
                                    "有没有", "是不是", "吗"))

    def pick_shiroko_tone(self, h: Dict[str, float], text: str = "") -> str:
        if _f(h.get("core_temp"), 37.0) >= 37.6:
            return "hot"
        if (_f(h.get("sleep_pressure")) >= 0.62
                or _f(h.get("central_fatigue")) >= 0.62):
            return "tired"
        if _f(h.get("glucose"), 5.0) <= 3.9 or _f(h.get("hunger")) >= 0.66:
            return "hungry"
        if self._asked(text):
            return "present"
        return "present" if self.rng.random() < 0.34 else "warm"

    # ==================================================================
    # 渐进酱：加权语气选择
    # ==================================================================
    @staticmethod
    def _hits(text: str, words: Sequence[str]) -> int:
        t = str(text or "").lower()
        return sum(1 for w in words if w and str(w).lower() in t)

    def kaka_weights(self, h: Dict[str, float], text: str = "",
                     surprise: float = 0.0) -> Dict[str, float]:
        """8 路语气权重。

        规则来自第3代：护短和兴奋优先，其次热/累/饿/应激，都平就 idle。
        """
        w = {k: 1.0 for k in LANG.VOICE}
        guard_hits = self._hits(text, LANG.GUARD_WORDS)
        hype_hits = self._hits(text, LANG.HYPE_WORDS)
        if guard_hits:
            w["guard"] += 8.0 + 2.0 * guard_hits
        if hype_hits:
            w["hype"] += 2.0 + 1.5 * hype_hits

        core = _f(h.get("core_temp"), 37.0)
        sweat = _f(h.get("sweating_rate"))
        muscle = _f(h.get("muscle_fatigue"))
        sleep = _f(h.get("sleep_pressure"))
        central = _f(h.get("central_fatigue"))
        glucose = _f(h.get("glucose"), 5.0)
        hunger = _f(h.get("hunger"))
        adr = _f(h.get("adrenaline"))
        cortisol = _f(h.get("cortisol"), 10.0)
        valence = _f(h.get("valence"))

        if core >= PERSONA_CFG["heat_core"]:
            w["heat"] += 3.5
        if sweat >= PERSONA_CFG["heat_sweat"]:
            w["heat"] += 1.5
        if muscle >= 0.66 or sleep >= 0.64:
            w["tired"] += 3.5
        if central >= 0.60:
            w["tired"] += 2.0
        if glucose <= 4.2 or hunger >= 0.62:
            w["hungry"] += 3.0
        if adr >= 0.62 or cortisol >= 20.0:
            w["stress"] += 3.0
        if valence <= -0.15:
            w["warm"] += 2.0
        if surprise >= 0.7:
            w["hype"] += 1.5

        # 六路都平（没有明显倾向）→ 让 idle 接管
        if sum(w[k] for k in ("guard", "hype", "heat", "tired",
                              "hungry", "stress")) <= 6.0:
            w["idle"] += 6.0
        return w

    def pick_kaka_tone(self, h: Dict[str, float], text: str = "",
                       surprise: float = 0.0) -> Tuple[str, Dict[str, float]]:
        w = self.kaka_weights(h, text, surprise)
        keys = list(w)
        # 用 w^sharpen 放大差异后做累积采样
        weights = [max(1e-6, w[k]) ** PERSONA_CFG["sharpen"] for k in keys]
        total = sum(weights)
        r = self.rng.random() * total
        acc = 0.0
        for k, wt in zip(keys, weights):
            acc += wt
            if r <= acc:
                return k, w
        return keys[-1], w

    # ==================================================================
    # 占位符替换（渐进酱的台词里有 {call} {V} {S} {F} {A} {B} {N}）
    # ==================================================================
    def fill(self, text: str, h: Dict[str, float],
             user_name: str = "") -> str:
        if "{" not in text:
            return text
        core = _f(h.get("core_temp"), 37.0)
        sweat = _f(h.get("sweating_rate"))
        glucose = _f(h.get("glucose"), 5.0)
        adr = _f(h.get("adrenaline"))
        out = str(text)
        out = out.replace("{call}", user_name or "老板")
        out = out.replace("{V}", "%.1f" % core)
        out = out.replace("{S}", "%.2f" % sweat)
        out = out.replace("{F}", "%.1f" % glucose)
        out = out.replace("{A}", "%.2f" % adr)
        out = out.replace("{B}", "%d" % (int(sweat * 100) % 40 + 8))
        out = out.replace("{N}", "%d" % self.rng.randint(80, 980))
        return out

    # ==================================================================
    # 口误纠正（渐进酱的"旧硬件"设定）
    # ==================================================================
    def glitch(self, text: str) -> str:
        if not LANG.GLITCHES or self.rng.random() > PERSONA_CFG["glitch_chance"]:
            return text
        return self.rng.choice(LANG.GLITCHES) + "\n" + text

    # ==================================================================
    # 时序
    # ==================================================================
    def tempo(self, tone: str) -> Tuple[int, int]:
        if self.is_kaka:
            cm, gm = KAKA_TEMPO.get(tone, KAKA_TEMPO_DEFAULT)
            return cm, gm + int(self.rng.random() * 260)
        # 白子
        if tone == "silent":
            return SHIROKO_CHAR_MS, SHIROKO_SILENT_GAP
        return SHIROKO_CHAR_MS, (SHIROKO_GAP_MIN
                                 + int(self.rng.random() * SHIROKO_GAP_SPAN))

    # ==================================================================
    # 主入口
    # ==================================================================
    def compose(self, h: Any, user_text: str = "", *,
                surprise: float = 0.0, pre_react: bool = True,
                user_name: str = "") -> Reply:
        """按当前身体状态生成一句回复（本地语言库，不调 LLM）。"""
        hh = _as_dict(h)
        with self._lock:
            if self.is_kaka:
                return self._compose_kaka(hh, user_text, surprise, pre_react,
                                          user_name)
            return self._compose_shiroko(hh, user_text)

    def _compose_shiroko(self, h: Dict[str, float], user_text: str) -> Reply:
        # 沉默权优先于一切
        if user_text and self.rng.random() < self.silence_chance(h):
            cm, gm = self.tempo("silent")
            return Reply(text="", tone="silent", silent=True,
                         char_ms=cm, gap_ms=gm, source="local")

        tone = self.pick_shiroko_tone(h, user_text)
        bank = LANG.SHIROKO_TONE.get(tone) or LANG.SHIROKO_TONE.get("warm") or [""]
        text = self.fill(self.pick_fresh(bank), h)
        cm, gm = self.tempo(tone)
        return Reply(text=text, tone=tone, char_ms=cm, gap_ms=gm,
                     source="local")

    def _compose_kaka(self, h: Dict[str, float], user_text: str,
                      surprise: float, pre_react: bool,
                      user_name: str) -> Reply:
        tone, w = self.pick_kaka_tone(h, user_text, surprise)
        bank = LANG.VOICE.get(tone) or LANG.VOICE.get("idle") or [""]
        text = self.fill(self.pick_fresh(bank), h, user_name)

        if pre_react and tone in ("hype", "stress") and self.rng.random() < 0.45:
            if LANG.PRE_REACT:
                text = self.pick_fresh(LANG.PRE_REACT) + text
        if tone == "hype":
            text = self.glitch(text)

        cm, gm = self.tempo(tone)
        return Reply(text=text, tone=tone, guard=(tone == "guard"),
                     char_ms=cm, gap_ms=gm, source="local", weights=w)

    # ==================================================================
    # 主动开口（不是被问，而是自己想说）
    # ==================================================================
    def idle_line(self, h: Any) -> Optional[Reply]:
        hh = _as_dict(h)
        with self._lock:
            if self.is_kaka:
                if not LANG.IDLE_VOICE:
                    return None
                text = self.fill(self.pick_fresh(LANG.IDLE_VOICE), hh)
                cm, gm = self.tempo("idle")
                return Reply(text=text, tone="idle", char_ms=cm, gap_ms=gm)
            if not LANG.SHIROKO_IDLE:
                return None
            # 越累越少主动开口
            if self.rng.random() < self.silence_chance(hh) + 0.25:
                return None
            text = self.fill(self.pick_fresh(LANG.SHIROKO_IDLE), hh)
            cm, gm = self.tempo("warm")
            return Reply(text=text, tone="warm", char_ms=cm, gap_ms=gm)

    # ==================================================================
    # 跨角色认知：读不到对方状态就返回空串，**绝不编造数值**
    # ==================================================================
    def other_status_line(self, other_homeo: Any,
                          other_env: Any = None) -> str:
        """她注意到对方（另一个角色）的身体状况时说的话。

        这是第3代独有的设定：白子会关心渐进酱过热，渐进酱会关心白子累了。
        """
        if other_homeo is None:
            return ""
        o = _as_dict(other_homeo)
        core = _f(o.get("core_temp"), 37.0)
        sweat = _f(o.get("sweating_rate"))
        muscle = _f(o.get("muscle_fatigue"))
        sleep = _f(o.get("sleep_pressure"))
        glucose = _f(o.get("glucose"), 5.0)
        glycogen = _f(o.get("liver_glycogen"), 100.0)
        env_temp = 22.0
        if isinstance(other_env, dict):
            amb = other_env.get("ambient") or {}
            env_temp = _f(amb.get("temperature"), 22.0)

        if self.is_kaka:
            # 渐进酱看白子
            if core < 36.2:
                return "白子那边……核心温度 %.1f，有点凉。我把机柜风道调小一点。" % core
            if core >= 37.6:
                return "白子烧到 %.1f 了。降温，马上降温。" % core
            if glycogen < 60:
                return "白子的肝糖原只剩 %.0f 了，得让她吃点东西。" % glycogen
            if sleep > 0.60:
                return "白子睡眠压力 %.2f……今晚别叫她。" % sleep
            if glucose < 4.0:
                return "白子血糖 %.1f，偏低。我去看看有没有零食。" % glucose
            return ""
        # 白子看渐进酱
        if core > 37.4:
            return "……你太热了。"
        if sweat > 0.3:
            return "风扇开到最大了。歇一会。"
        if muscle > 0.70:
            return "别硬撑。"
        if env_temp > 28.0:
            return "……机房进风温度偏高。"
        return ""

    def mentions_other(self, text: str) -> bool:
        """这句话里有没有提到对方。"""
        t = str(text or "")
        if self.is_kaka:
            return ("白子" in t) or ("砂狼" in t)
        return ("渐进" in t) or ("卡卡" in t) or ("机房" in t)

    # ------------------------------------------------------------------
    def describe(self) -> Dict[str, Any]:
        return {
            "who": self.who, "name": self.name,
            "system_prompt_len": len(self.system_prompt),
            "tones": (list(LANG.VOICE) if self.is_kaka
                      else list(LANG.SHIROKO_TONE)),
            "bank_size": sum(len(v) for v in
                             (LANG.VOICE if self.is_kaka
                              else LANG.SHIROKO_TONE).values()),
        }


def _f(v: Any, default: float = 0.0) -> float:
    if isinstance(v, bool):
        return default
    if isinstance(v, (int, float)):
        return float(v)
    return default


def _as_dict(h: Any) -> Dict[str, float]:
    if h is None:
        return {}
    if isinstance(h, dict):
        return {k: float(v) for k, v in h.items()
                if isinstance(v, (int, float)) and not isinstance(v, bool)}
    out: Dict[str, float] = {}
    for k in ("hunger", "thirst", "muscle_fatigue", "sleep_pressure",
              "pain_level", "adrenaline", "cortisol", "glucose", "core_temp",
              "sweating_rate", "central_fatigue", "liver_glycogen",
              "heart_rate", "valence", "arousal"):
        v = getattr(h, k, None)
        if isinstance(v, (int, float)) and not isinstance(v, bool):
            out[k] = float(v)
    return out


__all__ = [
    "PersonaEngine", "Reply", "SHIROKO_NAME", "KAKA_NAME", "PERSONA_CFG",
    "SHIROKO_SILENCE_RULES", "KAKA_TEMPO", "KAKA_TEMPO_DEFAULT",
    "SHIROKO_CHAR_MS",
]
