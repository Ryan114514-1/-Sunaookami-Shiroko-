# -*- coding: utf-8 -*-
"""
Shiroko β —— QQ / OneBot 桥接（客户端模式）

第2代有完整实现（`OneBotAdapter`），第3代整块删掉。这里是重写版。

两种模式的区别（旧版各代不一样，别混）
--------------------------------------
    服务端模式（demo s β / demo3β / demo4β）
        她开一个 WS 服务，等 OneBot 实现连进来。端口写死 3334。

    客户端模式（第2代 —— 本模块采用）
        她主动连到 OneBot 实现（LLOneBot / NapCat / Lagrange.Core）。
        好处：重连由自己控制，能带 access_token，能看连接状态。

用 aiohttp 而不是 websockets
----------------------------
旧版演示脚本用 `websockets.serve`，那是**另一个依赖**。
本项目已经依赖 aiohttp（HTTP 服务用），它自带 `ws_connect`
且支持 heartbeat / max_msg_size / timeout，所以不再引入新依赖。

消息流
------
    QQ 群 → OneBot 实现 → 本模块 WS → rt.enqueue() → 下一个 tick
    → 她回复 → 本模块 send_group_msg → OneBot 实现 → QQ 群
"""

from __future__ import annotations

import asyncio
import json
import logging
import time
from typing import Any, Callable, Dict, List, Optional

log = logging.getLogger("shiroko.onebot")

# 重连退避（第2代：3 → 60 秒，×1.5）
RECONNECT_BASE = 3.0
RECONNECT_MAX = 60.0
RECONNECT_FACTOR = 1.5

CONNECT_TIMEOUT = 15.0
HEARTBEAT = 25.0
MAX_MSG_SIZE = 4 * 1024 * 1024        # 4 MB（第2代）
QUEUE_MAX = 200                        # 第2代 incoming Queue(200)

# 本模块向外塞消息时的回调签名
EnqueueFn = Callable[[str, str, str], None]      # (text, sender, group_id)


class OneBotAdapter:
    """OneBot v11 客户端。

    用法：
        ob = OneBotAdapter("ws://127.0.0.1:3001", "123456", "token")
        ob.on_message = lambda text, sender, gid: rt.enqueue(...)
        await ob.start()          # 后台自动重连
        ob.send("在。")            # 她的话发回群里
        await ob.stop()
    """

    def __init__(self, ws_url: str = "ws://127.0.0.1:3001",
                 group_id: str = "", access_token: str = "",
                 *, on_message: Optional[EnqueueFn] = None,
                 reply_to_private: bool = False) -> None:
        self.ws_url = str(ws_url or "").strip()
        self.group_id = str(group_id or "").strip()
        self.access_token = str(access_token or "").strip()
        self.on_message = on_message
        self.reply_to_private = reply_to_private

        self._session: Optional[Any] = None         # aiohttp.ClientSession
        self._ws: Optional[Any] = None
        self._task: Optional[asyncio.Task] = None
        self._stop: Optional[asyncio.Event] = None
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._running = False
        self._backoff = RECONNECT_BASE

        # 统计（第2代 `status()` 的 9 个字段）
        self.connected = False
        self.last_error = ""
        self.received = 0
        self.sent = 0
        self.errors = 0
        self.connected_at = 0.0
        self._pending: List[str] = []
        # 最近一次会话目标（回复时用）
        self._last_group = ""
        self._last_user = ""

    # ==================================================================
    # 生命周期
    # ==================================================================
    async def start(self) -> None:
        """开始后台连接（自动重连，不会抛异常）。"""
        if self._running:
            return
        self._running = True
        self._loop = asyncio.get_running_loop()
        self._stop = asyncio.Event()
        self._task = self._loop.create_task(self._loop_fn(), name="onebot")
        log.info("QQ 桥接已启动 → %s（群 %s）",
                 self.ws_url or "(未配置)", self.group_id or "(未配置)")

    async def stop(self) -> None:
        self._running = False
        if self._stop is not None:
            self._stop.set()
        if self._task is not None:
            self._task.cancel()
            try:
                await self._task
            except (asyncio.CancelledError, Exception):          # noqa: BLE001
                pass
            self._task = None
        await self._close_ws()
        if self._session is not None:
            try:
                await self._session.close()
            except Exception:                                    # noqa: BLE001
                pass
            self._session = None
        self.connected = False
        log.info("QQ 桥接已停止")

    async def _close_ws(self) -> None:
        ws, self._ws = self._ws, None
        self.connected = False
        if ws is not None:
            try:
                await ws.close()
            except Exception:                                    # noqa: BLE001
                pass

    # ==================================================================
    # 连接循环
    # ==================================================================
    async def _loop_fn(self) -> None:
        """连接 → 收发 → 断开 → 退避重连。"""
        import aiohttp
        while self._running and not self._stop.is_set():
            if not self.ws_url:
                log.debug("未配置 QQ 地址，桥接空转")
                if await self._sleep(10.0):
                    return
                continue
            try:
                if self._session is None or self._session.closed:
                    self._session = aiohttp.ClientSession(
                        timeout=aiohttp.ClientTimeout(total=None,
                                                      connect=CONNECT_TIMEOUT))
                headers = {}
                if self.access_token:
                    headers["Authorization"] = "Bearer " + self.access_token
                ws = await self._session.ws_connect(
                    self.ws_url, headers=headers, heartbeat=HEARTBEAT,
                    max_msg_size=MAX_MSG_SIZE, autoping=True)
                self._ws = ws
                self.connected = True
                self.connected_at = time.time()
                self.last_error = ""
                self._backoff = RECONNECT_BASE
                log.info("QQ 桥接已连接：%s", self.ws_url)
                await self._flush_pending()      # 连上后补发排队的话
                await self._pump(ws)
            except asyncio.CancelledError:
                raise
            except Exception as e:                               # noqa: BLE001
                self.errors += 1
                self.last_error = "%s: %s" % (type(e).__name__, str(e)[:120])
                log.warning("QQ 桥接断开（%s），%.1f 秒后重连",
                            self.last_error, self._backoff)
            finally:
                await self._close_ws()
            if await self._sleep(self._backoff):
                return
            self._backoff = min(RECONNECT_MAX,
                                self._backoff * RECONNECT_FACTOR)

    async def _sleep(self, sec: float) -> bool:
        """可被 stop 打断的 sleep。返回 True 表示应当退出。"""
        if self._stop is None:
            await asyncio.sleep(sec)
            return not self._running
        try:
            await asyncio.wait_for(self._stop.wait(), timeout=sec)
            return True
        except asyncio.TimeoutError:
            return not self._running

    async def _pump(self, ws: Any) -> None:
        """读消息。"""
        import aiohttp
        async for msg in ws:
            if msg.type == aiohttp.WSMsgType.TEXT:
                self._handle_raw(msg.data)
            elif msg.type == aiohttp.WSMsgType.BINARY:
                try:
                    self._handle_raw(msg.data.decode("utf-8", "replace"))
                except Exception:                                # noqa: BLE001
                    self.errors += 1
            elif msg.type in (aiohttp.WSMsgType.CLOSED,
                              aiohttp.WSMsgType.ERROR):
                break

    # ==================================================================
    # 处理收到的消息
    # ==================================================================
    def _handle_raw(self, raw: str) -> None:
        try:
            d = json.loads(raw)
        except (ValueError, TypeError):
            return
        if not isinstance(d, dict):
            return
        # 心跳包（OneBot 会定期发 meta_event）
        if d.get("post_type") == "meta_event":
            return
        if d.get("post_type") != "message":
            return                       # 心跳（meta_event）与 API 回执不计入

        text = str(d.get("raw_message") or d.get("message") or "").strip()
        if not text:
            return
        # 去掉 @机器人 之类的 CQ 码
        text = _strip_cq(text)
        if not text:
            return

        # 计数放在**所有过滤之后** —— 只有真正会被处理的消息才算收到。
        # 早期写法把它放在 post_type 判断之前，心跳包也会把计数顶上去。
        self.received += 1

        sender = ""
        s = d.get("sender")
        if isinstance(s, dict):
            sender = str(s.get("card") or s.get("nickname") or "").strip()
        sender = sender or str(d.get("user_id") or "群友")

        if d.get("message_type") == "group":
            gid = str(d.get("group_id") or "")
            if self.group_id and gid != self.group_id:
                return                       # 只理配置的那个群
        else:
            if not self.reply_to_private:
                return                       # 默认不理私聊
            gid = "private:" + str(d.get("user_id") or "")

        self._remember_group(gid, d.get("message_type"))
        if self.on_message is not None:
            try:
                self.on_message(text, sender, gid)
            except Exception as e:                               # noqa: BLE001
                self.errors += 1
                log.warning("处理 QQ 消息失败：%s", e)

    def _remember_group(self, gid: str, mtype: Any) -> None:
        """记住最近一次会话，回复时用得上。"""
        if gid and not str(gid).startswith("private"):
            self._last_group = str(gid)
        elif mtype == "private":
            self._last_user = gid

    # ==================================================================
    # 发送
    # ==================================================================
    def send(self, text: str) -> bool:
        """发一句话。没连上时排队，连上后自动补发。

        这是**同步**接口（她的回复生成在同步上下文里），
        内部把实际发送用 `run_coroutine_threadsafe` 丢回事件循环。
        """
        t = str(text or "").strip()
        if not t:
            return False
        if not self.connected or self._ws is None or self._loop is None:
            if len(self._pending) < QUEUE_MAX:
                self._pending.append(t)
            return False
        try:
            asyncio.run_coroutine_threadsafe(self._send_text(t), self._loop)
            return True
        except Exception as e:                                   # noqa: BLE001
            self.errors += 1
            log.warning("QQ 发送失败：%s", e)
            if len(self._pending) < QUEUE_MAX:
                self._pending.append(t)
            return False

    async def _send_text(self, text: str) -> None:
        ws = self._ws
        if ws is None:
            return
        gid = self._last_group or self.group_id
        if gid:
            payload = {"action": "send_group_msg",
                       "params": {"group_id": _as_int(gid), "message": text}}
        else:
            payload = {"action": "send_private_msg",
                       "params": {"user_id": _as_int(self._last_user),
                                  "message": text}}
        await ws.send_str(json.dumps(payload, ensure_ascii=False))
        self.sent += 1
        log.debug("QQ 已发送：%s", text[:40])

    async def _flush_pending(self) -> None:
        if not self._pending:
            return
        pending, self._pending = self._pending[:20], self._pending[20:]
        for t in pending:
            try:
                await self._send_text(t)
            except Exception:                                    # noqa: BLE001
                break

    # ==================================================================
    # 状态（第2代 status() 的 9 个字段）
    # ==================================================================
    def status(self) -> Dict[str, Any]:
        return {
            "connected": bool(self.connected),
            "url": self.ws_url,
            "group_id": self.group_id,
            "has_token": bool(self.access_token),
            "queued": len(self._pending),
            "messages_received": self.received,
            "messages_sent": self.sent,
            "errors": self.errors,
            "last_error": self.last_error,
            "connected_seconds": round(time.time() - self.connected_at, 1)
            if self.connected else 0.0,
        }

    def configure(self, ws_url: str = "", group_id: str = "",
                  access_token: str = "") -> Dict[str, Any]:
        """改配置。地址变了需要重连才生效。"""
        changed = False
        if ws_url and ws_url != self.ws_url:
            self.ws_url, changed = str(ws_url).strip(), True
        if group_id is not None and str(group_id) != self.group_id:
            self.group_id, changed = str(group_id).strip(), True
        if access_token is not None and str(access_token) != self.access_token:
            self.access_token, changed = str(access_token).strip(), True
        return {"changed": changed, "status": self.status()}


# ----------------------------------------------------------------------
def _strip_cq(text: str) -> str:
    """去掉 CQ 码（`[CQ:at,qq=123]` 之类）。"""
    import re
    out = re.sub(r"\[CQ:[^\]]*\]", "", str(text or ""))
    return out.strip()


def _as_int(v: Any) -> Any:
    try:
        return int(str(v))
    except (TypeError, ValueError):
        return v


__all__ = ["OneBotAdapter", "RECONNECT_BASE", "RECONNECT_MAX",
           "RECONNECT_FACTOR", "CONNECT_TIMEOUT", "HEARTBEAT",
           "MAX_MSG_SIZE", "QUEUE_MAX"]
