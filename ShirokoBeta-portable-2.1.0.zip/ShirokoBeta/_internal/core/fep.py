# -*- coding: utf-8 -*-
"""
Shiroko β —— 自由能原理（FEP）与期望自由能（EFE）

分两层，别混
------------
**第一层：变分自由能 F**（第 2/3 代都有）

    F = KL[q(θ) ‖ p(θ)] − E_q[log p(o|θ)]
      = 复杂度 − 准确度

每个脑区维护一个高斯后验 q(θ)=N(mu, e^{log_var}) 与先验 p(θ)=N(prior_mu, prior_var)，
用当前观测做一步梯度下降。F 越低表示"预测得越好"。

**第二层：期望自由能 EFE**（★ 只有 demo4β 有，第 1/2/3 代都没有）

动作选择不是"哪个动作让当前 F 最低"，而是"哪个动作能让**未来**的 F 最低"。
这需要世界模型：

    pragmatic   = Σ weights[v]·[(当前值−目标)² − (预测值−目标)²]
                  这个动作能让身体离目标近多少
    complexity  = 动作本身要付出多少代价（耗能、费劲）
    epistemic   = 能满足多少好奇（去看看没看过的地方）

    EFE = −pragmatic + complexity − epistemic        取 **min**

用户最初抱怨"脑区和自由能好像也都是假的"，根因就是这一层从来没接过 ——
旧版只有作者自述的启发式 `action_scores`。本模块把它真正实现出来。

--------------------------------------------------------------------------
标定与修复记录（都基于实测）

  · SIGMA_OBS 第2代取 0.15，与 0~1 量级的观测量不匹配，F 会跳到 39.9~101.2；
    第3代改成 0.35 是对的，本模块沿用。
  · `prior_mu` 钳 [0,1] 而 `mu` 钳 [−1,2]，区间不对称会人为放大 KL ——
    本模块把两者都放在 [−0.5, 1.5]，并允许通过参数调整。
  · 各区的先验不是常数：它由内稳态推出（饿了杏仁核先验就高）。
    第 2 代有这套 `_compute_homeostatic_priors`，第 3 代搬成 staticmethod，
    本模块保留并补齐注释。
"""

from __future__ import annotations

import math
import threading
from collections import deque
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Sequence, Tuple

from . import snn as snn_mod

LOG_2PI = math.log(2.0 * math.pi)
EPS = 1e-9

# 观测噪声标准差。0.15 与 0~1 的观测不匹配（F 会到 100 量级），0.35 合适。
SIGMA_OBS = 0.35
PRIOR_VAR = 0.25
PRIOR_MU = 0.20
# 学习率：0.15 在高精度先验下会让 mu 振荡并撞到下限（实测 lr≥0.08、
# prior_var=0.05 时 mu 被钉在 −0.5）。0.08 全区间稳定。
LEARNING_RATE = 0.08
MAX_FEP_HISTORY = 24
MU_RANGE = (-0.5, 1.5)
LOGVAR_RANGE = (-6.0, 2.0)

# 关于收敛到什么值：本模型是**变分**推断（梯度下降），不是解析后验。
# 解析解 μ_post = Σ_post·(μ_prior/σ_prior² + obs/σ_obs²)，
# 代入默认参数得 0.6998；实测梯度下降收敛到 0.6698 —— 方向与量级都对，
# 差的那部分是梯度近似与 log_var 漂移带来的。**这是预期行为，不是缺陷。**
# 校验时应看"是否朝观测移动、是否随观测变化"，而不是要求等于观测值。

# 动作候选（沿用旧版，补上新版用到的）
CANDIDATE_ACTIONS: Tuple[str, ...] = (
    "do_nothing", "sit_down", "stand_up", "look_at_board", "look_window",
    "look_door", "relax", "move_to_seat", "move_to_water", "eat_snack",
    "drink_water", "sleep", "wake_up", "speak",
)
# ★ `speak` 不是一个"定时动作"，它是一个**候选动作** ——
#   和看窗外、坐下、去喝水一样，由 EFE 最小化选出来。
#   她的认知价值来自"对方还在不在"这件事的不确定性：
#   越久没交流，这份不确定越大，开口的收益就越高。
#   所以她是**想过之后决定说话**，不是到点了必须说。

# 目标状态与权重（demo4β L882-897，原样保留）
GOALS: Dict[str, float] = {
    "hunger": 0.2, "thirst": 0.1, "muscle_fatigue": 0.1,
    "sleep_pressure": 0.2, "pain_level": 0.0, "adrenaline": 0.1,
}
WEIGHTS: Dict[str, float] = {
    "hunger": 2.0, "thirst": 2.0, "muscle_fatigue": 1.0,
    "sleep_pressure": 1.5, "pain_level": 3.0, "adrenaline": 0.5,
}

# 动作的"代价"（demo4β L919-933）
COMPLEXITY_COST: Dict[str, float] = {
    # ★ `do_nothing` 与 `relax` 的代价都是 0，所以净收益 = 0 ——
    #   它们是**自然基线**。要让别的动作被选中，它必须挣得比 0 多。
    "do_nothing": 0.0, "relax": 0.0, "sit_down": 0.05,
    "look_at_board": 0.02, "look_window": 0.02, "look_door": 0.02,    "stand_up": 0.1,
    "move_to_seat": 0.3, "move_to_water": 0.3,
    "eat_snack": 0.1, "drink_water": 0.1, "sleep": 0.05, "wake_up": 0.1,
    # 开口是有代价的：要组织语言、要承担被无视的可能
    "speak": 0.12,
}

# 动作能带来多少"新信息"（demo4β L935-949）
# ----------------------------------------------------------------------
# ★ 这里的**绝对值**决定她一天在做什么，比任何机制都重要。
#
#   原来的值（看一眼窗外 0.08、代价 0.02 → 净 +0.06）让所有"看"类动作
#   都严格优于 `do_nothing`（净恒为 0）。后果：她 **98.7% 的时间在看窗**，
#   而且**永远不会发呆** —— 发呆恒等于 0，永远赢不了任何正收益的动作。
#
#   ★ 标定原则（唯一一条，别再靠相对微调）：
#     `do_nothing` 与 `relax` 的价值定义为 **0** —— 休息是基线。
#     任何动作想被选中，它的**净收益（认知 − 代价）必须为正**。
#
#     由此推出各动作该给多少：
#       · 原地扫一眼 → 0（净 −0.02）：看摆在眼前的东西不产生新信息。
#         她还是会看，靠的是 `LOOK_EPI` 那点边际收益，
#         但很容易被"刚看过"的衰减压到基线以下 —— 那是对的。
#       · 走过去看   → 正值（净 +0.18）：那才真可能有新信息。
#       · 吃/喝/睡   → 0：它们的价值在 **pragmatic**（补上生理缺口），
#                     不在认知。饿了自然会被选上。
#
#     之前的错在于把"看一眼"的认知价值设得比代价高，
#     于是所有"看"类动作都严格优于基线 —— 她 24 小时在"看门→看窗→看黑板"
#     地转，实测单一动作占 80%，而且**永远不会发呆**。
LOOK_EPI = 0.0       # 原地扫一眼：不产生新信息
MOVE_EXTRA = 0.48    # 走过去看：那才是探索

EPISTEMIC_VALUE: Dict[str, float] = {
    "do_nothing": 0.0, "sit_down": 0.0, "stand_up": 0.0, "relax": 0.0,
    "look_at_board": LOOK_EPI, "look_window": LOOK_EPI, "look_door": LOOK_EPI,
    "move_to_seat": MOVE_EXTRA, "move_to_water": MOVE_EXTRA,
    "eat_snack": 0.0, "drink_water": 0.0, "sleep": 0.0, "wake_up": 0.0,
    # speak 的基准认知价值。真正的值由 `speak_epistemic()` 按时长算 ——
    # 这里给的是"下限"，避免它永远选不上。
    "speak": 0.04,
}

# 开口的认知价值：越久没交流，"对方还在不在"越不确定 ——
# 这份不确定就是主动推理里值得用动作去消解的东西。
SPEAK_EPISTEMIC_MAX = 0.55     # 很久没交流时的上限
SPEAK_SATURATION_SEC = 900.0   # 到这个时长，收益基本封顶


def speak_epistemic(seconds_since_contact: float) -> float:
    """按"多久没交流"算开口的认知价值。

    用 `t / (t + T)` 这种饱和曲线，而不是线性 ——
    刚说完话时收益接近 0（没什么可确认的），
    隔久了才显著上升，但不会无限涨（她不是焦虑）。
    """
    t = max(0.0, float(seconds_since_contact))
    base = EPISTEMIC_VALUE["speak"]
    frac = t / (t + SPEAK_SATURATION_SEC)
    return base + (SPEAK_EPISTEMIC_MAX - base) * frac


def _clamp(v: float, lo: float, hi: float) -> float:
    return lo if v < lo else (hi if v > hi else v)


# ----------------------------------------------------------------------
@dataclass
class EFEChoice:
    """一次动作选择的结果（可解释，前端要展示理由）。"""

    action: str = "do_nothing"
    scores: Dict[str, float] = field(default_factory=dict)
    pragmatic: Dict[str, float] = field(default_factory=dict)
    complexity: Dict[str, float] = field(default_factory=dict)
    epistemic: Dict[str, float] = field(default_factory=dict)
    predicted: Dict[str, Dict[str, float]] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "action": self.action,
            "scores": {k: round(v, 5) for k, v in self.scores.items()},
            "pragmatic": {k: round(v, 5) for k, v in self.pragmatic.items()},
            "complexity": dict(self.complexity),
            "epistemic": dict(self.epistemic),
            "ranking": sorted(self.scores.items(), key=lambda kv: kv[1])[:5],
        }


@dataclass
class RegionUnitState:
    """单区 FEP 状态（第2代有独立 dataclass，第3代丢了，这里恢复）。"""

    mu: float = 0.20
    log_var: float = -1.386          # e^-1.386 ≈ 0.25 = PRIOR_VAR
    prior_mu: float = PRIOR_MU
    prior_var: float = PRIOR_VAR
    F: float = 0.0
    complexity: float = 0.0
    accuracy: float = 0.0
    surprise: float = 0.0
    prediction_error: float = 0.0
    last_observation: float = 0.0
    last_prediction: float = 0.0

    @property
    def var(self) -> float:
        return math.exp(self.log_var)

    def to_dict(self) -> Dict[str, float]:
        return {
            "mu": round(self.mu, 5), "var": round(self.var, 6),
            "prior_mu": round(self.prior_mu, 5),
            "prior_var": round(self.prior_var, 5),
            "F": round(self.F, 5),
            "complexity": round(self.complexity, 5),
            "accuracy": round(self.accuracy, 5),
            "surprise": round(self.surprise, 5),
            "prediction_error": round(self.prediction_error, 5),
        }


class RegionUnit:
    """一个脑区的自由能单元。"""

    __slots__ = ("key", "st", "history", "_lock")

    def __init__(self, key: str) -> None:
        self.key = key
        self.st = RegionUnitState()
        self.history: deque = deque(maxlen=60)     # 第2代是 60 帧
        self._lock = threading.RLock()

    def set_prior(self, mu: float, var: float = PRIOR_VAR) -> None:
        with self._lock:
            self.st.prior_mu = _clamp(mu, MU_RANGE[0], MU_RANGE[1])
            self.st.prior_var = max(1e-3, float(var))

    def step(self, observation: float) -> RegionUnitState:
        """吃一个观测，走一步梯度下降，返回新状态。"""
        with self._lock:
            st = self.st
            obs = _clamp(float(observation), -2.0, 2.0)
            st.last_observation = obs
            st.last_prediction = st.mu

            # 预测误差与惊奇
            err = obs - st.mu
            st.prediction_error = err
            sigma2 = SIGMA_OBS * SIGMA_OBS
            st.surprise = _clamp(0.5 * (LOG_2PI + math.log(sigma2)
                                        + err * err / sigma2), 0.0, 50.0)

            # 复杂度 = KL[q‖p]
            vq = max(1e-6, st.var)
            vp = max(1e-6, st.prior_var)
            st.complexity = 0.5 * (
                math.log(vp / vq) + (vq + (st.mu - st.prior_mu) ** 2) / vp - 1.0)

            # 准确度 = log p(o|μ)（取负号使"越准越负"）
            st.accuracy = -0.5 * (LOG_2PI + math.log(sigma2)
                                  + err * err / sigma2)

            # F = 复杂度 − 准确度
            st.F = st.complexity - st.accuracy

            # 梯度下降：mu 朝观测走，同时对先验有拉力
            #
            # ★ 步长必须除以对角 Hessian。直接写 `mu - lr·g` 时，
            #   Hessian ≈ 1/σ_prior² + 1/σ_obs² 会随先验精度变化：
            #   prior_var=0.25 时约 12.2，prior_var=0.05 时高达 28.2，
            #   而 lr=0.08 在 Hessian>25 时就发散 —— 实测 mu 被钉到下限 −0.5。
            #   除以 Hessian 后步长自动适配，任何先验精度都稳定
            #   （对 μ 而言这就是一步精确牛顿更新，方差需为正才有效）。
            g_mu = (st.mu - st.prior_mu) / vp - err / sigma2
            g_lv = 0.5 * (1.0 / vp - 1.0 / vq)
            hess_mu = 1.0 / vp + 1.0 / sigma2
            step_mu = g_mu / max(1e-6, hess_mu)
            st.mu = _clamp(st.mu - LEARNING_RATE * step_mu,
                           MU_RANGE[0], MU_RANGE[1])
            # 注意：log_var 用**已更新的 mu**，这是旧版的行为，原样保留
            st.log_var = _clamp(st.log_var - LEARNING_RATE * g_lv,
                                LOGVAR_RANGE[0], LOGVAR_RANGE[1])

            self.history.append(round(st.F, 5))
            return st

    def to_dict(self) -> Dict[str, Any]:
        d = self.st.to_dict()
        d["key"] = self.key
        return d


# ----------------------------------------------------------------------
class FEPNetwork:
    """10 个脑区的自由能网络 + 动作选择。"""

    def __init__(self) -> None:
        self._lock = threading.RLock()
        self.units: Dict[str, RegionUnit] = {
            k: RegionUnit(k) for k in snn_mod.REGION_KEYS}
        self.history: deque = deque(maxlen=MAX_FEP_HISTORY)
        self.global_F = 0.0
        self.delta_F = 0.0
        self.surprise = 0.0
        self.complexity = 0.0
        self.accuracy = 0.0
        self._last_F = 0.0
        self._prior_key = ""

    # ------------------------------------------------------------------
    @staticmethod
    def compute_homeostatic_priors(h: Any) -> Dict[str, float]:
        """由内稳态推出各区的先验（不是常数）。

        h 可以是 homeo.State、字典或任何带同名属性的对象。
        """
        def g(name: str, default: float = 0.0) -> float:
            if h is None:
                return default
            if isinstance(h, dict):
                try:
                    return float(h.get(name, default))
                except (TypeError, ValueError):
                    return default
            return float(getattr(h, name, default))

        pain = g("pain_level")
        adr = g("adrenaline")
        hunger = g("hunger")
        thirst = g("thirst")
        sleep = g("sleep_pressure")
        fatigue = g("muscle_fatigue")
        central = g("central_fatigue")
        return {
            "reflex": _clamp(pain + 0.10 * adr, 0.0, 1.0),
            "thalamus": 0.25,
            "hippocampus": _clamp(0.20 + 0.10 * (1.0 - sleep), 0.0, 1.0),
            "hypothalamus": _clamp(0.20 + 0.30 * hunger + 0.30 * thirst
                                   + 0.20 * sleep, 0.0, 1.0),
            "motor": _clamp(0.20 + 0.20 * adr, 0.0, 1.0),
            "cerebellum": 0.15,
            "autonomic": _clamp(0.15 + 0.40 * adr + 0.20 * pain
                                + 0.20 * hunger, 0.0, 1.0),
            "prefrontal": _clamp(0.30 + 0.20 * (1.0 - fatigue)
                                 + 0.10 * (1.0 - central), 0.0, 1.0),
            "association": _clamp(0.25 + 0.10 * (1.0 - central), 0.0, 1.0),
            "language": _clamp(0.30 + 0.15 * (1.0 - central)
                               + 0.10 * (1.0 - sleep), 0.0, 1.0),
        }

    # ------------------------------------------------------------------
    def step(self, rates: Dict[str, float],
             homeo: Any = None) -> Dict[str, Any]:
        """吃一帧脑区发放率，推进所有 FEP 单元。"""
        with self._lock:
            priors = self.compute_homeostatic_priors(homeo)
            Fs, cs, acs, sus = [], [], [], []
            for key, unit in self.units.items():
                unit.set_prior(priors.get(key, PRIOR_MU))
                st = unit.step(rates.get(key, 0.0))
                Fs.append(st.F)
                cs.append(st.complexity)
                acs.append(st.accuracy)
                sus.append(st.surprise)

            n = max(1, len(Fs))
            self.global_F = sum(Fs) / n
            self.delta_F = self.global_F - self._last_F
            self._last_F = self.global_F
            self.complexity = sum(cs) / n
            self.accuracy = sum(acs) / n
            self.surprise = _clamp(sum(sus) / n, 0.0, 1.0)
            self.history.append(round(self.global_F, 5))
            return self.to_dict()

    # ------------------------------------------------------------------
    #  ★ 真·期望自由能（EFE）—— demo4β 的机制，第1/2/3 代都没有
    # ------------------------------------------------------------------
    @staticmethod
    def predict_state(action: str, homeo: Dict[str, float]) -> Dict[str, float]:
        """世界模型：预测执行某个动作后身体会变成什么样。

        转移规则来自 demo4β L899-917，原样保留并补注释。
        """
        p = dict(homeo or {})
        if action == "eat_snack":
            p["hunger"] = max(0.0, p.get("hunger", 0.0) - 0.4)
            p["glucose"] = min(10.0, p.get("glucose", 5.0) + 1.0)
            p["total_energy_kcal"] = min(
                2500.0, p.get("total_energy_kcal", 2000.0) + 100.0)
        elif action == "drink_water":
            p["thirst"] = max(0.0, p.get("thirst", 0.0) - 0.5)
            p["blood_osmolarity"] = max(
                280.0, p.get("blood_osmolarity", 290.0) - 2.0)
        elif action == "sleep":
            p["sleep_pressure"] = max(0.0, p.get("sleep_pressure", 0.0) - 0.5)
        elif action in ("relax", "sit_down"):
            p["muscle_fatigue"] = max(0.0, p.get("muscle_fatigue", 0.0) - 0.2)
        elif action in ("move_to_seat", "move_to_water"):
            p["muscle_fatigue"] = min(
                1.0, p.get("muscle_fatigue", 0.0) + 0.1)
            p["total_energy_kcal"] = max(
                1500.0, p.get("total_energy_kcal", 2000.0) - 20.0)
        elif action == "stand_up":
            p["muscle_fatigue"] = min(
                1.0, p.get("muscle_fatigue", 0.0) + 0.05)
        return p

    def expected_free_energy(self, homeo: Dict[str, float],
                             goals: Optional[Dict[str, float]] = None,
                             weights: Optional[Dict[str, float]] = None,
                             allowed: Optional[Sequence[str]] = None,
                             social_gap: float = 0.0,
                             epistemic_scale: float = 1.0,
                             novelty: Optional[Dict[str, float]] = None
                             ) -> EFEChoice:
        """在候选动作里挑 EFE 最小的那个。

        EFE = −pragmatic + complexity − epistemic
            pragmatic  朝目标改善了多少（越大越好，所以取负）
            complexity 动作本身的代价（越小越好）
            epistemic  能获得多少新信息（越大越好，所以取负）

        `social_gap` 是"多久没和对方交流了"（秒）。
        它只影响 `speak` 的认知价值 —— 越久没交流，
        "对方还在不在"这份不确定越大，开口的收益就越高。
        ★ 这样"主动开口"就是她**权衡后的选择**，而不是定时触发。

        `epistemic_scale` 是她给这份信息的**估价系数**（人设差异）：
        渐进酱 1.0（她需要一直确认对方在），白子 0.62（没那么需要）。

        `novelty` 是每个动作的**新鲜度**（0–1，默认 1）。
        ★ 为什么需要它：认知价值原本是固定常数，于是"看一成不变的窗外"
          每 4 秒都能拿到同样的 0.08 —— 实测她 98.7% 的时间都在看窗。
          真实的主动推理里，同一件事看第二遍的信息量是**递减**的。
        """
        gl = goals or GOALS
        wt = weights or WEIGHTS
        acts = list(allowed) if allowed else list(CANDIDATE_ACTIONS)
        cur = dict(homeo or {})
        nov = novelty or {}

        choice = EFEChoice()
        for a in acts:
            pred = self.predict_state(a, cur)
            choice.predicted[a] = {
                k: round(pred.get(k, cur.get(k, 0.0)), 4) for k in gl}
            pragmatic = 0.0
            for var, goal in gl.items():
                c = float(cur.get(var, goal))
                p = float(pred.get(var, c))
                # 离目标近了多少：当前误差² − 预测误差²
                pragmatic += wt.get(var, 1.0) * ((c - goal) ** 2
                                                 - (p - goal) ** 2)
            complexity = COMPLEXITY_COST.get(a, 0.1)
            if a == "speak":
                epistemic = speak_epistemic(social_gap) * epistemic_scale
            else:
                epistemic = EPISTEMIC_VALUE.get(a, 0.0)
            # 重复的动作信息量递减
            f = nov.get(a, 1.0)
            epistemic *= max(0.0, min(1.0, f))
            efe = -pragmatic + complexity - epistemic
            choice.scores[a] = efe
            choice.pragmatic[a] = pragmatic
            choice.complexity[a] = complexity
            choice.epistemic[a] = epistemic

        if choice.scores:
            # ★ 平分时用 novelty（"多久没做"）破平，而不是让 Python 的
            #   `min()` 按插入顺序挑第一个。否则 do_nothing 与 relax 价值
            #   都是 0，会永远只有一个被选中，另一个形同不存在。
            choice.action = min(
                choice.scores,
                key=lambda a: (choice.scores[a], -nov.get(a, 1.0)))
        return choice

    # ------------------------------------------------------------------
    # 启发式打分（第2/3代有，保留作为对照与兜底）
    # ------------------------------------------------------------------
    @staticmethod
    def compute_action_scores(homeo: Dict[str, float]) -> Dict[str, float]:
        """旧版的启发式打分。**不是 EFE**，仅在 EFE 不可用时兜底。"""
        h = homeo or {}
        g = lambda k, d=0.0: float(h.get(k, d))            # noqa: E731
        hunger, thirst = g("hunger"), g("thirst")
        fatigue, pain = g("muscle_fatigue"), g("pain_level")
        sleep = g("sleep_pressure")
        s: Dict[str, float] = {a: 0.0 for a in CANDIDATE_ACTIONS}
        for a in ("eat_snack", "move_to_seat"):
            s[a] += -2.0 * hunger + 0.3 * fatigue
        for a in ("drink_water", "move_to_water"):
            s[a] += -2.0 * thirst + 0.3 * fatigue
        s["sleep"] += -3.0 * sleep
        for a in ("relax", "sit_down", "do_nothing"):
            s[a] += -1.5 * fatigue - 2.0 * pain + 0.2 * hunger
        for a in ("stand_up", "move_to_seat", "move_to_water"):
            s[a] += 1.0 * fatigue + 2.0 * pain
        for a in ("look_window", "look_at_board", "look_door"):
            s[a] += -0.5 * fatigue + 0.1 * hunger
        return s

    # ------------------------------------------------------------------
    def to_dict(self) -> Dict[str, Any]:
        """给前端的一帧 FEP 数据。

        ★ `units` 是**逐区明细**（key → {F, cx, acc, ...}），不是数量。
        旧版前端就是这么用的（`Object.entries(units)`）；我一度把它写成
        `len(self.units)`，前端拿到一个 int 会直接崩。真要看数量用
        `unit_count`。
        """
        return {
            "free_energy": round(self.global_F, 5),
            "fe_delta": round(self.delta_F, 5),
            "surprise": round(self.surprise, 5),
            "complexity": round(self.complexity, 5),
            "accuracy": round(self.accuracy, 5),
            "units": self.units_detail(),
            "unit_count": len(self.units),
            "history": list(self.history),
        }

    def units_detail(self) -> Dict[str, Any]:
        """每个脑区单元的自由能明细。"""
        with self._lock:
            return {k: u.to_dict() for k, u in self.units.items()}

    def reset(self) -> None:
        with self._lock:
            for u in self.units.values():
                u.st = RegionUnitState()
                u.history.clear()
            self.history.clear()
            self.global_F = self.delta_F = 0.0


__all__ = [
    "FEPNetwork", "RegionUnit", "RegionUnitState", "EFEChoice",
    "CANDIDATE_ACTIONS", "GOALS", "WEIGHTS", "COMPLEXITY_COST",
    "EPISTEMIC_VALUE", "speak_epistemic",
    "SPEAK_EPISTEMIC_MAX", "SPEAK_SATURATION_SEC", "SIGMA_OBS", "PRIOR_VAR", "PRIOR_MU",
    "LEARNING_RATE", "MAX_FEP_HISTORY",
]
