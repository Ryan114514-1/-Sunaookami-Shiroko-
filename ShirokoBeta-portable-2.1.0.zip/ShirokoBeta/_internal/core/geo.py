# -*- coding: utf-8 -*-
"""
Shiroko β —— 环境几何

这是**小地图的唯一数据源**。设计原则（针对旧版最大的毛病）
--------------------------------------------------------
旧版把教室几何写死在两个地方：前端 `LANDMARKS` 常量与 `ROOM` 常量。
于是无论默认环境是机房、用户新建的是天台，小地图永远画那间教室。

这里的规矩是：

    环境描述（environment_spec） → Environment 对象 → 前端只负责画

前端**不允许**再有任何写死的地标或房间尺寸。它拿到的就是
`Environment.to_client()` 返回的这份数据，画出来必然与环境一致。

坐标约定
--------
世界坐标是「米」，原点在房间**左下角**，x 向右、y 向上（数学惯例）。
前端负责翻转成屏幕坐标，本模块不掺和像素。

    room = {x0, y0, x1, y1}      房间矩形（米）
    landmark.pos = [x, y]        地标中心（米）

向后兼容
--------
`classroom()` 产出的几何与旧版 galbeta 完全一致
（room x∈[-4,4] y∈[-4,3.5]，8 个地标位置一一对应），
这样旧存档的地图不会跳变。
"""

from __future__ import annotations

import math
import re
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Sequence, Tuple

# 地标类别 → 前端配色（前端直接用这个 key 取色，不再自己猜）
KIND_COLORS: Dict[str, str] = {
    "board": "#2f6b4f",
    "furniture": "#a98763",
    "seat": "#a8c4dc",
    "window": "#8fc7d8",
    "door": "#c9a06a",
    "clock": "#c3ccd5",
    "equipment": "#7d8fa3",
    "light": "#e8d9a0",
    "plant": "#7fae7a",
    "bed": "#b9a7c9",
    "shelf": "#a08d78",
    "table": "#b09a80",
    "other": "#c3ccd5",
}

# 英文标识 → 类别（模型常返回英文 name + 中文 label，这里归一化）
KIND_ALIASES: Dict[str, str] = {
    "blackboard": "board", "whiteboard": "board", "board": "board",
    "teacher_desk": "furniture", "podium": "furniture", "desk": "furniture",
    "cabinet": "furniture", "locker": "shelf", "shelf": "shelf",
    "bookshelf": "shelf", "table": "table", "bench": "seat",
    "chair": "seat", "seat": "seat", "student_desk": "seat",
    "window": "window", "window_left": "window", "window_right": "window",
    "door": "door", "gate": "door", "exit": "door",
    "clock": "clock", "wall_clock": "clock", "timer": "clock",
    "rack": "equipment", "server_rack": "equipment", "ac": "equipment",
    "air_conditioner": "equipment", "ups": "equipment",
    "console": "equipment", "monitor": "equipment",
    "machine": "equipment", "equipment": "equipment",
    "lamp": "light", "light": "light", "ceiling_light": "light",
    "flower": "plant", "plant": "plant", "tree": "plant",
    "bed": "bed", "cot": "bed",
}

# 位置语义 → 贴哪面墙（模型只说"黑板在教室前面"时用得上）
PLACEMENT_HINTS: Dict[str, Tuple[str, str]] = {
    "back_wall": ("y", "min"),     # 后墙 = y 最小
    "front_wall": ("y", "max"),
    "left_wall": ("x", "min"),
    "right_wall": ("x", "max"),
    "center": ("c", "c"),
}

_FLOAT_RE = re.compile(r"-?\d+(?:\.\d+)?")


def _f(v: Any, default: float = 0.0) -> float:
    """尽力把任意输入变成 float（模型有时返回 "3.5 米" 这种）。"""
    if isinstance(v, bool):
        return default
    if isinstance(v, (int, float)):
        return float(v)
    if isinstance(v, str):
        m = _FLOAT_RE.search(v)
        if m:
            try:
                return float(m.group())
            except ValueError:
                pass
    return default


def _norm_kind(raw: Any) -> str:
    """把任意类别写法归一成 KIND_COLORS 的键。"""
    s = str(raw or "").strip().lower()
    if not s:
        return "other"
    if s in KIND_COLORS:
        return s
    s2 = re.sub(r"[\s\-]+", "_", s)
    if s2 in KIND_ALIASES:
        return KIND_ALIASES[s2]
    for key, val in KIND_ALIASES.items():
        if key and key in s2:
            return val
    return "other"


@dataclass
class Landmark:
    """环境中的一个可指认位置。"""

    name: str = ""                       # 稳定标识（英文，程序用）
    label: str = ""                      # 显示名（中文，界面用）
    kind: str = "other"                  # 类别，决定配色
    pos: Tuple[float, float] = (0.0, 0.0)
    interactable: bool = False           # 能否交互（旧版字段，保留）
    note: str = ""                       # 可选补充说明

    def to_client(self) -> Dict[str, Any]:
        return {
            "name": self.name, "label": self.label, "kind": self.kind,
            "color": KIND_COLORS.get(self.kind, KIND_COLORS["other"]),
            "pos": [round(self.pos[0], 3), round(self.pos[1], 3)],
            "interactable": self.interactable,
            "note": self.note,
        }

    def distance_to(self, xy: Sequence[float]) -> float:
        """到某个坐标的直线距离（米）。"""
        try:
            dx = self.pos[0] - float(xy[0])
            dy = self.pos[1] - float(xy[1])
        except (TypeError, ValueError, IndexError):
            return float("inf")
        return math.hypot(dx, dy)


@dataclass
class Environment:
    """一个环境：房间几何 + 地标 + 氛围。

    这是「环境描述」的结构化形态，也是小地图的唯一依据。
    """

    scene_name: str = "未命名环境"
    scene_type: str = "indoor"
    description: str = ""
    room: Dict[str, float] = field(
        default_factory=lambda: {"x0": -4.0, "y0": -4.0, "x1": 4.0, "y1": 3.5})
    landmarks: List[Landmark] = field(default_factory=list)
    ambient: Dict[str, Any] = field(
        default_factory=lambda: {"temperature": 22.0, "lighting": 0.6,
                                 "weather": "sunny"})
    sensory_sounds: List[str] = field(default_factory=list)
    sensory_smells: List[str] = field(default_factory=list)
    spawn: Tuple[float, float] = (0.0, 0.0)
    source: str = "builtin"      # builtin | user | llm_generated
    raw: Dict[str, Any] = field(default_factory=dict)   # 原始 spec，便于回看

    # ------------------------------------------------------------------
    @property
    def width(self) -> float:
        return max(0.5, self.room["x1"] - self.room["x0"])

    @property
    def height(self) -> float:
        return max(0.5, self.room["y1"] - self.room["y0"])

    @property
    def center(self) -> Tuple[float, float]:
        return (self.room["x0"] + self.room["x1"]) / 2.0, \
               (self.room["y0"] + self.room["y1"]) / 2.0

    @property
    def area(self) -> float:
        return self.width * self.height

    # ------------------------------------------------------------------
    def contains(self, x: float, y: float, margin: float = 0.0) -> bool:
        return (self.room["x0"] + margin <= x <= self.room["x1"] - margin
                and self.room["y0"] + margin <= y <= self.room["y1"] - margin)

    def clamp(self, x: float, y: float, margin: float = 0.0
              ) -> Tuple[float, float]:
        """把坐标夹进房间里（留 margin 边距）。"""
        return (min(max(x, self.room["x0"] + margin), self.room["x1"] - margin),
                min(max(y, self.room["y0"] + margin), self.room["y1"] - margin))

    def landmark_by_name(self, name: str) -> Optional[Landmark]:
        for lm in self.landmarks:
            if lm.name == name or lm.label == name:
                return lm
        return None

    def visible(self, xy: Sequence[float], max_dist: float = 6.0) -> List[Landmark]:
        """按距离升序返回视野内的地标。

        距离阈值相对房间尺寸自适应：小房间 6 米就够看全，大机房要放宽，
        否则会出现"站在房间里却什么都看不见"。
        """
        span = max(self.width, self.height)
        limit = max(float(max_dist), span * 0.75)
        out = [lm for lm in self.landmarks if lm.distance_to(xy) <= limit]
        out.sort(key=lambda lm: lm.distance_to(xy))
        return out

    def nearest(self, xy: Sequence[float],
                max_dist: float = 1.2) -> Optional[Landmark]:
        """最近的地标（在给定半径内）。"""
        best, best_d = None, float(max_dist)
        for lm in self.landmarks:
            d = lm.distance_to(xy)
            if d <= best_d:
                best, best_d = lm, d
        return best

    def landmarks_of_kind(self, kind: str) -> List[Landmark]:
        return [lm for lm in self.landmarks if lm.kind == kind]

    # ------------------------------------------------------------------
    def to_client(self) -> Dict[str, Any]:
        """给前端的完整几何数据。小地图照着这个画，必然与环境一致。

        同时带上 `spec` —— 前端"新建角色时装进当前环境"要用它，
        不必再单独请求一次。
        """
        return {
            "scene_name": self.scene_name,
            "scene_type": self.scene_type,
            "description": self.description,
            "room": {k: round(float(v), 3) for k, v in self.room.items()},
            "size": {"width": round(self.width, 3),
                     "height": round(self.height, 3),
                     "area": round(self.area, 2)},
            "center": [round(self.center[0], 3), round(self.center[1], 3)],
            "spawn": [round(self.spawn[0], 3), round(self.spawn[1], 3)],
            "landmarks": [lm.to_client() for lm in self.landmarks],
            "ambient": dict(self.ambient),
            "sensory": {"sounds": list(self.sensory_sounds),
                        "smells": list(self.sensory_smells)},
            "source": self.source,
            "spec": self.to_spec(),
        }

    def to_spec(self) -> Dict[str, Any]:
        """存进 config / 存档用的精简形式。"""
        return {
            "scene_name": self.scene_name,
            "scene_type": self.scene_type,
            "description": self.description,
            "room": dict(self.room),
            "landmarks": [
                {"name": lm.name, "label": lm.label, "kind": lm.kind,
                 "pos": list(lm.pos), "interactable": lm.interactable,
                 "note": lm.note} for lm in self.landmarks],
            "ambient": dict(self.ambient),
            "sensory_sounds": list(self.sensory_sounds),
            "sensory_smells": list(self.sensory_smells),
            "spawn": list(self.spawn),
            "source": self.source,
        }

    def describe_for_llm(self) -> str:
        """给大模型看的一段环境说明（让她知道自己身处何处）。"""
        lines = ["【当前环境】%s（%s）" % (self.scene_name, self.scene_type)]
        if self.description:
            lines.append(self.description)
        lines.append("房间尺寸：%.1f 米 × %.1f 米，坐标原点在左下角，"
                     "x 向右、y 向上。" % (self.width, self.height))
        if self.landmarks:
            lines.append("可指认的位置：")
            for lm in self.landmarks:
                lines.append("  · %s（%s）在 (%.1f, %.1f)"
                             % (lm.label, lm.kind, lm.pos[0], lm.pos[1]))
        amb = self.ambient
        lines.append("环境：温度 %.0f°C，光照 %.0f%%%s"
                     % (_f(amb.get("temperature"), 22),
                        _f(amb.get("lighting"), 0.6) * 100,
                        ("，天气 " + str(amb["weather"]))
                        if amb.get("weather") else ""))
        if self.sensory_sounds:
            lines.append("能听到：" + "、".join(self.sensory_sounds))
        if self.sensory_smells:
            lines.append("能闻到：" + "、".join(self.sensory_smells))
        return "\n".join(lines)


# ----------------------------------------------------------------------
# 校验与修正
# ----------------------------------------------------------------------
def normalize_room(raw: Any, fallback: Dict[str, float]
                   ) -> Dict[str, float]:
    """把模型给的 room 修正成合法矩形。

    模型常见毛病：
      · 给 x/y/width/height 而不是 x0/y0/x1/y1
      · 原点在左上角（y 轴朝下）→ y1 < y0
      · 尺寸为 0 或负数
      · 尺寸离谱（几百米）
    """
    d = raw if isinstance(raw, dict) else {}
    x0, y0 = _f(d.get("x0"), fallback["x0"]), _f(d.get("y0"), fallback["y0"])
    # 兼容 width/height 写法
    if "x1" in d:
        x1 = _f(d.get("x1"), fallback["x1"])
    elif "width" in d or "w" in d:
        x1 = x0 + _f(d.get("width", d.get("w")), fallback["x1"] - fallback["x0"])
    else:
        x1 = fallback["x1"]
    if "y1" in d:
        y1 = _f(d.get("y1"), fallback["y1"])
    elif "height" in d or "h" in d:
        y1 = y0 + _f(d.get("height", d.get("h")), fallback["y1"] - fallback["y0"])
    else:
        y1 = fallback["y1"]

    # 翻转：y 轴朝下写的（y1 < y0）
    if y1 < y0:
        y0, y1 = y1, y0
    if x1 < x0:
        x0, x1 = x1, x0

    # 尺寸兜底与限幅
    if x1 - x0 < 0.5:
        x1 = x0 + max(2.0, fallback["x1"] - fallback["x0"])
    if y1 - y0 < 0.5:
        y1 = y0 + max(2.0, fallback["y1"] - fallback["y0"])
    if x1 - x0 > 200.0:
        x1 = x0 + 200.0
    if y1 - y0 > 200.0:
        y1 = y0 + 200.0

    return {"x0": round(x0, 3), "y0": round(y0, 3),
            "x1": round(x1, 3), "y1": round(y1, 3)}


def normalize_landmarks(raw: Any, room: Dict[str, float],
                        limit: int = 24) -> List[Landmark]:
    """把模型给的地标列表修正成可用的。

    做的修正：
      · pos 不是 [x,y] → 丢进房间中央
      · 坐标落在房间外 → 投影回最近的墙内侧
      · 名字缺失 → 用类别生成
      · 英文名带空格/大写 → 归一成 snake_case
      · 完全重复的位置且同名 → 去重
    """
    out: List[Landmark] = []
    seen_names: set = set()
    items = raw if isinstance(raw, list) else []
    w = room["x1"] - room["x0"]
    h = room["y1"] - room["y0"]
    inset = min(0.35, w / 12.0, h / 12.0)

    for i, it in enumerate(items[:limit]):
        if not isinstance(it, dict):
            continue
        label = str(it.get("label") or it.get("name") or "").strip()
        name = str(it.get("name") or "").strip()
        kind = _norm_kind(it.get("kind") or it.get("category") or name
                          or label)
        if not label:
            label = name or ("地点 %d" % (i + 1))
        if not name:
            name = re.sub(r"[^a-z0-9_]+", "_", label.lower()).strip("_") \
                or ("spot_%d" % (i + 1))
        name = re.sub(r"[\s\-]+", "_", name.strip().lower())
        if name in seen_names:
            name = "%s_%d" % (name, i + 1)
        seen_names.add(name)

        pos = it.get("pos") or it.get("position") or it.get("location")
        if isinstance(pos, dict):
            pos = [pos.get("x"), pos.get("y")]
        if isinstance(pos, (list, tuple)) and len(pos) >= 2:
            x, y = _f(pos[0], float("nan")), _f(pos[1], float("nan"))
        else:
            x = y = float("nan")

        # 位置缺失或越界 → 修正
        if math.isnan(x) or math.isnan(y) or not (
                room["x0"] - 0.01 <= x <= room["x1"] + 0.01
                and room["y0"] - 0.01 <= y <= room["y1"] + 0.01):
            place = str(it.get("placement") or it.get("where") or "").lower()
            side = PLACEMENT_HINTS.get(place)
            cx = (room["x0"] + room["x1"]) / 2.0
            cy = (room["y0"] + room["y1"]) / 2.0
            if side and side[0] == "y":
                x = cx if math.isnan(x) else x
                y = (room["y0"] + inset if side[1] == "min"
                     else room["y1"] - inset)
            elif side and side[0] == "x":
                y = cy if math.isnan(y) else y
                x = (room["x0"] + inset if side[1] == "min"
                     else room["x1"] - inset)
            else:
                # 按序号沿墙均匀铺开，至少能看出方位
                if math.isnan(x):
                    x = room["x0"] + inset + (w - inset * 2) * \
                        ((i % 4) + 0.5) / 4.0
                if math.isnan(y):
                    y = room["y0"] + inset + (h - inset * 2) * \
                        ((i // 4) % 3 + 0.5) / 3.0
        x = min(max(x, room["x0"] + inset * 0.5),
                room["x1"] - inset * 0.5)
        y = min(max(y, room["y0"] + inset * 0.5),
                room["y1"] - inset * 0.5)

        out.append(Landmark(
            name=name, label=label, kind=kind, pos=(round(x, 3), round(y, 3)),
            interactable=bool(it.get("interactable", False)),
            note=str(it.get("note") or "")[:80],
        ))
    return out


def normalize_ambient(raw: Any) -> Dict[str, Any]:
    d = raw if isinstance(raw, dict) else {}
    temp = _f(d.get("temperature"), 22.0)
    light = _f(d.get("lighting"), 0.6)
    if light > 1.5:                       # 模型有时给百分比
        light = light / 100.0
    return {
        "temperature": round(min(max(temp, -40.0), 60.0), 1),
        "lighting": round(min(max(light, 0.0), 1.0), 3),
        "weather": str(d.get("weather") or "sunny")[:24],
    }


def build_from_spec(spec: Any, *, source: str = "user",
                    fallback_room: Optional[Dict[str, float]] = None
                    ) -> Environment:
    """从（可能不规范的）环境描述构造 Environment。

    这是**唯一的入口**：无论是内置默认、用户手填、还是大模型生成，
    最终都要经过这里，才能保证几何一定是合法的。
    """
    d = spec if isinstance(spec, dict) else {}
    fb = fallback_room or {"x0": -4.0, "y0": -4.0, "x1": 4.0, "y1": 3.5}
    room = normalize_room(d.get("room"), fb)
    landmarks = normalize_landmarks(d.get("landmarks"), room)
    if not landmarks:
        # 一个都没有时给最小可用集，避免小地图空白
        landmarks = _spread_defaults(room)

    env = Environment(
        scene_name=str(d.get("scene_name") or d.get("name") or "未命名环境")[:60],
        scene_type=str(d.get("scene_type") or d.get("type") or "indoor")[:32],
        description=str(d.get("description")
                        or d.get("desc") or "")[:1200],
        room=room,
        landmarks=landmarks,
        ambient=normalize_ambient(d.get("ambient")),
        sensory_sounds=[str(x)[:40] for x in
                        (d.get("sensory_sounds") or d.get("sounds") or [])][:8],
        sensory_smells=[str(x)[:40] for x in
                        (d.get("sensory_smells") or d.get("smells") or [])][:8],
        source=source,
        raw=dict(d),
    )
    sp = d.get("spawn")
    if isinstance(sp, (list, tuple)) and len(sp) >= 2:
        env.spawn = env.clamp(_f(sp[0]), _f(sp[1]), margin=0.4)
    else:
        cx, cy = env.center
        env.spawn = env.clamp(cx, cy, margin=0.4)
    return env


def _spread_defaults(room: Dict[str, float]) -> List[Landmark]:
    """没有任何地标时，沿墙铺几个通用位置。"""
    inset = min(0.4, (room["x1"] - room["x0"]) / 10.0,
                (room["y1"] - room["y0"]) / 10.0)
    cx = (room["x0"] + room["x1"]) / 2.0
    cy = (room["y0"] + room["y1"]) / 2.0
    return [
        Landmark("entrance", "入口", "door",
                 (cx, room["y0"] + inset), interactable=True),
        Landmark("window", "窗户", "window",
                 (room["x0"] + inset, cy)),
        Landmark("center", "房间中央", "other", (cx, cy), interactable=True),
    ]


# ----------------------------------------------------------------------
# 内置环境
# ----------------------------------------------------------------------
def classroom() -> Environment:
    """阿拜多斯旧校舍教室 —— 与旧版 galbeta 几何**完全一致**。

    旧版坐标（前端 LANDMARKS 常量）：
        blackboard[0,-4]  teacher_desk[0,-3]
        student_desk_1[-1.5,.5]  student_desk_2[1.5,.5]
        window_left[-4,1]  window_right[4,1]
        classroom_door[3.5,3.5]  wall_clock[2.5,-4]
        room x∈[-4,4]  y∈[-4,3.5]
    """
    return Environment(
        scene_name="阿拜多斯旧校舍教室",
        scene_type="classroom",
        description=(
            "一间位于阿拜多斯旧校舍内、略显陈旧但仍可使用的教室。"
            "木质课桌排成两列，黑板擦得不太干净，粉笔灰在斜射的阳光里浮着。"
            "靠走廊一侧是连排的窗户，窗框有些锈。后墙挂着停止走动的挂钟。"
            "空气里有旧木头、粉笔灰和一点灰尘的味道。"),
        room={"x0": -4.0, "y0": -4.0, "x1": 4.0, "y1": 3.5},
        landmarks=[
            Landmark("blackboard", "黑板", "board", (0.0, -4.0)),
            Landmark("teacher_desk", "讲台", "furniture", (0.0, -3.0)),
            Landmark("student_desk_1", "课桌 1", "seat", (-1.5, 0.5),
                     interactable=True),
            Landmark("student_desk_2", "课桌 2", "seat", (1.5, 0.5),
                     interactable=True),
            Landmark("window_left", "左窗", "window", (-4.0, 1.0)),
            Landmark("window_right", "右窗", "window", (4.0, 1.0)),
            Landmark("classroom_door", "教室门", "door", (3.5, 3.5),
                     interactable=True),
            Landmark("wall_clock", "挂钟", "clock", (2.5, -4.0)),
        ],
        ambient={"temperature": 22.0, "lighting": 0.62, "weather": "sunny"},
        sensory_sounds=["窗外偶尔传来的鸟鸣", "挂钟几乎不动的滴答声"],
        sensory_smells=["旧木头和粉笔灰的气味", "淡淡的灰尘味"],
        spawn=(0.0, 2.0),
        source="builtin",
    )


def server_room() -> Environment:
    """服务器机房 —— 渐进酱的"身体"所在。"""
    return Environment(
        scene_name="服务器机房",
        scene_type="server_room",
        description=(
            "一间 9×8 米的机房。四壁是深灰色吸音板，三排黑色机柜整齐排列，"
            "指示灯以固定的节奏闪烁。恒温恒湿系统低声运转，"
            "空气里有金属和硅胶的淡味。电缆束从天花板垂下，在机柜间穿行。"
            "远处偶尔传来风扇转速变化的嗡鸣。"),
        room={"x0": 0.0, "y0": 0.0, "x1": 9.0, "y1": 8.0},
        landmarks=[
            Landmark("rack_a", "一号机柜", "equipment", (1.5, 2.0),
                     interactable=True),
            Landmark("rack_b", "二号机柜", "equipment", (4.5, 2.0),
                     interactable=True),
            Landmark("rack_c", "三号机柜", "equipment", (7.5, 2.0),
                     interactable=True),
            Landmark("precision_ac", "精密空调", "equipment", (8.5, 6.5)),
            Landmark("ups_cabinet", "UPS 配电柜", "equipment", (0.8, 6.8)),
            Landmark("console", "运维监控台", "table", (4.5, 7.0),
                     interactable=True),
            Landmark("door", "机房门", "door", (4.5, 0.15),
                     interactable=True),
            Landmark("cable_tray", "走线桥架", "other", (4.5, 4.5)),
        ],
        ambient={"temperature": 18.0, "lighting": 0.42, "weather": "indoor"},
        sensory_sounds=["恒温系统的低鸣", "风扇转速变化的嗡声",
                        "指示灯继电器的轻响"],
        sensory_smells=["金属与硅胶的气味", "略微发凉的空气"],
        spawn=(4.5, 4.0),
        source="builtin",
    )


BUILTIN_ENVIRONMENTS = {
    "classroom": classroom,
    "server_room": server_room,
}

# 默认环境
# --------
# 旧版第5代前端的初始环境是写死的「服务器机房」（引导第 9 步：
# `环境（只读：服务器机房）· 系统预设环境 · 首次创建不可修改`，
# 描述原文「一间安静的服务器机房，成排的机柜泛着冷色指示灯，
# 风扇声和硬盘的嗡嗡声混在一起」）。那是**渐进酱**的家。
#
# 本项目早期版本回落到了教室，于是用户会看到"默认环境明明是机房，
# 小地图画的却是教室" —— 那正是用户报的问题。
DEFAULT_ENVIRONMENT = "server_room"


def default_environment() -> Environment:
    """按一句话描述之外的方式拿到默认环境。"""
    if DEFAULT_ENVIRONMENT == "classroom":
        return classroom()
    return server_room()


# 关键词 → 内置场景
# ------------------
# 用户（或角色设定）写了一段环境描述但没配大模型时，用它挑最接近的内置场景。
# 否则会出现"描述写的是旧校舍，实际住进机房"这种明显不对的结果
# （首跑欢迎页选白子时就会碰到）。
BUILTIN_KEYWORDS: Tuple[Tuple[str, Tuple[str, ...]], ...] = (
    ("server_room", ("机房", "机柜", "服务器", "机架", "散热", "显卡", "交换机",
                     "运维", "ups", "空调")),
    ("classroom", ("教室", "校舍", "黑板", "课桌", "讲台", "学校", "走廊",
                   "阿拜多斯", "高中")),
)


def match_builtin(description: str) -> Optional[Environment]:
    """按关键词挑一个内置场景。**挑不到返回 None**。

    ★ 零命中时必须返回 None。早期写法在 `best_hits == 0` 时也返回了
      `BUILTIN_ENVIRONMENTS[best]`（best 停在第一个候选），于是
      "一片星空下的草地"被匹配成了服务器机房 —— 一个完全无关的场景。
    """
    text = str(description or "").lower()
    if not text:
        return None
    best, best_hits = None, 0
    for name, words in BUILTIN_KEYWORDS:
        hits = sum(1 for w in words if w in text)
        if hits > best_hits:
            best, best_hits = name, hits
    if best is None or best_hits <= 0:
        return None
    maker = BUILTIN_ENVIRONMENTS.get(best)
    return maker() if maker else None


def spec_schema_hint() -> str:
    """给大模型看的 JSON 结构说明（与 build_from_spec 完全对齐）。"""
    return (
        '{\n'
        '  "scene_name": "中文场景名",\n'
        '  "scene_type": "classroom/server_room/rooftop/bedroom/...（英文小写）",\n'
        '  "description": "50-150 字的环境描述，要有光线、气味、声音的细节",\n'
        '  "room": {"x0": 0, "y0": 0, "x1": 8, "y1": 7.5},\n'
        '  "landmarks": [\n'
        '    {"name": "blackboard", "label": "黑板",\n'
        '     "kind": "board", "pos": [4, 0.4], "interactable": false}\n'
        '  ],\n'
        '  "ambient": {"temperature": 22, "lighting": 0.6, "weather": "sunny"},\n'
        '  "sensory_sounds": ["能听到的声音"],\n'
        '  "sensory_smells": ["能闻到的气味"],\n'
        '  "spawn": [4, 4]\n'
        '}\n'
        '要求：\n'
        '· room 是矩形，原点在左下角，x 向右、y 向上，单位米；\n'
        '· 每个 landmark 的 pos 必须落在 room 范围内；\n'
        '· kind 只能取：board/furniture/seat/window/door/clock/equipment/'
        'light/plant/bed/shelf/table/other；\n'
        '· landmarks 给 5-9 个，覆盖房间不同方位。'
    )


__all__ = [
    "Environment", "Landmark", "KIND_COLORS", "BUILTIN_ENVIRONMENTS",
    "classroom", "server_room", "default_environment",
    "DEFAULT_ENVIRONMENT", "match_builtin", "BUILTIN_KEYWORDS",
    "build_from_spec", "spec_schema_hint",
    "normalize_room", "normalize_landmarks", "normalize_ambient",
]
