# -*- coding: utf-8 -*-
"""
Shiroko β —— 启动入口

    python -m core                    # 启动（默认 127.0.0.1:8000）
    python -m core --port 9000
    python -m core --no-browser       # 不自动开浏览器
    python -m core --check            # 自检：环境/依赖/存档/API，不开服务
    python -m core --reset            # 清空存档与配置（会先备份）

启动流程
--------
    解析参数 → 建数据目录 → 写日志 → 载入配置 → 载入存档
        → 没有生命就按配置建一个 → 起 HTTP/WS → 起世界主循环 → 开浏览器

数据目录（%LOCALAPPDATA%\\ShirokoBeta，可用 --data 覆盖）
--------------------------------------------------------
    config.json     配置（含明文 API Key —— 见下）
    state.pkl       存档（pickle，原子写）
    backups/        人类可读备份，保留最近 50 份
    logs/           运行日志
    static/         前端页面（也可用 --static 指到别处）

安全提醒
--------
`config.json` 里是**明文 API Key**，这是旧版一直以来的做法。
文件权限交给操作系统，界面上会对 Key 打码显示。
"""

from __future__ import annotations

import argparse
import asyncio
import logging
import os
import signal
import subprocess
import sys
import threading
import time
import webbrowser
from pathlib import Path
from typing import Any, List, Optional
# 让 `python -m core` 与 `python core/__main__.py` 都能跑
if __package__ in (None, ""):                                # pragma: no cover
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
    __package__ = "core"

# 模块级 logger。
# ★ `_launch_window()` 这些模块级函数也要记日志，而 `main()` 里的
#   `log` 只是**局部变量** —— 之前模块级函数引用它就 NameError。
#   实测：WebView2 DLL 缺失时走回落分支，直接崩在 log.warning 上。
log = logging.getLogger("shiroko")

from . import APP_NAME, VERSION                           # noqa: E402
from . import geo, llm as llm_mod, runtime as rt_mod, server as srv_mod  # noqa: E402
from . import persona as persona_mod                      # noqa: E402

DEFAULT_HOST = "127.0.0.1"
DEFAULT_PORT = 8000

RULES = "=" * 66


# ----------------------------------------------------------------------
def data_dir(override: str = "") -> Path:
    if override:
        return Path(override).expanduser().resolve()
    base = os.environ.get("LOCALAPPDATA") or os.environ.get("APPDATA")
    if base:
        return Path(base) / "ShirokoBeta"
    return Path.home() / ".shirokobeta"


def setup_logging(log_dir: Path, verbose: bool = False) -> Path:
    log_dir.mkdir(parents=True, exist_ok=True)
    path = log_dir / ("shiroko_%s.log" % time.strftime("%Y%m%d"))
    root = logging.getLogger()
    root.setLevel(logging.DEBUG if verbose else logging.INFO)
    for h in list(root.handlers):
        root.removeHandler(h)

    fh = logging.FileHandler(path, encoding="utf-8")
    fh.setLevel(logging.DEBUG if verbose else logging.INFO)
    fh.setFormatter(logging.Formatter(
        "%(asctime)s %(levelname)-7s %(name)-18s %(message)s",
        datefmt="%H:%M:%S"))
    root.addHandler(fh)

    ch = logging.StreamHandler(sys.stderr)
    ch.setLevel(logging.DEBUG if verbose else logging.WARNING)
    ch.setFormatter(logging.Formatter("  %(levelname)s %(message)s"))
    root.addHandler(ch)

    # aiohttp 的访问日志太吵
    for noisy in ("aiohttp.access", "aiohttp.server", "asyncio"):
        logging.getLogger(noisy).setLevel(logging.WARNING)
    return path


def banner(rt: "rt_mod.Runtime", server_url: str, ddir: Path) -> None:
    key = str(rt.config.get("api_key") or "")
    lines = [
        "",
        RULES,
        "  %s  v%s" % (APP_NAME, VERSION),
        RULES,
        "  界面      %s" % server_url,
        "  数据目录  %s" % ddir,
        "  大模型    %s（%s）" % (
            rt.llm_pool.get("language").model,
            "已配置" if key else "未配置 —— 开始页会要求输入 API 密钥"),
        "  接入方式  %s" % ("QQ / OneBot" if rt.bridge == "qq" else "内置对讲机"),
        RULES,
    ]
    if rt.lives:
        lines.append("  数字生命")
        for cid, lf in rt.lives.items():
            lines.append("    · %-10s %s（%s）"
                         % (cid, lf.name,
                            "睡眠中" if lf.memory.is_asleep else lf.plan))
        lines.append(RULES)
    lines.append("  在世界里：1 模拟分钟 = 1 真实秒，一天 = 24 真实分钟")
    lines.append("  按 Ctrl+C 退出（退出前会自动存档与备份）")
    lines.append(RULES)
    lines.append("")
    print("\n".join(lines), flush=True)


# ----------------------------------------------------------------------
def self_check(ddir: Path, static_dir: Optional[Path]) -> int:
    """自检。返回 0 表示全部通过。"""
    print(RULES)
    print("  %s v%s —— 自检" % (APP_NAME, VERSION))
    print(RULES)
    problems: List[str] = []

    def ok(label: str, cond: bool, extra: str = "") -> None:
        print("  [%s] %-34s %s" % ("OK" if cond else "!!", label, extra))
        if not cond:
            problems.append(label)

    ok("Python 版本 >= 3.11", sys.version_info >= (3, 11),
       "%d.%d.%d" % sys.version_info[:3])

    try:
        import aiohttp
        ok("aiohttp 可用", True, aiohttp.__version__)
    except ImportError:
        ok("aiohttp 可用", False, "缺少 aiohttp，无法启动服务")

    from . import fep, homeo, life as life_mod, memory, onebot, snn
    ok("核心模块可导入", True,
       "%d 个模块" % len([geo, fep, homeo, life_mod, memory, onebot, snn]))

    ok("SNN 规模口径一致",
       snn.BASE_SYNAPSES == sum(r.synapses for r in snn.REGION_SPECS),
       "%d 突触 / %d 神经元" % (snn.BASE_SYNAPSES, snn.BASE_NEURONS))
    ok("内稳态 26 维", homeo.FIELD_COUNT == 26, "%d" % homeo.FIELD_COUNT)

    # 数据目录可写
    try:
        ddir.mkdir(parents=True, exist_ok=True)
        probe = ddir / ".write_probe"
        probe.write_text("x", encoding="utf-8")
        probe.unlink()
        ok("数据目录可写", True, str(ddir))
    except OSError as e:
        ok("数据目录可写", False, str(e)[:50])

    # 前端
    if static_dir is not None and (static_dir / "index.html").is_file():
        size = (static_dir / "index.html").stat().st_size
        ok("前端页面存在", True, "%.1f KB" % (size / 1024))
    else:
        ok("前端页面存在", False,
           "缺少 index.html（界面会开不出来）")

    # 默认环境能建起来
    try:
        e = geo.classroom()
        ok("内置环境可构建", len(e.landmarks) > 0,
           "%s，%d 个地标" % (e.scene_name, len(e.landmarks)))
    except Exception as ex:                                      # noqa: BLE001
        ok("内置环境可构建", False, str(ex)[:50])

    # 一个生命能跑
    try:
        lf = life_mod.DigitalLife(scale=0)
        f = lf.tick("自检")
        ok("数字生命可运行", "homeo" in f,
           "%d 维内稳态" % len(f["homeo"]))
    except Exception as ex:                                      # noqa: BLE001
        ok("数字生命可运行", False, str(ex)[:60])

    # 端口是否被占
    import socket
    s = socket.socket()
    try:
        s.bind((DEFAULT_HOST, DEFAULT_PORT))
        ok("默认端口 %d 空闲" % DEFAULT_PORT, True)
    except OSError:
        ok("默认端口 %d 空闲" % DEFAULT_PORT, False, "已被占用，用 --port 换一个")
    finally:
        s.close()

    # API Key
    cfg_file = ddir / "config.json"
    key = ""
    if cfg_file.is_file():
        import json
        try:
            key = str(json.loads(cfg_file.read_text(
                encoding="utf-8")).get("api_key") or "")
        except (OSError, ValueError):
            pass
    if key:
        ok("API 密钥已配置", True, "%s…%s" % (key[:6], key[-4:]))
        c = llm_mod.DeepSeekClient(api_key=key)
        try:
            r = c.ping()
            models = [m.id for m in c.list_models(refresh=True)]
            ok("能连上 DeepSeek", True,
               "%s · %s · %s" % (r.model, r.text.strip()[:14],
                                 ",".join(models)))
        except Exception as ex:                                  # noqa: BLE001
            ok("能连上 DeepSeek", False, str(ex)[:70])
    else:
        ok("API 密钥已配置", False, "还没填 —— 打开界面时开始页会让你输")

    print(RULES)
    if problems:
        print("  有 %d 项需要处理：" % len(problems))
        for p in problems:
            print("    · %s" % p)
    else:
        print("  全部通过 —— 可以直接启动")
    print(RULES)
    return 1 if problems else 0


# ----------------------------------------------------------------------
async def run(args: argparse.Namespace) -> int:
    ddir = data_dir(args.data)
    log_path = setup_logging(ddir / "logs", args.verbose)
    log = logging.getLogger("shiroko")

    static_dir = Path(args.static).expanduser().resolve() if args.static \
        else Path(__file__).resolve().parent.parent / "static"
    avatar_dir = static_dir / "avatars" if static_dir.is_dir() else None

    if args.check:
        return self_check(ddir, static_dir)

    if args.reset:
        print("即将清空配置与存档。现有文件会先改名保留。")
        try:
            ans = input("确认？输入 yes 继续：").strip().lower()
        except (EOFError, KeyboardInterrupt):
            ans = ""
        if ans not in ("yes", "y", "是"):
            print("已取消。")
            return 0
        stamp = time.strftime("%Y%m%d_%H%M%S")
        for name in ("config.json", "state.pkl"):
            p = ddir / name
            if p.is_file():
                p.rename(p.with_name("%s.bak_%s" % (name, stamp)))
                print("  已保留 %s → %s.bak_%s" % (name, name, stamp))
        print("已重置。下次启动会重新走一遍引导。")

    rt = rt_mod.Runtime(
        config_file=ddir / "config.json",
        state_file=ddir / "state.pkl",
        backup_dir=ddir / "backups",
        log_dir=ddir / "logs")

    print(RULES)
    print("  %s v%s 正在启动…" % (APP_NAME, VERSION))
    print(RULES)

    cfg = rt.load_config()
    had_state = rt.load()
    print("  配置      %s" % ("已读取" if (ddir / "config.json").is_file()
                              else "新建（默认值）"))
    print("  存档      %s" % ("已读取" if had_state else "无（全新开始）")
          + ("，%d 个生命" % len(rt.lives) if had_state else ""))

    # 没有生命时：**已经配过密钥**才自动建一个（老用户重启后立刻可用）。
    # 全新安装（没密钥）不建 —— 那会绕过首跑欢迎页，用户就没机会选角色了。
    if not rt.lives:
        if str(rt.config.get("api_key") or "").strip():
            lf = rt.create_life()
            print("  数字生命  已创建 %s（%s）" % (lf.name, lf.char_id))
        else:
            print("  数字生命  还没有 —— 打开界面时先填密钥，再选角色")

    # 默认环境同步到世界时钟
    for lf in rt.lives.values():
        lf.env.ambient["weather"] = rt.clock.weather
        lf.env.ambient["lighting"] = rt.clock.lighting(lf.env.scene_type)
        print("  环境      %s（%d 个地标）"
              % (lf.env.scene_name, len(lf.env.landmarks)))

    server = srv_mod.ShirokoServer(
        rt, host=args.host, port=args.port,
        static_dir=static_dir if static_dir.is_dir() else None,
        avatar_dir=avatar_dir)

    # QQ 桥接
    if rt.bridge == "qq":
        try:
            await server._ensure_onebot(connect=True)
            print("  QQ 桥接   已启动")
        except Exception as e:                                   # noqa: BLE001
            log.warning("QQ 桥接启动失败：%s", e)
            print("  QQ 桥接   启动失败（不影响使用）")

    await server.start()
    url = server.url
    banner(rt, url, ddir)
    print("  日志      %s" % log_path)
    print()

    world = asyncio.get_running_loop().create_task(rt.run())

    # ---- 界面：原生窗口（优先）→ 浏览器 ----
    host_proc = None
    if args.window:
        host_proc = _launch_window(url, args.host, args.port)
        if host_proc is not None:
            print("  窗口      已启动（关掉窗口即退出程序）")
        elif args.browser:
            print("  窗口      找不到原生窗口程序，改用浏览器")
    if host_proc is None and args.browser:
        def _open() -> None:
            time.sleep(1.0)
            try:
                webbrowser.open(url)
            except Exception:                                    # noqa: BLE001
                pass
        threading.Thread(target=_open, daemon=True).start()

    stop = asyncio.Event()

    def _on_signal(*_: object) -> None:
        stop.set()

    loop = asyncio.get_running_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, _on_signal)
        except (NotImplementedError, AttributeError, ValueError):
            signal.signal(sig, _on_signal)

    # 关掉窗口 = 退出程序（原生窗口模式下就是主循环的退出条件）
    #
    # ★★ 但"宿主退出"不等于"用户关窗"。实测两种情况下宿主会退出，
    #    而用户**什么都没看见**：
    #      · WebView2 在提权进程里起不来（服务器运行失败）
    #      · 数据目录不可写（无法读取或写入其数据目录）
    #    这时如果直接 stop.set()，用户双击之后就是一片空白 ——
    #    这正是他报的现象。所以要看**握手文件有没有出现过**：
    #      出现过 → 窗口真的开过，这次退出就是用户关窗 → 退出程序
    #      没出现 → 窗口压根没起来 → 开浏览器兜底，程序继续跑
    if host_proc is not None:
        async def _watch_host() -> None:
            while host_proc.poll() is None:
                await asyncio.sleep(0.6)
            log.info("窗口宿主已退出（退出码 %s）", host_proc.returncode)

            if _window_ok_file().is_file():
                log.info("窗口正常关闭 —— 程序一并退出")
                stop.set()
                return

            # 窗口没起来过：换个方式给她一个界面，别让用户对着空气
            log.warning("窗口从未成功显示 —— 改用浏览器打开，程序继续运行")
            try:
                webbrowser.open(url)
                log.info("已用默认浏览器打开：%s", url)
            except Exception as exc:                             # noqa: BLE001
                log.error("连浏览器都打不开：%s —— 请手动访问 %s", exc, url)
            print("\n  没能打开原生窗口，已改用浏览器。")
            print("  地址：%s\n" % url, flush=True)
        asyncio.get_running_loop().create_task(_watch_host())

    try:
        await stop.wait()
    except (asyncio.CancelledError, KeyboardInterrupt):
        pass
    finally:
        print("\n  正在收尾…", flush=True)
        await rt.shutdown()
        try:
            await asyncio.wait_for(world, timeout=5.0)
        except (asyncio.TimeoutError, asyncio.CancelledError, Exception):  # noqa: BLE001
            world.cancel()
        await server.stop()
        if host_proc is not None and host_proc.poll() is None:
            try:
                host_proc.terminate()
            except Exception:                                    # noqa: BLE001
                pass
        print("  已存档并退出。")
    return 0


def _launch_window(url: str, host: str, port: int) -> Optional[Any]:
    r"""启动原生窗口宿主（WebView2）。

    宿主是一个自写的极小 C# WinForms 程序（`ShirokoWindow.exe`），
    因为 pywebview / pythonnet 在 PyInstaller 打包后会坏掉
    （`Failed to resolve Python.Runtime.Loader.Initialize`）。

    找不到宿主就返回 None，调用方回落到浏览器 —— **不是错误**，
    只是少了个原生外观。

    ★ 还要处理"宿主起来了但立刻死掉"。
      没装 WebView2 运行时的机器上，宿主会**静默秒退、退出码 0、
      没有任何 stderr**（实测过：拿一个必定失败的 URL 去跑，
      返回码 0、stdout/stderr 都是空的）。
      如果不看这个，`_watch_host` 会把"秒退"当成"用户关窗" →
      整个程序跟着退出，用户双击之后**什么都没看见**。
      所以这里等一下：活得下来才算窗口开成功。

    ★★ 但光看进程活不活**不够**。实测两种失败都是"进程活着但窗口没成"：
      · WebView2 DLL 被移走 → 宿主照样活（Windows 会去系统目录找）
      · 数据目录不可写 → 异常被宿主 catch，弹个框，进程一直挂着
      所以改成**文件握手**：宿主初始化成功后会写
      `%LOCALAPPDATA%\ShirokoBeta\webview_data\window-ok.txt`。
      这里先把这个文件删掉，启动后等它出现；等不到就回落浏览器。
    """
    exe = _find_window_host()
    if exe is None:
        return None
    need = ("WebView2Loader.dll", "Microsoft.Web.WebView2.Core.dll")
    missing = [n for n in need if not (exe.parent / n).is_file()]
    if missing:
        log.warning("窗口宿主缺少 %s —— 改用浏览器打开",
                    "、".join(missing))
        return None

    # 握手文件：先清掉旧的，否则会误判成"这次也成功了"
    okfile = _window_ok_file()
    try:
        if okfile.is_file():
            okfile.unlink()
    except OSError:
        pass

    try:
        proc = subprocess.Popen(
            [str(exe), url, APP_NAME, "1280", "840"],
            cwd=str(exe.parent))
    except OSError:
        return None

    deadline = time.time() + 12.0
    while time.time() < deadline:
        if okfile.is_file():
            log.info("原生窗口已就绪")
            return proc
        if proc.poll() is not None:
            log.warning("窗口宿主退出（退出码 %s）—— 改用浏览器打开",
                        proc.returncode)
            return None
        time.sleep(0.15)

    log.warning("等了 12 秒窗口仍未就绪 —— 改用浏览器打开")
    try:
        proc.terminate()
    except Exception:                                        # noqa: BLE001
        pass
    return None


def _window_ok_file() -> Path:
    """宿主成功后写的握手文件（路径要和 ShirokoWindow.cs 里一致）。"""
    base = os.environ.get("LOCALAPPDATA") or os.environ.get("TEMP") or "."
    return Path(base) / "ShirokoBeta" / "webview_data" / "window-ok.txt"


def _find_window_host() -> Optional[Path]:
    """在几个常规位置找 ShirokoWindow.exe。

    打包后的目录结构：
        ShirokoBeta.exe
        ShirokoWindow.exe          ← 与 exe 同级
        Microsoft.Web.WebView2.*.dll
        WebView2Loader.dll
        _internal\\...              ← PyInstaller 的东西
        static\\...
        data\\...
    """
    here = Path(__file__).resolve().parent
    root = Path(sys.executable).resolve().parent
    cands = [
        root / "ShirokoWindow.exe",
        root / "host" / "ShirokoWindow.exe",
        here / "ShirokoWindow.exe",
        here.parent / "ShirokoWindow.exe",
        here.parent / "packaging" / "host" / "ShirokoWindow.exe",
    ]
    meipass = getattr(sys, "_MEIPASS", None)
    if meipass:
        cands.insert(0, Path(meipass) / "ShirokoWindow.exe")
    for c in cands:
        try:
            if c.is_file():
                return c
        except OSError:
            continue
    return None


# ----------------------------------------------------------------------
def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="python -m core",
        description="%s v%s —— 数字生命运行时" % (APP_NAME, VERSION),
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""示例:
  python -m core                     启动（自动开浏览器）
  python -m core --port 9000         换端口
  python -m core --no-browser        不开浏览器
  python -m core --check             只做自检，不开服务
  python -m core --reset             清空配置与存档（保留备份）
""")
    p.add_argument("--host", default=DEFAULT_HOST, help="监听地址")
    p.add_argument("--port", type=int, default=DEFAULT_PORT, help="监听端口")
    p.add_argument("--data", default="", help="数据目录（默认 %%LOCALAPPDATA%%\\ShirokoBeta）")
    p.add_argument("--static", default="", help="前端目录（默认包内的 static）")
    p.add_argument("--no-browser", dest="browser", action="store_false",
                   default=True, help="启动后不自动打开浏览器")
    p.add_argument("--window", action="store_true",
                   help="用原生窗口打开（需要 ShirokoWindow.exe）")
    p.add_argument("--check", action="store_true", help="自检后退出")
    p.add_argument("--reset", action="store_true", help="清空配置与存档")
    p.add_argument("-v", "--verbose", action="store_true", help="详细日志")
    return p


def main(argv: Optional[List[str]] = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        return asyncio.run(run(args))
    except KeyboardInterrupt:
        return 130
    except Exception as e:                                       # noqa: BLE001
        print("\n启动失败：%s" % e, file=sys.stderr)
        import traceback
        traceback.print_exc(limit=6)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
