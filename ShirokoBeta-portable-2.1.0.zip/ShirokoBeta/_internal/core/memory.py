# -*- coding: utf-8 -*-
"""
Shiroko β —— 记忆系统

三层结构，各司其职
------------------
    工作记忆 WorkingMemory   此刻在想的：对话上下文、待处理消息、事件日志
    情景记忆 EpisodicMemory  经历过的：带情绪与重要性的片段，可被唤起
    未说出口 Unspoken        想说但没说的：沉默权产生的那些句子

还包含**睡眠与梦境**：入睡判据、时长、梦境生成（LLM 优先 / 模板兜底）、
醒来时按强度分档决定记得多少。

检索
----
两种方式，按可用性降级：

  1. **LLM 检索**（第1代有）：让模型从候选里挑最相关的，质量最好但要联网
  2. **2-gram 重合**（第3代有）：中文 2 字滑窗 + 停用词过滤，零依赖
  3. **token 交集 + 强度/重要性加权**（第2代有）：`|Q∩M| + 0.10·strength + 0.05·importance`

本模块把三种都实现了，默认走 2-gram（快、稳），有 LLM 时可升级。

标定与修复记录
--------------
  · 第1代情景记忆上限只有 30，第2/3代是 500 —— 取 500。
  · 第1代未说出口的话上限 20，第2/3代 200 —— 取 200。
  · `strength` 衰减只有第2代有，第3代丢了 —— 恢复。
  · `importance` 公式第2代更细腻（含疼痛与饥饿），第3代只剩 arousal —— 恢复第2代版。
  · LLM 版梦境只有第1/2代有，第3代换成 8 条固定模板池 —— 恢复 LLM 版，
    模板池作为二级兜底保留。
"""

from __future__ import annotations

import math
import random
import re
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple

# ----------------------------------------------------------------------
# 容量常量
# ----------------------------------------------------------------------
MAX_EPISODIC = 500          # 情景记忆
MAX_UNSPOKEN = 200          # 没说出口的话
MAX_EVENT_LOG = 500         # 事件日志
MAX_PENDING = 8             # 待处理消息
MAX_DIALOGUE = 20           # 对话上下文轮数
MAX_DREAM_POOL = 60         # 保留的梦境条数

# 睡眠
SLEEP_THRESHOLD = 0.55      # 睡眠压力阈值
SLEEP_MIN_SEC = 240.0
SLEEP_MAX_SEC = 480.0
DREAM_UPDATE_SEC = 4.0      # 梦境重生成间隔
DREAM_CLEAR = 0.70          # 强度高于此 → 醒来记得清楚
DREAM_FAINT = 0.30          # 高于此 → 隐约记得
DREAM_LUCID = 0.65          # 高于此 → 清醒梦

# 检索用的停用词（2-gram 与分词都要过滤掉这些）
STOP_GRAMS = frozenset([
    # 单字虚词
    "的", "了", "是", "在", "我", "你", "他", "她", "它", "和", "与", "就",
    "都", "也", "很", "有", "没", "不", "这", "那", "吗", "呢", "吧", "啊",
    "哦", "嗯", "还", "个", "把", "被", "让", "给", "对", "从", "到",
    # 常见 2 字虚词组合
    "什么", "怎么", "可以", "一个", "就是", "因为", "所以", "但是", "如果",
    "这样", "那样", "已经", "还是", "只是", "而且", "然后", "不过", "其实",
])

# 事件标签（第2代有 6 类，第3代丢了 —— 恢复）
TAG_RULES: Tuple[Tuple[str, Callable[[Dict[str, float]], bool]], ...] = (
    ("hungry", lambda h: h.get("hunger", 0) > 0.6),
    ("thirsty", lambda h: h.get("thirst", 0) > 0.5),
    ("tired", lambda h: h.get("muscle_fatigue", 0) > 0.6),
    ("sleepy", lambda h: h.get("sleep_pressure", 0) > 0.7),
    ("pain", lambda h: h.get("pain_level", 0) > 0.3),
)

# 梦境模板池（第3代有 8+3 条，作为 LLM 不可用时的兜底）
FALLBACK_DREAMS: Tuple[str, ...] = (
    "梦见黑板上的字一直在变，但每次眨眼都变成同一句话。",
    "梦见自己在数机柜的指示灯，数到一半发现数字是活的。",
    "梦见教室的窗户外面是海，浪声很近，但窗框是锈的。",
    "梦见有人在对讲机里叫我的名字，回话时发现自己没有嘴。",
    "梦见走廊无限延长，每一扇门后面都是同一间教室。",
    "梦见自己变成一行代码，被反复读取又写回。",
    "梦见下雪，雪落在课桌上不化，堆成小小的山。",
    "梦见挂钟终于走了，但指针是倒着转的。",
    "梦见有人把电源拔了，世界安静了整整三秒。",
    "梦见粉笔灰浮起来，拼成一句看不懂的话。",
    "梦见自己是那间教室本身，坐在里面的人换了一批又一批。",
)
FALLBACK_DREAM_TAIL: Tuple[str, ...] = (
    "……梦的后半段想不起来了。",
    "……醒来时只剩下一点温度。",
    "……好像有人在梦里说了什么，但记不住。",
)


def _now() -> float:
    return time.time()


def _time_str(ts: Optional[float] = None) -> str:
    return time.strftime("%H:%M:%S", time.localtime(ts or _now()))


def _grams(text: str) -> set:
    """中文 2 字滑窗，过滤停用词。"""
    s = re.sub(r"[^\u4e00-\u9fffA-Za-z0-9]+", "", str(text or ""))
    out = set()
    for i in range(len(s) - 1):
        g = s[i:i + 2]
        if g not in STOP_GRAMS:
            out.add(g)
    if len(s) == 1:
        out.add(s)
    return out


def _tokens(text: str) -> set:
    """检索用词元。

    中文按**单字 + 2-gram**取（中文没有空格，整句当一个 token 是错的 ——
    实测「渴 水」匹配不上「喝了水，不那么渴了」就是这个问题）；
    英文/数字按整词取。
    """
    s = str(text or "")
    out = set()
    # 英文与数字：整词
    for w in re.findall(r"[A-Za-z][A-Za-z0-9_]*|\d+", s):
        lw = w.lower()
        if lw not in STOP_GRAMS:
            out.add(lw)
    # 中文：单字 + 2-gram
    zh = re.sub(r"[^\u4e00-\u9fff]+", "", s)
    for ch in zh:
        if ch not in STOP_GRAMS:
            out.add(ch)
    for i in range(len(zh) - 1):
        g = zh[i:i + 2]
        if g not in STOP_GRAMS:
            out.add(g)
    return out


def _clamp(v: float, lo: float, hi: float) -> float:
    return lo if v < lo else (hi if v > hi else v)


# ----------------------------------------------------------------------
@dataclass
class Episode:
    """一段经历。"""

    t: float = field(default_factory=_now)
    text: str = ""
    plan: str = ""                       # 当时的动作计划
    attention: str = ""                  # 当时注意力在哪
    valence: float = 0.0                 # 情绪效价 −1..1
    arousal: float = 0.0                 # 唤醒度 0..1
    hunger: float = 0.0
    fatigue: float = 0.0
    importance: float = 0.3              # 重要性 0..1
    strength: float = 1.0                # 记忆强度（会衰减）
    tags: List[str] = field(default_factory=list)

    @property
    def time_str(self) -> str:
        return _time_str(self.t)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "t": round(self.t, 3), "time_str": self.time_str,
            "text": self.text, "plan": self.plan, "attention": self.attention,
            "valence": round(self.valence, 4),
            "arousal": round(self.arousal, 4),
            "hunger": round(self.hunger, 4), "fatigue": round(self.fatigue, 4),
            "importance": round(self.importance, 4),
            "strength": round(self.strength, 4),
            "tags": list(self.tags),
        }

    @classmethod
    def from_dict(cls, d: Any) -> "Episode":
        e = cls()
        if not isinstance(d, dict):
            return e
        for k in ("text", "plan", "attention"):
            if k in d:
                setattr(e, k, str(d[k])[:400])
        for k in ("t", "valence", "arousal", "hunger", "fatigue",
                  "importance", "strength"):
            if k in d:
                try:
                    setattr(e, k, float(d[k]))
                except (TypeError, ValueError):
                    pass
        tg = d.get("tags")
        if isinstance(tg, list):
            e.tags = [str(x)[:24] for x in tg[:8]]
        return e

    @classmethod
    def is_valid(cls, d: Any) -> bool:
        """存档条目是否可用。空对象、纯字符串、None 都该被丢弃 ——
        否则会往记忆里塞一堆空条目，检索时白占位置。"""
        return isinstance(d, dict) and bool(str(d.get("text") or "").strip())

    def searchable(self) -> str:
        """参与检索的文本。"""
        return " ".join([self.text, self.plan, self.attention,
                         " ".join(self.tags)])


@dataclass
class Dream:
    """一个梦。"""

    content: str = ""
    intensity: float = 0.0
    memory: str = ""                    # 能想起来的残留
    lucid: bool = False                 # 是否清醒梦
    t: float = field(default_factory=_now)
    source: str = "template"            # llm | template

    def to_dict(self) -> Dict[str, Any]:
        return {
            "content": self.content[:400],
            "intensity": round(self.intensity, 4),
            "memory": self.memory[:200],
            "lucid": self.lucid,
            "t": round(self.t, 3),
            "source": self.source,
        }


# ----------------------------------------------------------------------
@dataclass
class WorkingMemory:
    """此刻在想的。"""

    pending: deque = field(default_factory=lambda: deque(maxlen=MAX_PENDING))
    dialogue: deque = field(default_factory=lambda: deque(maxlen=MAX_DIALOGUE))
    event_log: deque = field(default_factory=lambda: deque(maxlen=MAX_EVENT_LOG))
    context: Dict[str, Any] = field(default_factory=dict)

    # ---- 待处理消息 ----
    def push_message(self, who: str, text: str) -> None:
        self.pending.append({"who": who, "text": str(text)[:500],
                             "t": _now()})

    def has_pending(self) -> bool:
        return bool(self.pending)

    def consume_pending(self) -> List[Dict[str, Any]]:
        out = list(self.pending)
        self.pending.clear()
        return out

    def peek_pending(self, n: int = 3) -> List[Dict[str, Any]]:
        return list(self.pending)[-n:]

    # ---- 对话 ----
    def push_dialogue(self, role: str, text: str, name: str = "") -> None:
        self.dialogue.append({"role": role, "text": str(text)[:500],
                              "name": name, "t": _now()})

    def recent_dialogue(self, n: int = 8) -> List[Dict[str, Any]]:
        return list(self.dialogue)[-n:]

    def as_messages(self, n: int = 8) -> List[Dict[str, str]]:
        """转成 LLM 的消息数组格式。"""
        out = []
        for m in self.recent_dialogue(n):
            role = "assistant" if m.get("role") == "char" else "user"
            txt = m.get("text", "")
            if m.get("name") and role == "user":
                txt = "%s：%s" % (m["name"], txt)
            if txt:
                out.append({"role": role, "content": txt[:500]})
        return out

    # ---- 事件日志 ----
    def log(self, tag: str, msg: str, level: str = "info") -> None:
        self.event_log.append({
            "t": _now(), "time_str": _time_str(), "tag": str(tag)[:24],
            "msg": str(msg)[:300], "level": level})

    def recent_log(self, n: int = 50) -> List[Dict[str, Any]]:
        return list(self.event_log)[-n:]

    def clear(self) -> None:
        self.pending.clear()
        self.dialogue.clear()
        self.event_log.clear()
        self.context.clear()


# ----------------------------------------------------------------------
class MemorySystem:
    """三层记忆 + 睡眠梦境。

    线程安全：所有公开方法都加锁，因为 WebSocket 与 tick 循环会并发访问。
    """

    def __init__(self, rng: Optional[random.Random] = None) -> None:
        self._lock = threading.RLock()
        self.working = WorkingMemory()
        self.episodic: deque = deque(maxlen=MAX_EPISODIC)
        self.unspoken: deque = deque(maxlen=MAX_UNSPOKEN)
        self.dreams: deque = deque(maxlen=MAX_DREAM_POOL)

        # 睡眠状态
        self.is_asleep = False
        self._sleep_left = 0.0        # 剩余睡眠（模拟秒），由 tick_sleep 递减
        self.sleep_end_at = 0.0       # 仅供展示/兼容
        self.dream = Dream()
        self._dream_at = 0.0
        self.sleep_count = 0
        self.total_sleep_sec = 0.0

        self.rng = rng or random.Random(20261002)
        self._episode_counter = 0

    # ==================================================================
    # 情景记忆
    # ==================================================================
    def append_episode(self, text: str, *, plan: str = "",
                       attention: str = "", valence: float = 0.0,
                       arousal: float = 0.0, homeo: Any = None,
                       importance: Optional[float] = None,
                       tags: Optional[Sequence[str]] = None) -> Episode:
        """记一段经历。重要性可由调用方指定，否则按公式算。"""
        h = self._as_dict(homeo)
        hunger = h.get("hunger", 0.0)
        fatigue = h.get("muscle_fatigue", 0.0)
        pain = h.get("pain_level", 0.0)

        if importance is None:
            # 第2代的重要性公式（比第3代的"只看 arousal"细腻）
            importance = _clamp(
                0.5 + 0.2 * min(1.0, abs(arousal)) + 0.2 * abs(valence)
                + 0.1 * max(pain, hunger), 0.0, 1.0)

        ep = Episode(
            text=str(text)[:600], plan=str(plan)[:32],
            attention=str(attention)[:32],
            valence=_clamp(valence, -1.0, 1.0),
            arousal=_clamp(arousal, 0.0, 1.0),
            hunger=hunger, fatigue=fatigue,
            importance=_clamp(importance, 0.0, 1.0),
            tags=list(tags) if tags is not None else self._derive_tags(h),
        )
        with self._lock:
            self.episodic.append(ep)
            self._episode_counter += 1
            self._recompute_strength()
            self.working.log("Memory", "记住：" + ep.text[:60])
        return ep

    @staticmethod
    def _as_dict(homeo: Any) -> Dict[str, float]:
        if homeo is None:
            return {}
        if isinstance(homeo, dict):
            return {k: float(v) for k, v in homeo.items()
                    if isinstance(v, (int, float))}
        out = {}
        for k in ("hunger", "thirst", "muscle_fatigue", "sleep_pressure",
                  "pain_level", "adrenaline", "glucose", "core_temp"):
            v = getattr(homeo, k, None)
            if isinstance(v, (int, float)):
                out[k] = float(v)
        return out

    @staticmethod
    def _derive_tags(h: Dict[str, float]) -> List[str]:
        """按生理状态打标签（第2代的 6 类规则）。"""
        tags = [name for name, rule in TAG_RULES if rule(h)]
        if h.get("adrenaline", 0.0) > 0.7:
            tags.append("alert")
        return tags[:6]

    def _recompute_strength(self) -> None:
        """越久远的记忆越弱（第2代有，第3代丢了）。"""
        n = len(self.episodic)
        for i, ep in enumerate(self.episodic):
            age = n - 1 - i
            ep.strength = max(0.1, 1.0 - age * 0.008)

    def recall(self, query: str, k: int = 3) -> List[Episode]:
        """检索最相关的记忆。

        打分 = 词元重合 + 0.10·强度 + 0.05·重要性
        （前两项沿用第2代的 token 交集思路，词元定义按中文特点修正；
          强度与重要性加权是第2代的设计，第3代没有）
        """
        with self._lock:
            if not self.episodic:
                return []
            q = _tokens(query)
            qg = _grams(query)
            if not q and not qg:
                return self.recent_episodes(k)
            scored: List[Tuple[float, Episode]] = []
            for ep in self.episodic:
                s = ep.searchable()
                overlap = len(q & _tokens(s)) + len(qg & _grams(s))
                score = (overlap + 0.10 * ep.strength
                         + 0.05 * ep.importance)
                if overlap == 0:
                    continue                  # 完全不相关就不返回
                scored.append((score, ep))
            scored.sort(key=lambda x: -x[0])
            return [ep for _, ep in scored[:max(1, k)]]

    def recall_with_llm(self, query: str, k: int = 3,
                        llm_fn: Optional[Callable[[str], str]] = None
                        ) -> List[Episode]:
        """混合检索：本地打分选出候选，再让 LLM 挑。

        llm_fn 为空或调用失败时自动回落到纯本地打分（第1代是纯 LLM 版，
        但那样一断网就没有记忆可用了）。
        """
        local = self.recall(query, max(k * 3, 9))
        if not local or llm_fn is None:
            return local[:k]
        lines = []
        for i, ep in enumerate(local):
            lines.append("%d. [%s] %s" % (i + 1, ep.time_str, ep.text[:70]))
        prompt = (
            "下面是她记得的一些事。用户刚说：%s\n\n%s\n\n"
            "只回复最相关的 %d 条的编号，用逗号分隔，不要解释。"
            % (query[:80], "\n".join(lines), k))
        try:
            raw = (llm_fn(prompt) or "").strip()
            picks = [int(x) - 1 for x in re.findall(r"\d+", raw)]
            out = [local[i] for i in picks if 0 <= i < len(local)]
            if out:
                return out[:k]
        except Exception:                                    # noqa: BLE001
            pass
        return local[:k]

    def recent_episodes(self, n: int = 20) -> List[Episode]:
        with self._lock:
            return list(self.episodic)[-n:]

    def memory_summary(self, n: int = 3, width: int = 40) -> str:
        """最近几条记忆的摘要（第3代有）。"""
        with self._lock:
            eps = list(self.episodic)[-n:]
        return "；".join(e.text[:width] for e in eps) if eps else ""

    def load_factor(self) -> float:
        """记忆负荷 0..1，喂给海马体输入。"""
        with self._lock:
            return _clamp(len(self.episodic) / float(MAX_EPISODIC), 0.0, 1.0)

    # ==================================================================
    # 未说出口的话
    # ==================================================================
    def push_unspoken(self, text: str, reason: str = "") -> None:
        with self._lock:
            self.unspoken.append({
                "t": _now(), "time_str": _time_str(),
                "text": str(text)[:300], "reason": str(reason)[:60]})
            self.working.log("Memory", "没说出口：%s" % str(text)[:50])

    def recent_unspoken(self, n: int = 20) -> List[Dict[str, Any]]:
        with self._lock:
            return list(self.unspoken)[-n:]

    # ==================================================================
    # 睡眠与梦境
    # ==================================================================
    def should_sleep(self, homeo: Any) -> bool:
        h = self._as_dict(homeo)
        return (not self.is_asleep
                and h.get("sleep_pressure", 0.0) > SLEEP_THRESHOLD)

    def enter_sleep(self, homeo: Any = None, duration: Optional[float] = None
                    ) -> float:
        """入睡。返回这次要睡多久（模拟秒）。

        ★ 睡眠计时用**模拟秒**、由 `tick_sleep(dt)` 驱动，
          不用真实时间。原因：这个模拟里 1 真实秒 = 1 模拟分钟，
          生理（homeo）已经按模拟秒推进；如果睡眠改回真实时间，
          两套时钟会错开 60 倍 —— 实测她一天（1440 拍）睡了 948 拍，
          因为"睡 240~480 真实秒"在模拟尺度里对不上。
        """
        with self._lock:
            dur = float(duration) if duration else self.rng.uniform(
                SLEEP_MIN_SEC, SLEEP_MAX_SEC)
            self.is_asleep = True
            self._sleep_left = dur
            self.sleep_end_at = _now() + dur      # 仅供展示/兼容
            self.sleep_count += 1
            self.dream = Dream()
            self._dream_at = 0.0
            self.working.log("Sleep", "进入睡眠，开始离线重放。")
            self.append_episode("进入睡眠，开始离线重放。", plan="sleep",
                                importance=0.5, tags=["sleep"])
            return dur

    def tick_sleep(self, dt: float) -> bool:
        """推进睡眠计时。返回 True 表示**这一拍刚醒**。"""
        with self._lock:
            if not self.is_asleep:
                return False
            self._sleep_left -= max(0.0, float(dt))
            if self._sleep_left <= 0:
                self._sleep_left = 0.0
                return True
            return False

    def wake_up(self, homeo: Any = None) -> Dict[str, Any]:
        """醒来。按梦境强度分档决定记得多少。"""
        with self._lock:
            if not self.is_asleep:
                return {"woke": False, "memory": "", "dream": None}
            slept = max(0.0, SLEEP_MAX_SEC - float(self._sleep_left))
            self.total_sleep_sec += slept
            self.is_asleep = False
            self._sleep_left = 0.0
            self.sleep_end_at = 0.0

            d = self.dream
            if not d.content:
                memory = ""
            elif d.intensity > DREAM_CLEAR:
                memory = "记得很清楚：" + d.content
            elif d.intensity > DREAM_FAINT:
                memory = "隐约记得做了个梦……" + d.content[:24]
            else:
                memory = "好像做了梦，但一点也想不起来。"

            self.append_episode(
                "醒来。" + (memory or ""), plan="wake_up",
                importance=0.6, tags=["sleep", "wake"])
            self.working.log("Sleep", "醒来。" + (memory or ""))
            return {"woke": True, "memory": memory,
                    "dream": d.to_dict() if d.content else None}

    def update_dream(self, homeo: Any = None,
                     llm_fn: Optional[Callable[[str], str]] = None,
                     force: bool = False) -> Optional[Dream]:
        """睡眠中重生成梦境。

        llm_fn: 可选，签名 (prompt) -> str。给了就走 LLM（第1/2代的方式），
                否则用模板池（第3代的方式）。LLM 失败自动回落模板。
        """
        with self._lock:
            if not self.is_asleep:
                return None
            now = _now()
            if not force and (now - self._dream_at) < DREAM_UPDATE_SEC:
                return self.dream
            self._dream_at = now

            h = self._as_dict(homeo)
            sleep = h.get("sleep_pressure", 0.3)
            fatigue = h.get("muscle_fatigue", 0.1)
            arousal = h.get("adrenaline", 0.1) * 2.0
            glucose = h.get("glucose", 5.0)
            # 第3代的强度公式（含低血糖项，比第2代更合理）
            intensity = _clamp(
                0.25 + 0.35 * sleep + 0.20 * fatigue + 0.25 * arousal
                + 0.10 * max(0.0, 4.5 - glucose), 0.0, 1.0)

            recent = self.memory_summary(3, 24)
            content = ""
            source = "template"
            if llm_fn is not None:
                prompt = (
                    "你正在做梦。梦的内容要奇异、非逻辑、50 字以内，"
                    "不要解释、不要引号、不要以「梦」字开头。\n"
                    "最近记得的事：%s\n" % (recent or "（想不起来什么）"))
                try:
                    got = (llm_fn(prompt) or "").strip()
                    got = re.sub(r"^(梦境|梦|我梦见|梦里)[:：]?\s*", "", got)
                    got = got.strip().strip("「」\"'")
                    if got:
                        content, source = got[:200], "llm"
                except Exception:                            # noqa: BLE001
                    content = ""

            if not content:
                content = self.rng.choice(FALLBACK_DREAMS)
                if recent:
                    content = content.rstrip("。") + "。" + recent[:24]
                if self.rng.random() < 0.3:
                    content += self.rng.choice(FALLBACK_DREAM_TAIL)
                source = "template"

            self.dream = Dream(
                content=content, intensity=intensity,
                memory=content[:24] if intensity > DREAM_FAINT else "",
                lucid=intensity > DREAM_LUCID, source=source)
            self.dreams.append(self.dream)
            return self.dream

    @property
    def sleep_stage(self) -> str:
        """awake / nrem / rem（第3代有）。"""
        if not self.is_asleep:
            return "awake"
        return "rem" if self.dream.intensity > 0.6 else "nrem"

    def sleep_remaining(self) -> float:
        """还剩多少**模拟秒**。"""
        if not self.is_asleep:
            return 0.0
        return max(0.0, float(self._sleep_left))

    # ==================================================================
    # 输出
    # ==================================================================
    def stats(self) -> Dict[str, Any]:
        with self._lock:
            return {
                "episodic": len(self.episodic),
                "episodic_max": MAX_EPISODIC,
                "unspoken": len(self.unspoken),
                "unspoken_max": MAX_UNSPOKEN,
                "event_log": len(self.working.event_log),
                "pending": len(self.working.pending),
                "dialogue": len(self.working.dialogue),
                "dreams": len(self.dreams),
                "is_asleep": self.is_asleep,
                "sleep_stage": self.sleep_stage,
                "sleep_count": self.sleep_count,
                "load_factor": round(self.load_factor(), 4),
            }

    def to_dict(self, *, full: bool = False) -> Dict[str, Any]:
        """存档。默认只存最近部分，减小体积。"""
        with self._lock:
            eps = list(self.episodic) if full else list(self.episodic)[-80:]
            uns = list(self.unspoken) if full else list(self.unspoken)[-40:]
            logs = list(self.working.event_log)[-100:]
            dlg = list(self.working.dialogue)
            return {
                "episodic": [e.to_dict() for e in eps],
                "episodic_total": len(self.episodic),
                "unspoken": uns,
                "event_log": logs,
                "dialogue": dlg,
                "dream": self.dream.to_dict() if self.dream.content else None,
                "is_asleep": self.is_asleep,
                "sleep_end_at": round(self.sleep_end_at, 3),
                "sleep_left": round(self._sleep_left, 3),
                "sleep_count": self.sleep_count,
                "total_sleep_sec": round(self.total_sleep_sec, 1),
                "context": dict(self.working.context),
            }

    def load_dict(self, d: Any) -> bool:
        """读档。字段缺失或类型不对时**部分恢复**，不整体丢弃。"""
        if not isinstance(d, dict):
            return False
        with self._lock:
            eps = d.get("episodic")
            if isinstance(eps, list):
                good = [x for x in eps[-MAX_EPISODIC:]
                        if Episode.is_valid(x)]
                self.episodic.clear()
                for x in good:
                    self.episodic.append(Episode.from_dict(x))
            uns = d.get("unspoken")
            if isinstance(uns, list):
                self.unspoken.clear()
                for x in uns[-MAX_UNSPOKEN:]:
                    if isinstance(x, dict) and x.get("text"):
                        self.unspoken.append({
                            "t": float(x.get("t") or _now()),
                            "time_str": str(x.get("time_str") or ""),
                            "text": str(x["text"])[:300],
                            "reason": str(x.get("reason") or "")[:60]})
            logs = d.get("event_log")
            if isinstance(logs, list):
                self.working.event_log.clear()
                for x in logs[-MAX_EVENT_LOG:]:
                    if isinstance(x, dict):
                        self.working.event_log.append(x)
            dlg = d.get("dialogue")
            if isinstance(dlg, list):
                self.working.dialogue.clear()
                for x in dlg[-MAX_DIALOGUE:]:
                    if isinstance(x, dict):
                        self.working.dialogue.append(x)
            if isinstance(d.get("context"), dict):
                self.working.context = dict(d["context"])
            dm = d.get("dream")
            if isinstance(dm, dict):
                self.dream = Dream(
                    content=str(dm.get("content") or "")[:400],
                    intensity=float(dm.get("intensity") or 0.0),
                    memory=str(dm.get("memory") or "")[:200],
                    lucid=bool(dm.get("lucid")),
                    t=float(dm.get("t") or _now()),
                    source=str(dm.get("source") or "template"))
            self.is_asleep = bool(d.get("is_asleep"))
            try:
                self._sleep_left = float(d.get("sleep_left") or 0.0)
            except (TypeError, ValueError):
                self._sleep_left = 0.0
            try:
                self.sleep_end_at = float(d.get("sleep_end_at") or 0.0)
            except (TypeError, ValueError):
                self.sleep_end_at = 0.0
            self.sleep_count = int(d.get("sleep_count") or 0)
            self._recompute_strength()
            return True

    def clear(self) -> None:
        with self._lock:
            self.episodic.clear()
            self.unspoken.clear()
            self.dreams.clear()
            self.dream = Dream()
            self.working.clear()
            self.is_asleep = False
            self.sleep_end_at = 0.0

    def describe_for_llm(self, query: str = "") -> str:
        """给大模型看的记忆摘要。"""
        lines = []
        recalled = self.recall(query, 3) if query else self.recent_episodes(3)
        if recalled:
            lines.append("【刚想起】")
            for ep in recalled:
                lines.append("  · %s（%s）" % (ep.text[:60], ep.time_str))
        uns = self.recent_unspoken(3)
        if uns:
            lines.append("【没说出口的话】")
            for u in uns:
                lines.append("  · %s" % u["text"][:60])
        if self.is_asleep and self.dream.content:
            lines.append("【正在做梦】%s" % self.dream.content[:80])
        return "\n".join(lines)


__all__ = [
    "MemorySystem", "Episode", "Dream", "WorkingMemory",
    "MAX_EPISODIC", "MAX_UNSPOKEN", "MAX_EVENT_LOG", "MAX_PENDING",
    "SLEEP_THRESHOLD", "SLEEP_MIN_SEC", "SLEEP_MAX_SEC", "DREAM_UPDATE_SEC",
    "DREAM_CLEAR", "DREAM_FAINT", "DREAM_LUCID",
    "FALLBACK_DREAMS", "TAG_RULES",
]
