# -*- coding: utf-8 -*-
"""
Shiroko β —— 世界运行时

一个 `Runtime` 就是一个世界：**一个共享时钟 + 若干数字生命 + 一个 WebSocket 广播**。

为什么时钟要共享
----------------
旧版第3代让每个 `DigitalLife` 各自维护 `sim_clock`，于是两个角色可以一个在早上
一个在晚上 —— 而她们**同处一间房、共用一台机器**。本模块把时间与天气提到世界层，
个体的生理与位置仍归自己。

世界时间换算
------------
    1 模拟分钟 = 1 真实秒   （沿用第3代）
    于是 1 真实秒的 dt 对应 1/60 模拟分钟，一天 24 小时 = 24 真实分钟

恢复的旧版功能
--------------
· **存档原子写入**（第2代 `atomic_write`）—— 直接写盘时断电会留下半个文件
· **人类可读备份**（第1/2/3代都有）—— 逐字段文本，26 维内稳态逐行
· **备份数量上限清理**（第2代 `cleanup_backups(keep=50)`）
· **配置自动落盘**（第2代）—— 每 2 秒检查一次，内容变了才写
· **多角色快照**（第3代 `lives{id: snapshot}`）
· **LLMPool 六角色池**（第2代有、第3代砍成单客户端）—— 见 llm 分角色用法
· **QQ / OneBot 桥接**（第2代有、第3代全删）—— 见 core/onebot.py
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import pickle
import random
import shutil
import tempfile
import threading
import time
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import (
    Any, Awaitable, Callable, Dict, List, Optional, Sequence, Tuple,
)

from . import VERSION as _APP_VERSION
from . import geo, life as life_mod, llm as llm_mod, memory as mem_mod
from . import persona as persona_mod, snn as snn_mod

log = logging.getLogger("shiroko.runtime")

# ----------------------------------------------------------------------
# 节奏与容量（沿用旧版，标注来源代）
# ----------------------------------------------------------------------
TICK_INTERVAL_SEC = 1.0          # 主循环步长（第2/3代）
SAVE_INTERVAL_SEC = 30.0         # 自动存档（第2/3代）
BACKUP_INTERVAL_SEC = 300.0      # 自动备份（第2/3代）
CONFIG_SAVE_INTERVAL_SEC = 2.0   # 配置落盘（第2/3代）
DREAM_UPDATE_INTERVAL_SEC = 4.0  # 梦境重生成（第2/3代）
MAX_BACKUPS = 50                 # 备份保留数（第2/3代）
MAX_CHAT_HISTORY = 200           # 对话历史上限（第2/3代）

STATE_VERSION = 3

# 天气与光照（第3代）
WEATHER_LIGHT = {"sunny": 1.00, "cloudy": 0.75, "rainy": 0.55,
                 "snowy": 0.65, "foggy": 0.60, "windy": 0.85,
                 "indoor": 0.90}
WEATHER_TEMP = {"sunny": 24.0, "cloudy": 20.0, "rainy": 16.0,
                "snowy": 2.0, "foggy": 18.0, "windy": 21.0,
                "indoor": 18.0}
WEATHER_LABEL = {"sunny": "晴", "cloudy": "阴", "rainy": "雨",
                 "snowy": "雪", "foggy": "雾", "windy": "风",
                 "indoor": "室内"}
WEATHER_CHOICES = ("sunny", "cloudy", "rainy", "snowy", "foggy", "windy")

# ★ 神经元倍率的**下界**：必须是 >= 1 的整数。
#   前端那个「网络规模」滑块最左边是 1 KB，换算成倍率是 0.007 —— int() 之后就是 0，
#   而 DigitalLife 里是 `self.snn = SpikingNetwork(scale=...) if scale else None`，
#   于是她的脉冲网络直接变成 None：点阵没有发放率（一直不亮），
#   所有「调网络」的接口都回「没有可用的数字生命」（用户报的就是这两条）。
MIN_SNN_SCALE = 1
MAX_SNN_SCALE = 100000


def clamp_snn_scale(v: Any) -> int:
    """把任何来源的 snn_scale 夹到 [1, 100000] 的整数。"""
    try:
        n = int(float(v))
    except (TypeError, ValueError):
        n = MIN_SNN_SCALE
    return max(MIN_SNN_SCALE, min(MAX_SNN_SCALE, n))


def _now_iso() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def _stamp() -> str:
    """到微秒的时间戳。

    只用 `%Y%m%d_%H%M%S`（秒级）时，同一秒内触发两次备份会**互相覆盖** ——
    实测连做 58 次只剩 1 份文件。加上微秒后天然唯一。
    """
    return datetime.now().strftime("%Y%m%d_%H%M%S_%f")


def atomic_write(path: Path, data: bytes) -> bool:
    """原子写：先写临时文件再 replace。

    直接 `open(path,'wb')` 时如果断电/崩溃，会留下半个文件，
    读档就永远失败了 —— 旧版第2代特意加了这一步，这里保留。
    """
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        fd, tmp = tempfile.mkstemp(dir=str(path.parent),
                                   prefix=".tmp_" + path.name)
        try:
            with os.fdopen(fd, "wb") as f:
                f.write(data)
                f.flush()
                os.fsync(f.fileno())
            os.replace(tmp, path)
            return True
        except Exception:                                    # noqa: BLE001
            try:
                os.unlink(tmp)
            except OSError:
                pass
            raise
    except Exception as e:                                   # noqa: BLE001
        log.error("原子写入失败 %s：%s", path, e)
        return False


# ----------------------------------------------------------------------
@dataclass
class WorldClock:
    """共享的世界时间与天气。"""

    sim_hour: float = 8.0            # 0..24
    weather: str = "sunny"
    minutes_per_second: float = 1.0   # 1 真实秒 = 1 模拟分钟
    total_minutes: float = 0.0
    _since_weather_change: float = 0.0

    # ------------------------------------------------------------------
    def advance(self, real_seconds: float) -> None:
        sim_minutes = real_seconds * self.minutes_per_second
        self.total_minutes += sim_minutes
        self.sim_hour = (self.sim_hour + sim_minutes / 60.0) % 24.0
        self._since_weather_change += real_seconds

    @property
    def day_count(self) -> int:
        return int(self.total_minutes // (24 * 60))

    @property
    def time_of_day(self) -> str:
        h = self.sim_hour
        if h < 5.0 or h >= 20.0:
            return "night"
        if h < 11.0:
            return "morning"
        if h < 17.0:
            return "afternoon"
        return "evening"

    @property
    def time_label(self) -> str:
        return {"night": "夜里", "morning": "早上",
                "afternoon": "下午", "evening": "傍晚"}[self.time_of_day]

    @property
    def clock_text(self) -> str:
        h = int(self.sim_hour)
        m = int((self.sim_hour - h) * 60)
        return "%02d:%02d" % (h, m)

    # ------------------------------------------------------------------
    def lighting(self, scene_type: str = "classroom") -> float:
        """光照由时段与天气共同决定。

        室内场景不受天气影响（机房看不到外面下雨）。
        """
        h = self.sim_hour
        if h < 5.0:
            base = 0.15
        elif h < 11.0:
            base = 0.55 + (h - 5.0) * 0.09
        elif h < 17.0:
            base = 0.95
        else:
            base = max(0.10, 0.90 - (h - 17.0) * 0.16)
        if scene_type in ("indoor", "server_room"):
            return round(min(1.0, max(0.02, base * 0.92)), 3)
        return round(min(1.0, max(0.02,
                                  base * WEATHER_LIGHT.get(self.weather, 1.0))),
                     3)

    def ambient_temp(self, scene_type: str = "classroom") -> float:
        if scene_type in ("indoor", "server_room"):
            return 18.0
        return WEATHER_TEMP.get(self.weather, 22.0)

    def roll_weather(self, rng: random.Random,
                     every_seconds: float = 600.0) -> bool:
        """偶尔变天。返回是否真的变了。"""
        if self._since_weather_change < every_seconds:
            return False
        self._since_weather_change = 0.0
        new = rng.choice(WEATHER_CHOICES)
        if new == self.weather:
            return False
        self.weather = new
        return True

    def to_dict(self) -> Dict[str, Any]:
        return {
            "sim_hour": round(self.sim_hour, 4),
            "clock_text": self.clock_text,
            "time_of_day": self.time_of_day,
            "time_label": self.time_label,
            "weather": self.weather,
            "weather_label": WEATHER_LABEL.get(self.weather, self.weather),
            "day": self.day_count,
            "total_minutes": round(self.total_minutes, 2),
        }

    @classmethod
    def from_dict(cls, d: Any) -> "WorldClock":
        c = cls()
        if isinstance(d, dict):
            for k, cast in (("sim_hour", float), ("total_minutes", float),
                            ("minutes_per_second", float)):
                if isinstance(d.get(k), (int, float)):
                    setattr(c, k, cast(d[k]))
            if d.get("weather"):
                c.weather = str(d["weather"])
        return c


# ----------------------------------------------------------------------
def env_summary(env: "geo.Environment") -> Dict[str, Any]:
    """环境的"人话摘要" —— 生成结果要能让用户看见。

    用户报过"新建环境点生成以后看不见调用 API 生成的结果"：
    生成是真的发生了，但界面上只有一句 toast，生成出来的房间尺寸、
    地标、氛围全都没有露过面。这里统一给前端一份可读的摘要。
    """
    return {
        "scene_name": env.scene_name,
        "scene_type": env.scene_type,
        "description": env.description,
        "room": {k: round(float(v), 2) for k, v in env.room.items()},
        "size": {"width": round(env.width, 2),
                 "height": round(env.height, 2),
                 "area": round(env.area, 2)},
        "spawn": [round(env.spawn[0], 2), round(env.spawn[1], 2)],
        "landmarks": [{"label": lm.label or lm.name, "kind": lm.kind,
                       "pos": [round(lm.pos[0], 2), round(lm.pos[1], 2)]}
                      for lm in env.landmarks],
        "landmark_labels": [lm.label or lm.name for lm in env.landmarks],
        "ambient": dict(env.ambient),
        "sensory": {"sounds": list(env.sensory_sounds),
                    "smells": list(env.sensory_smells)},
        "source": env.source,
    }


class LLMPool:
    """按用途分角色的模型池。

    第2代有 6 个角色（`reasoner / memory / emotion / language / dream / env`），
    每个角色一个独立客户端；第3代砍成单个 `Translator`。
    现行 DeepSeek API 只有两个模型，但"**按用途选模型与参数**"这个思路值得保留：

        language  对话      温度高一点，让它自然
        dream     梦境      温度最高，要荒诞
        env       场景生成  温度最低 + JSON 模式，要结构化
        memory    记忆检索  低温
        reasoner  规划推理  开思考模式
        emotion   情绪评估  低温、短输出
    """

    ROLES: Dict[str, Dict[str, Any]] = {
        # ★ max_tokens 从 300 降到 140：聊天要短（用户反馈"一次说一大段"）。
            #   300 token ≈ 200 个汉字，额度会被模型用满。
            "language": {"temperature": 0.85, "max_tokens": 140,
                     "effort": "none"},
        "dream": {"temperature": 1.10, "max_tokens": 120, "effort": "none"},
        "env": {"temperature": 0.40, "max_tokens": 1200, "json": True,
                "effort": "none"},
        "memory": {"temperature": 0.30, "max_tokens": 200, "effort": "none"},
        "reasoner": {"temperature": 0.30, "max_tokens": 400,
                     "effort": "high"},
        "emotion": {"temperature": 0.50, "max_tokens": 80, "effort": "none"},
    }

    def __init__(self, api_key: str = "", base_url: str = "",
                 model: str = "", reasoner_model: str = "") -> None:
        self.clients: Dict[str, llm_mod.DeepSeekClient] = {}
        self.stats: Dict[str, Dict[str, int]] = {}
        self.reconfigure(api_key, base_url, model, reasoner_model)

    def reconfigure(self, api_key: str = "", base_url: str = "",
                    model: str = "", reasoner_model: str = "") -> bool:
        """重建 6 个客户端。

        两者都为空时必须各自落到**自己的**默认值 ——
        早期写成 `reasoner_model or model`，于是空参数下 reasoner 也拿到
        `deepseek-flash`，等于没有推理模型。
        """
        changed = False
        chat = (model or "").strip() or llm_mod.DEFAULT_MODEL
        reason = (reasoner_model or "").strip() or llm_mod.MODEL_PRO
        for role, cfg in self.ROLES.items():
            m = reason if role == "reasoner" else chat
            c = llm_mod.DeepSeekClient(
                api_key=api_key,
                base_url=base_url or llm_mod.DEFAULT_BASE_URL,
                model=m)
            old = self.clients.get(role)
            if old is None or old.api_key != c.api_key \
                    or old.base_url != c.base_url or old.model != c.model:
                changed = True
            self.clients[role] = c
            self.stats.setdefault(role, {"requests": 0, "errors": 0})
        return changed

    @property
    def enabled(self) -> bool:
        return any(c.enabled for c in self.clients.values())

    def get(self, role: str) -> llm_mod.DeepSeekClient:
        return self.clients.get(role) or self.clients["language"]

    def call(self, role: str, messages: List[Dict[str, Any]],
             **overrides) -> llm_mod.ChatResult:
        """按角色调用。参数可被 overrides 覆盖。"""
        cfg = dict(self.ROLES.get(role, self.ROLES["language"]))
        json_mode = cfg.pop("json", False)
        cfg.update(overrides)
        st = self.stats.setdefault(role, {"requests": 0, "errors": 0})
        st["requests"] += 1
        try:
            client = self.get(role)
            if json_mode:
                d = client.chat_json(messages, **cfg)
                return llm_mod.ChatResult(text=json.dumps(d, ensure_ascii=False),
                                          model=client.model)
            return client.chat(messages, **cfg)
        except Exception:                                    # noqa: BLE001
            st["errors"] += 1
            raise

    def to_client(self) -> Dict[str, Any]:
        return {
            "enabled": self.enabled,
            "roles": {r: {"model": c.model, "base_url": c.base_url,
                          **self.stats.get(r, {})}
                      for r, c in self.clients.items()},
        }


# ----------------------------------------------------------------------
class Runtime:
    """一个世界。"""

    def __init__(self, *, config_file: Path, state_file: Path,
                 backup_dir: Path, log_dir: Optional[Path] = None,
                 seed: int = 20261002) -> None:
        self.config_file = Path(config_file)
        self.state_file = Path(state_file)
        self.backup_dir = Path(backup_dir)
        self.log_dir = Path(log_dir) if log_dir else self.backup_dir.parent / "logs"

        self.rng = random.Random(seed)
        self.lock = threading.RLock()
        self.clock = WorldClock()

        # 世界内容
        self.lives: Dict[str, life_mod.DigitalLife] = {}
        self.default_life: Optional[life_mod.DigitalLife] = None
        self.config: Dict[str, Any] = {}

        # 外部接入
        self.llm_pool = LLMPool()
        self.bridge = "internal"          # internal | qq
        self.qq: Dict[str, Any] = {"ws_url": "ws://127.0.0.1:3001",
                                   "group_id": "", "access_token": ""}
        self.onebot: Optional[Any] = None   # core.onebot.OneBotAdapter

        # 运行状态
        self.started_at = time.time()
        self.tick_count = 0
        self._stop = threading.Event()
        self._tasks: List[asyncio.Task] = []
        self._config_dirty = False
        self._last_save = 0.0
        self._last_backup = 0.0
        self._last_dream = 0.0
        self._inbox: List[Dict[str, Any]] = []      # 外部进来的消息
        self._broadcast: Optional[Callable[[Dict[str, Any]], Awaitable[None]]] = None
        self._loop: Optional[asyncio.AbstractEventLoop] = None

    # ==================================================================
    # 配置
    # ==================================================================
    DEFAULT_CONFIG: Dict[str, Any] = {
        "initialized": False,
        "api_key": "",
        "api_base": llm_mod.DEFAULT_BASE_URL,
        "chat_model": llm_mod.DEFAULT_MODEL,
        "reasoner_model": llm_mod.MODEL_PRO,
        "tech_path": "hybrid_snn",
        "free_energy": True,
        "homeostasis_enabled": True,
        "character_name": persona_mod.KAKA_NAME,
        "character_prompt": "",
        "avatar": "",
        "environment_description": "",
        "environment_spec": None,
        "bridge": "internal",
        "qq": {"ws_url": "ws://127.0.0.1:3001", "group_id": "",
               "access_token": ""},
        "snn_scale": 1,
        "user_name": "",
    }

    def load_config(self) -> Dict[str, Any]:
        """读配置。文件损坏时用默认值，不崩。"""
        cfg = dict(self.DEFAULT_CONFIG)
        cfg["qq"] = dict(self.DEFAULT_CONFIG["qq"])
        if self.config_file.exists():
            try:
                d = json.loads(self.config_file.read_text(encoding="utf-8"))
                if isinstance(d, dict):
                    cfg.update(d)
                    if isinstance(d.get("qq"), dict):
                        cfg["qq"].update(d["qq"])
            except (OSError, ValueError) as e:
                log.warning("配置文件读取失败，使用默认值：%s", e)
        with self.lock:
            self.config = cfg
            self.bridge = str(cfg.get("bridge") or "internal")
            self.qq = dict(cfg.get("qq") or {})
            self.llm_pool.reconfigure(
                str(cfg.get("api_key") or ""),
                str(cfg.get("api_base") or llm_mod.DEFAULT_BASE_URL),
                str(cfg.get("chat_model") or llm_mod.DEFAULT_MODEL),
                str(cfg.get("reasoner_model") or llm_mod.MODEL_PRO))
        return cfg

    def save_config(self, force: bool = False) -> bool:
        with self.lock:
            if not (force or self._config_dirty):
                return False
            data = json.dumps(self.config, ensure_ascii=False, indent=1)
            self._config_dirty = False
        ok = atomic_write(self.config_file, data.encode("utf-8"))
        if ok:
            log.debug("配置已落盘")
        return ok

    def update_config(self, patch: Dict[str, Any]) -> Dict[str, Any]:
        """改配置。返回实际生效的完整配置。

        `api_key` 传空字符串表示**不改**（避免前端每次保存都把 Key 清掉）；
        要清除请传 `"api_key": null`。
        """
        if not isinstance(patch, dict):
            return dict(self.config)
        with self.lock:
            cfg = self.config
            for k, v in patch.items():
                if k == "api_key":
                    if v is None:
                        cfg["api_key"] = ""
                    elif str(v).strip():
                        cfg["api_key"] = str(v).strip()
                    continue
                if k == "qq" and isinstance(v, dict):
                    cfg["qq"] = {**(cfg.get("qq") or {}), **v}
                    self.qq = dict(cfg["qq"])
                    continue
                if k in ("snn_scale",):
                    # ★ 夹到 >=1：0 会让脉冲网络变成 None（见 clamp_snn_scale 的说明）
                    new_scale = clamp_snn_scale(v)
                    if new_scale != int(cfg.get("snn_scale") or 1):
                        cfg[k] = new_scale
                        # 规模变了要**重建**每个生命的网络，否则帧里的脑区还是旧的
                        for lf0 in self.lives.values():
                            try:
                                lf0.snn = snn_mod.SpikingNetwork(
                                    cfg=lf0.snn.cfg if lf0.snn else None,
                                    scale=new_scale)
                                lf0.last_rates = {}
                            except Exception as _e:      # noqa: BLE001
                                log.warning("重建脉冲网络失败：%s", _e)
                    else:
                        cfg[k] = new_scale
                    continue
                if k in ("free_energy", "homeostasis_enabled", "initialized"):
                    cfg[k] = bool(v)
                    continue
                if k in ("avatar", "avatars", "avatarChar"):
                    # ★ 头像是**角色**的属性，不是全局开关。
                    #   旧实现只有一个 config.avatar：给渐进酱换过头像之后，
                    #   白子（以及任何新角色）也顶着她那张脸 ——
                    #   这正是用户报的"第一个智能体头像怎么是渐进酱"。
                    #   现在按 charId 存进 avatars{}，config.avatar 保留为
                    #   老配置的兼容字段（只有第一个角色会继承它）。
                    continue
                if k == "charId":
                    continue
                cfg[k] = v
            if any(k in patch for k in ("avatar", "avatars", "avatarChar")):
                avatars = dict(cfg.get("avatars") or {})
                cid = str(patch.get("avatarChar")
                          or patch.get("charId") or "").strip()
                if isinstance(patch.get("avatars"), dict):
                    for cid2, url2 in patch["avatars"].items():
                        cid2 = str(cid2).strip()
                        if not cid2:
                            continue
                        if url2 is None or str(url2).strip() == "":
                            avatars.pop(cid2, None)
                        else:
                            avatars[cid2] = str(url2)
                url = str(patch.get("avatar") or "").strip()
                if url:
                    if cid:
                        avatars[cid] = url
                    cfg["avatar"] = url          # 兼容：老读取方只认这个
                elif cid:
                    avatars.pop(cid, None)
                cfg["avatars"] = avatars
            self.bridge = str(cfg.get("bridge") or "internal")
            self._config_dirty = True

            changed = self.llm_pool.reconfigure(
                str(cfg.get("api_key") or ""),
                str(cfg.get("api_base") or llm_mod.DEFAULT_BASE_URL),
                str(cfg.get("chat_model") or llm_mod.DEFAULT_MODEL),
                str(cfg.get("reasoner_model") or llm_mod.MODEL_PRO))
            cfg["snn_scale"] = clamp_snn_scale(cfg.get("snn_scale"))
            for lf in self.lives.values():
                lf.set_policy(str(cfg.get("tech_path") or "hybrid_snn"))
                lf.set_homeostasis(bool(cfg.get("homeostasis_enabled", True)))
        if changed:
            log.info("大模型配置已更新（%s）", self.llm_pool.get("language").model)
        self.save_config()
        return self.to_client_config()

    def to_client_config(self) -> Dict[str, Any]:
        """给前端的配置（Key 打码）。"""
        with self.lock:
            cfg = dict(self.config)
            key = str(cfg.get("api_key") or "")
            cfg["api_key"] = ("***" if key else "")
            cfg["api_key_set"] = bool(key)
            cfg["avatars"] = dict(cfg.get("avatars") or {})
            cfg["api_key_hint"] = ("%s…%s" % (key[:6], key[-4:])) if len(key) > 12 \
                else ("已设置" if key else "")
            cfg["llm"] = self.llm_pool.to_client()
            # ★ 这里原来是 `snn_mod.BASE_NEURONS`（3328），注释还写着"由 server
            #   覆盖" —— 而 server 从来没覆盖过。于是侧栏页脚与"关于"页显示的
            #   版本号是"Shiroko β v3328"。版本号就该是版本号。
            cfg["version"] = _APP_VERSION
            cfg["snn_scale"] = int(cfg.get("snn_scale") or 1)
            return cfg

    # ==================================================================
    # 生命
    # ==================================================================
    def create_life(self, *, name: str = "", env: Optional[geo.Environment] = None,
                    char_id: str = "", seed: Optional[int] = None
                    ) -> life_mod.DigitalLife:
        """创建一个数字生命并登记进世界。

        `char_id` 只表示"**指定**这个 id"。空串等于没指定，走自动命名。

        ★ 为什么自动命名还要查重：早期实现里 HTTP 层把缺失的 charId
        回落成空串，`create_life` 再把它算成 `"default"`，于是**新建一个
        角色会把默认角色顶掉**（实测：建完"测试角色"，白子就没了）。
        这里对已占用的 id 自动让位。

        另一个要点：`default` 这个名字**只留给第一个角色**。
        否则用户新建命名角色（"渐进酱 2 号"之类）会拿到 `default-2`，
        看起来像系统角色，而真正占着 `default` 的是别人。
        """
        with self.lock:
            nm = name or str(self.config.get("character_name")
                             or persona_mod.SHIROKO_NAME)
            env = env or self._build_env_from_config()
            cid = str(char_id or "").strip()
            if not cid:
                # 显式命名的新角色**不用 default 这个名字**
                named = bool(str(name or "").strip())
                if named:
                    cid = ("kaka" if ("渐进" in nm or "卡" in nm)
                           else "shiroko")
                else:
                    cid = ("kaka" if ("渐进" in nm or "卡" in nm)
                           else "default")
            if cid in self.lives:
                base = cid
                n = 2
                while ("%s-%d" % (base, n)) in self.lives:
                    n += 1
                cid = "%s-%d" % (base, n)
                log.info("charId %r 已被占用，改用 %r", base, cid)
            lf = life_mod.DigitalLife(
                name=nm, env=env, life_id=cid,
                seed=int(seed if seed is not None else (20261002
                                                        + len(self.lives) * 977)),
                scale=clamp_snn_scale(self.config.get("snn_scale")))
            lf.set_policy(str(self.config.get("tech_path") or "hybrid_snn"))
            lf.set_homeostasis(bool(self.config.get("homeostasis_enabled", True)))
            prompt = str(self.config.get("character_prompt") or "")
            if prompt:
                lf.persona.system_prompt = prompt

            self.lives[cid] = lf
            self.default_life = self.default_life or lf
            self._wire_cross_character()
            log.info("数字生命已创建：%s（id=%s，SNN %d 神经元 / %d 突触）",
                     nm, cid, lf.snn.neurons if lf.snn else 0,
                     lf.snn.synapses if lf.snn else 0)
            return lf

    def _build_env_from_config(self) -> geo.Environment:
        """按配置里的环境描述建环境。没有就用**默认环境**。

        默认环境是**服务器机房**（`geo.DEFAULT_ENVIRONMENT`），
        与旧版第5代前端的初始环境一致。早期这里回落到教室，
        于是"默认环境是机房、小地图画的却是教室"。
        """
        spec = self.config.get("environment_spec")
        if isinstance(spec, dict) and spec:
            try:
                return geo.build_from_spec(spec, source=str(spec.get("source")
                                                            or "user"))
            except Exception as e:                               # noqa: BLE001
                log.warning("环境描述无法解析，回落默认环境：%s", e)
        return geo.default_environment()

    def _wire_cross_character(self) -> None:
        """让每个角色都能读到对方的生理状态（跨角色感知）。"""
        for a in self.lives.values():
            others = [b for b in self.lives.values() if b is not a]
            a.set_other(others[0].homeo.state if others else None)

    def life_for(self, char_id: str = "", name: str = ""
                 ) -> Optional[life_mod.DigitalLife]:
        with self.lock:
            if char_id and char_id in self.lives:
                return self.lives[char_id]
            if name:
                for lf in self.lives.values():
                    if lf.name == name:
                        return lf
            return self.default_life

    def remove_life(self, char_id: str) -> bool:
        with self.lock:
            lf = self.lives.pop(char_id, None)
            if lf is None:
                return False
            if self.default_life is lf:
                self.default_life = next(iter(self.lives.values()), None)
            self._wire_cross_character()
            return True

    # ==================================================================
    # 主循环
    # ==================================================================
    async def tick_once(self, dt: float = TICK_INTERVAL_SEC) -> Dict[str, Any]:
        """推进世界一次。"""
        self.clock.advance(dt)
        if self.clock.roll_weather(self.rng):
            log.info("变天：%s", WEATHER_LABEL.get(self.clock.weather))
            for lf in self.lives.values():
                lf.memory.working.log("World", "天气变成%s"
                                      % WEATHER_LABEL.get(self.clock.weather))
                lf.memory.append_episode(
                    "外面%s了。" % WEATHER_LABEL.get(self.clock.weather),
                    plan="look_window", importance=0.4, tags=["weather"])

        # 把世界时间/天气写进每个生命的感官环境
        for lf in self.lives.values():
            amb = lf.env.ambient
            amb["weather"] = self.clock.weather
            amb["lighting"] = self.clock.lighting(lf.env.scene_type)
            if lf.env.scene_type not in ("indoor", "server_room"):
                amb["temperature"] = self.clock.ambient_temp(lf.env.scene_type)

        # 外部进来的消息（QQ 桥接等）分发给对应生命
        inbox, self._inbox = self._inbox, []
        for msg in inbox:
            lf = self.life_for(str(msg.get("charId") or ""),
                               str(msg.get("name") or ""))
            if lf is not None:
                lf.memory.working.push_message(
                    str(msg.get("from") or "用户"), str(msg.get("text") or ""))

        # 推进每个生命
        frames: Dict[str, Any] = {}
        for cid, lf in self.lives.items():
            lf.tick("", dt=dt)
            frames[cid] = self.frame_for(life=lf) or {}

        self.tick_count += 1
        now = time.time()

        # 自动存档 / 备份 / 配置落盘
        if now - self._last_save >= SAVE_INTERVAL_SEC:
            self._last_save = now
            self.save()
        if now - self._last_backup >= BACKUP_INTERVAL_SEC:
            self._last_backup = now
            self.backup()
        self.save_config()

        return {"clock": self.clock.to_dict(), "frames": frames,
                "tick": self.tick_count}

    def push_message(self, text: str, *, char_id: str = "", name: str = "",
                     sender: str = "用户", reply: bool = True
                     ) -> Dict[str, Any]:
        """从外部塞一句话进来，并同步拿到她的回复。

        这是**同步**接口（给 HTTP / QQ 用）；WebSocket 走 `push_message_async`。
        """
        lf = self.life_for(char_id, name)
        if lf is None:
            return {"ok": False, "error": "没有可用的数字生命"}
        rep = lf.reply(text)
        out = {"ok": True, "charId": lf.char_id, "who": lf.persona.who,
               "name": lf.name, **rep.to_dict()}
        if self.bridge == "qq" and self.onebot is not None and not rep.silent:
            self._send_to_qq(rep.text, lf.name)
        return out

    def _send_to_qq(self, text: str, name: str = "") -> None:
        ob = self.onebot
        if ob is None:
            return
        try:
            ob.send(text)
        except Exception as e:                                   # noqa: BLE001
            log.warning("QQ 发送失败：%s", e)

    async def run(self) -> None:
        """主循环（在 asyncio 里跑）。"""
        self._loop = asyncio.get_running_loop()
        log.info("世界开始运转（1 模拟分钟 = 1 真实秒）")
        # 主动发言的广播游标：记录每个角色上次推到哪一句，
        # 避免每 tick 把整段历史重发一遍。
        said_cursor: Dict[str, int] = {}
        while not self._stop.is_set():
            t0 = time.time()
            try:
                payload = await self.tick_once(TICK_INTERVAL_SEC)
                if self._broadcast is not None:
                    for cid, frame in payload["frames"].items():
                        lf = self.lives.get(cid)
                        await self._broadcast({
                            "type": "frame", "charId": cid,
                            "name": lf.name if lf else cid,
                            "data": frame})
                    # ★ 她自己开口说的话要推给前端。
                    #   只广播 frame 的话，前端永远看不到主动发言 ——
                    #   后端记了、界面不显示，等于没做。
                    for cid, lf in self.lives.items():
                        try:
                            spoken = lf.recent_spoken(200)
                        except Exception:                        # noqa: BLE001
                            continue
                        start = said_cursor.get(cid, 0)
                        if len(spoken) < start:                  # 被裁剪过
                            start = 0
                        for item in spoken[start:]:
                            await self._broadcast({
                                "type": "say", "charId": cid,
                                "name": lf.name,
                                "data": dict(item, charId=cid,
                                             proactive=True)})
                        said_cursor[cid] = len(spoken)
                    await self._broadcast({"type": "clock",
                                           "data": payload["clock"]})
            except Exception:                                    # noqa: BLE001
                log.error("tick 异常：%s", __import__("traceback")
                          .format_exc(limit=4))
            await asyncio.sleep(max(0.05, TICK_INTERVAL_SEC
                                    - (time.time() - t0)))

    def start_background(self, loop: asyncio.AbstractEventLoop) -> asyncio.Task:
        self._loop = loop
        t = loop.create_task(self.run(), name="shiroko-world")
        self._tasks.append(t)
        return t

    async def shutdown(self) -> None:
        log.info("正在关闭世界…")
        self._stop.set()
        for t in self._tasks:
            t.cancel()
        for t in self._tasks:
            try:
                await t
            except (asyncio.CancelledError, Exception):          # noqa: BLE001
                pass
        self._tasks.clear()
        self.save()
        self.backup()
        if self.onebot is not None:
            try:
                await self.onebot.stop()
            except Exception:                                    # noqa: BLE001
                pass
        log.info("世界已停止")

    def stop(self) -> None:
        self._stop.set()

    # ==================================================================
    # 存档 / 备份
    # ==================================================================
    def snapshot(self) -> Dict[str, Any]:
        with self.lock:
            return {
                "version": STATE_VERSION,
                "app": "ShirokoBeta",
                "saved_at": time.time(),
                "saved_at_str": _now_iso(),
                "clock": self.clock.to_dict(),
                "tick": self.tick_count,
                "default": self.default_life.char_id if self.default_life
                else None,
                "lives": {cid: lf.snapshot() for cid, lf in self.lives.items()},
            }

    def save(self) -> bool:
        """存档（原子写 + pickle）。"""
        snap = self.snapshot()
        try:
            data = pickle.dumps(snap, protocol=pickle.HIGHEST_PROTOCOL)
        except Exception as e:                                   # noqa: BLE001
            log.error("序列化失败：%s", e)
            return False
        ok = atomic_write(self.state_file, data)
        if ok:
            log.info("已存档（%d 个生命，%.1f KB）",
                     len(self.lives), len(data) / 1024.0)
        return ok

    def load(self) -> bool:
        """读档。损坏或版本不符时**部分恢复**，不整体丢弃。"""
        if not self.state_file.exists():
            return False
        try:
            raw = self.state_file.read_bytes()
        except OSError as e:
            log.warning("存档读取失败：%s", e)
            return False
        snap: Optional[Dict[str, Any]] = None
        try:
            snap = pickle.loads(raw)
        except Exception as e:                                   # noqa: BLE001
            log.warning("存档反序列化失败（%s），尝试 JSON 兜底", e)
            try:
                snap = json.loads(raw.decode("utf-8", "replace"))
            except Exception:                                    # noqa: BLE001
                log.error("存档无法恢复，将以全新状态启动")
                return False
        if not isinstance(snap, dict):
            return False

        with self.lock:
            self.clock = WorldClock.from_dict(snap.get("clock"))
            self.tick_count = int(snap.get("tick") or 0)
            lives = snap.get("lives")
            if not isinstance(lives, dict):
                log.warning("存档里没有 lives 段")
                return False
            restored = 0
            for cid, ld in lives.items():
                if not isinstance(ld, dict):
                    continue
                lf = life_mod.DigitalLife(scale=0, life_id=str(cid))
                try:
                    # ★ 字典键是权威 id。旧存档可能没写 life_id，
                    #   甚至写了与键不一致的值 —— 一律以键为准。
                    box = dict(ld)
                    box["life_id"] = str(cid)
                    if lf.restore(box):
                        self.lives[str(cid)] = lf
                        restored += 1
                except Exception as e:                           # noqa: BLE001
                    log.warning("生命 %s 恢复失败：%s", cid, e)
            self.default_life = self.lives.get(str(snap.get("default") or "")) \
                or next(iter(self.lives.values()), None)
            self._wire_cross_character()
        log.info("存档已读取：%d 个生命，第 %d tick", restored, self.tick_count)
        return restored > 0

    def _format_backup(self) -> str:
        """人类可读的备份文本。

        26 维内稳态逐行 `%-22s %10.4f`（第3代版式），加上记忆、梦境、自由能。
        """
        L: List[str] = []
        L.append("=" * 68)
        L.append("Shiroko β —— 状态备份")
        L.append("=" * 68)
        L.append("保存时间：%s" % _now_iso())
        L.append("世界时间：%s（%s · %s · 第 %d 天）"
                 % (self.clock.clock_text, self.clock.time_label,
                    WEATHER_LABEL.get(self.clock.weather), self.clock.day_count))
        L.append("累计 tick：%d" % self.tick_count)
        L.append("")

        for cid, lf in self.lives.items():
            L.append("-" * 68)
            L.append("【%s】（id=%s）" % (lf.name, cid))
            L.append("-" * 68)
            L.append("位置：(%.2f, %.2f)  姿态：%s  计划：%s"
                     % (lf.pos[0], lf.pos[1], lf.state, lf.plan))
            L.append("情绪：%s（效价 %+.3f，唤醒 %.3f）"
                     % (lf.homeo.mood_label, lf.valence, lf.arousal))
            fepd = lf.fep.to_dict()
            L.append("自由能：F=%.4f ΔF=%+.4f 惊奇=%.4f 复杂度=%.4f 准确度=%.4f"
                     % (fepd["free_energy"], fepd["fe_delta"],
                        fepd["surprise"], fepd["complexity"],
                        fepd["accuracy"]))
            L.append("睡眠：%s（阶段 %s，累计 %d 次）"
                     % ("是" if lf.memory.is_asleep else "否",
                        lf.memory.sleep_stage, lf.memory.sleep_count))
            L.append("")

            L.append("── 26 维内稳态 ──")
            from . import homeo as _h
            for f in _h.HOMEOSTATIC_FIELDS:
                L.append("  %-22s %10.4f  %s"
                         % (f.label, getattr(lf.homeo.state, f.key),
                            f.unit))
            L.append("")

            L.append("── 脑区发放率 ──")
            for k in snn_mod.REGION_KEYS:
                L.append("  %-14s %.4f" % (snn_mod.REGION_MAP[k].label,
                                           lf.last_rates.get(k, 0.0)))
            L.append("")

            eps = lf.memory.recent_episodes(20)
            L.append("── 情景记忆（最近 %d / 共 %d）──"
                     % (len(eps), len(lf.memory.episodic)))
            for e in eps:
                L.append("  [%s] %s" % (e.time_str, e.text[:70]))
            L.append("")

            uns = lf.memory.recent_unspoken(20)
            L.append("── 没说出口的话（最近 %d / 共 %d）──"
                     % (len(uns), len(lf.memory.unspoken)))
            for u in uns:
                L.append("  [%s] %s" % (u.get("time_str", ""),
                                        u.get("text", "")[:70]))
            L.append("")

            d = lf.memory.dream
            L.append("── 梦境 ──")
            if d.content:
                L.append("  内容：%s" % d.content[:200])
                L.append("  强度：%.3f  清醒梦：%s  来源：%s"
                         % (d.intensity, "是" if d.lucid else "否", d.source))
                L.append("  醒来记得：%s" % d.memory)
            else:
                L.append("  （还没有做过梦）")
            L.append("")

        L.append("=" * 68)
        return "\n".join(L)

    def backup(self) -> Optional[Path]:
        """写一份人类可读备份，并清理过多的旧备份。"""
        try:
            self.backup_dir.mkdir(parents=True, exist_ok=True)
            p = self.backup_dir / ("backup_%s.txt" % _stamp())
            if p.exists():                       # 极端情况下仍撞名就加后缀
                p = self.backup_dir / ("backup_%s_%d.txt"
                                       % (_stamp(), self.rng.randint(100, 999)))
            p.write_text(self._format_backup(), encoding="utf-8")
            self.cleanup_backups()
            log.info("已备份：%s", p.name)
            return p
        except Exception as e:                                   # noqa: BLE001
            log.error("备份失败：%s", e)
            return None

    def cleanup_backups(self, keep: int = MAX_BACKUPS) -> int:
        """只保留最近 keep 份（第2代 `cleanup_backups`）。"""
        try:
            files = sorted(self.backup_dir.glob("backup_*.txt"))
        except OSError:
            return 0
        excess = files[:-keep] if keep > 0 else files
        n = 0
        for f in excess:
            try:
                f.unlink()
                n += 1
            except OSError:
                pass
        if n:
            log.info("清理了 %d 份旧备份", n)
        return n

    def list_backups(self, limit: int = MAX_BACKUPS) -> List[Dict[str, Any]]:
        try:
            files = sorted(self.backup_dir.glob("backup_*.txt"), reverse=True)
        except OSError:
            return []
        out = []
        for f in files[:limit]:
            try:
                st = f.stat()
                out.append({"name": f.name, "path": str(f),
                            "size_kb": round(st.st_size / 1024.0, 1),
                            "time": datetime.fromtimestamp(st.st_mtime)
                            .strftime("%Y-%m-%d %H:%M:%S")})
            except OSError:
                continue
        return out

    def reset_character(self, char_id: str = "") -> bool:
        """重启某个角色：清运行态、保留记忆（第3代 `#set-char-restart`）。

        注意这里**不用 `life_for`** —— 它对未知 id 会回落到默认生命，
        于是 `reset_character("不存在的id")` 会悄悄重置默认角色并返回 True。
        重置是可破坏操作，未知 id 必须明确失败。
        """
        with self.lock:
            if char_id:
                lf = self.lives.get(char_id)
            else:
                lf = self.default_life
            if lf is None:
                return False
            lf.homeo = type(lf.homeo)(seed=self.rng.randint(1, 10 ** 6))
            lf.fep.reset()
            lf.tick_count = 0
            lf.pos = lf.env.spawn
            lf.state, lf.plan = "standing", "relax"
            lf.memory.working.log("System", "角色已重启（记忆保留）")
            return True

    # ==================================================================
    # 对外状态
    # ==================================================================
    def health(self) -> Dict[str, Any]:
        with self.lock:
            return {
                "ok": True,
                "version": _APP_VERSION,
                "uptime": round(time.time() - self.started_at, 1),
                "tick": self.tick_count,
                "initialized": bool(self.lives),
                "lives": {cid: lf.name for cid, lf in self.lives.items()},
                "llm": {"enabled": self.llm_pool.enabled,
                        "model": self.llm_pool.get("language").model},
                "bridge": self.bridge,
                "clock": self.clock.to_dict(),
            }

    def frame_for(self, char_id: str = "",
                  life: Optional[life_mod.DigitalLife] = None
                  ) -> Optional[Dict[str, Any]]:
        """给前端的完整帧 = 个体帧 + 世界边车。

        ★ 必须走这里，不要直接调 `life.frame()`。
        世界时间、天气属于 Runtime 而不属于个体，早期只在 tick 循环里
        往副本上补，于是前端拿到的是 `f.clock === undefined` ——
        界面上显示"世界时间 undefined · undefined"。
        """
        lf = life if life is not None else self.life_for(char_id)
        if lf is None:
            return None
        f = lf.frame()
        f["clock"] = self.clock.to_dict()
        f["weather"] = self.clock.weather
        f["weather_label"] = WEATHER_LABEL.get(self.clock.weather,
                                               self.clock.weather)
        f["day"] = self.clock.day_count
        return f

    def state_for(self, char_id: str = "") -> Optional[Dict[str, Any]]:
        return self.frame_for(char_id)

    def regions_payload(self) -> Dict[str, Any]:
        lf = self.default_life
        if lf is None or lf.snn is None:
            return {"ok": True, "regions": [
                {"key": r.key, "label": r.label, "neurons": r.neurons,
                 "inputs": r.inputs, "synapses": r.synapses,
                 "role": r.role, "rate": 0.0} for r in snn_mod.REGION_SPECS],
                "totals": {"neurons": snn_mod.BASE_NEURONS,
                           "synapses": snn_mod.BASE_SYNAPSES,
                           "synapses_allocated": snn_mod.ALLOCATED_SYNAPSES,
                           "scale": int(self.config.get("snn_scale") or 1)}}
        d = lf.snn.to_client()
        d["ok"] = True
        d["totals"]["scale"] = int(self.config.get("snn_scale") or 1)
        return d

    # ==================================================================
    # 网络规模（旧版用一个 0–100 滑块驱动 7 个参数）
    # ==================================================================
    def snn_payload(self, char_id: str = "") -> Dict[str, Any]:
        """网络规模与参数。

        ★ 一律读**网络自身的** `scale` / `neurons` / `synapses`，
        不读配置里的 `snn_scale`。两者理论上同步，但读真实值才不会
        出现"改完参数、接口报的还是旧规模"这种自相矛盾。
        """
        lf = self.life_for(char_id)
        net = lf.snn if lf else None
        cfg = net.cfg if net else snn_mod.SNNConfig()
        scale = int(net.scale) if net else int(self.config.get("snn_scale") or 1)
        neurons = net.neurons if net else snn_mod.BASE_NEURONS * scale
        synapses = net.synapses if net else snn_mod.BASE_SYNAPSES * scale
        allocated = (net.allocated_bytes if net
                     else snn_mod.ALLOCATED_SYNAPSES * scale)
        return {
            "ok": True,
            "quality": snn_mod.config_to_quality(cfg, scale),
            "scale": scale,
            "neurons": neurons,
            "synapses": synapses,
            "synapses_allocated": allocated,
            "memory_mb": round(snn_mod.estimate_memory_mb(
                cfg, neuron_scale=neurons / float(snn_mod.BASE_NEURONS)), 2),
            "params": {
                "neuron_scale": round(neurons / float(snn_mod.BASE_NEURONS), 2),
                "weight_slots": cfg.weight_slots,
                "threshold": cfg.threshold,
                "tau": cfg.tau,
                "weight_scale": cfg.weight_scale,
                "refractory": cfg.refractory,
                "dt": cfg.dt,
            },
            "presets": {k: {"quality": v["quality"], "label": v["label"]}
                        for k, v in snn_mod.PRESETS.items()},
            "ranges": {k: list(v) for k, v in snn_mod.QUALITY_RANGES.items()},
        }

    def apply_quality(self, quality: Any = None, char_id: str = "",
                      params: Optional[Dict[str, Any]] = None,
                      rebuild: bool = True) -> Dict[str, Any]:
        """按综合质量（0–100）或直接给参数来改 SNN。

        · `neuron_scale` 会**重建网络**（神经元数量变了），开销约 0.2–0.5 秒，
          会重置膜电位与权重 —— 但**不丢记忆**（记忆不在 SNN 里）。
        · 其余参数**热改**，下一步生效。
        """
        lf = self.life_for(char_id)
        if lf is None:
            # ★ 这两种情况**不一样**，别都报「没有可用的数字生命」——
            #   用户看到那句话时，她其实好好地在跑，只是网络被规模 0 弄没了。
            return {"ok": False, "error": "还没有数字生命 —— 先在欢迎页唤醒一个"}
        if lf.snn is None:
            # 自愈：规模曾经是 0（滑块拖到最左边）→ 按合法下界重建一个。
            _scale = clamp_snn_scale(self.config.get("snn_scale"))
            self.config["snn_scale"] = _scale
            lf.snn = snn_mod.SpikingNetwork(scale=_scale)
            self._config_dirty = True
            log.info("脉冲网络缺失（规模曾为 0），已按 %s× 重建", _scale)
        try:
            q = int(quality) if quality is not None else None
        except (TypeError, ValueError):
            q = None
        if q is not None:
            q = max(0, min(100, q))
            want = snn_mod.quality_to_config(q)
        elif isinstance(params, dict):
            want = dict(params)
            q = None
        else:
            return {"ok": False, "error": "需要 quality 或 params"}

        with self.lock:
            cfg = lf.snn.cfg
            # --- 热改 ---
            for k in ("threshold", "tau", "weight_scale", "refractory",
                      "dt", "weight_slots"):
                if k not in want:
                    continue
                try:
                    v = float(want[k])
                except (TypeError, ValueError):
                    continue
                lo, hi = snn_mod.QUALITY_RANGES[k]
                v = max(lo, min(hi, v))
                setattr(cfg, k, int(round(v)) if k in ("tau", "refractory",
                                                       "weight_slots")
                        else v)

            # --- 需要重建的：神经元数量 ---
            rebuilt = False
            ns = want.get("neuron_scale")
            if rebuild and ns is not None:
                try:
                    new_scale = clamp_snn_scale(ns)
                except (TypeError, ValueError):
                    new_scale = int(self.config.get("snn_scale") or 1)
                if new_scale != int(self.config.get("snn_scale") or 1):
                    self.config["snn_scale"] = new_scale
                    self._config_dirty = True
                    for other in self.lives.values():
                        other.snn = snn_mod.SpikingNetwork(
                            cfg=other.snn.cfg if other.snn else None,
                            scale=new_scale)
                    rebuilt = True
            payload = self.snn_payload(char_id)
            payload["rebuilt"] = rebuilt
            payload["applied_quality"] = q
            lf.memory.working.log(
                "SNN", "网络参数已调整（质量 %s%s）"
                % (q if q is not None else "手调",
                   "，已重建" if rebuilt else ""))
        self.save_config()
        return payload

    def geometry_payload(self, char_id: str = "") -> Dict[str, Any]:
        """小地图几何 —— 前端唯一的几何来源。"""
        lf = self.life_for(char_id)
        env = lf.env if lf else self._build_env_from_config()
        d = env.to_client()
        d["ok"] = True
        if lf is not None:
            d["position"] = [round(lf.pos[0], 3), round(lf.pos[1], 3)]
            # 每个地标到当前位置的距离，前端可直接用来做排序或高亮
            for lm in d["landmarks"]:
                lm["distance"] = round(
                    env.landmark_by_name(lm["name"]).distance_to(lf.pos), 3) \
                    if env.landmark_by_name(lm["name"]) else None
        return d

    def memory_payload(self, char_id: str = "") -> Dict[str, Any]:
        lf = self.life_for(char_id)
        if lf is None:
            return {"ok": False, "error": "没有可用的数字生命"}
        m = lf.memory
        return {
            "ok": True,
            "episodic": [e.to_dict() for e in m.recent_episodes(30)],
            "episodic_total": len(m.episodic),
            "unspoken": m.recent_unspoken(30),
            "event_log": m.working.recent_log(50),
            "dream": m.dream.to_dict() if m.dream.content else None,
            "is_asleep": m.is_asleep,
            "stats": m.stats(),
        }

    def set_environment(self, spec: Dict[str, Any], *,
                        description: str = "", char_id: str = ""
                        ) -> Dict[str, Any]:
        """换环境。**所有角色一起换**（她们同处一个世界）。"""
        env = geo.build_from_spec(spec, source=str(spec.get("source")
                                                   or "user"))
        with self.lock:
            for lf in self.lives.values():
                lf.set_environment(env)
            self.config["environment_spec"] = env.to_spec()
            if description:
                self.config["environment_description"] = description
            self._config_dirty = True
        self.save_config()
        out = env.to_client()
        out["summary"] = env_summary(env)
        return out

    # ==================================================================
    # 消息入口
    # ==================================================================
    def enqueue(self, text: str, *, char_id: str = "", name: str = "",
                sender: str = "用户") -> None:
        """把一个外部消息排队（下一个 tick 处理）。"""
        with self.lock:
            self._inbox.append({"text": text, "charId": char_id, "name": name,
                                "from": sender})
            if len(self._inbox) > 64:
                self._inbox = self._inbox[-64:]

    def set_broadcast(self, fn: Optional[Callable[[Dict[str, Any]],
                                                  Awaitable[None]]]) -> None:
        self._broadcast = fn

    # ==================================================================
    # 场景生成（真调 API）
    # ==================================================================
    def _env_result(self, env: "geo.Environment", *, fallback: bool,
                    reason: str = "") -> Dict[str, Any]:
        """生成结果的统一返回：spec + 摘要 + 为什么回落。"""
        out: Dict[str, Any] = {
            "ok": True,
            "spec": env.to_spec(),
            "summary": env_summary(env),
            "fallback": bool(fallback),
            "source": env.source,
            "needs_key": not self.llm_pool.enabled,
        }
        if reason:
            out["reason"] = reason
        return out

    def generate_environment(self, description: str,
                             timeout: float = 60.0) -> Dict[str, Any]:
        """用大模型把一句话变成结构化场景。

        第2代有这个功能（`EnvironmentGenerator` + `POST /api/generate_env`），
        第3代砍掉了；而前端第5代的同一个按钮退化成 `await sleep(600)`。
        这里是真的调 API，失败时明确回落并标注。

        没配密钥时会先看描述里有没有**内置场景的关键词**
        （"机房/服务器/机柜"、"教室/校舍/黑板"…），有就用那个 ——
        比一律回到默认场景更贴近用户想要的东西。
        """
        desc = str(description or "").strip()
        if not desc:
            return {"ok": False, "error": "环境描述为空"}
        if not self.llm_pool.enabled:
            env = geo.match_builtin(desc)
            if env is not None:
                env.description = desc[:400]
                env.source = "fallback"
                return self._env_result(
                    env, fallback=True,
                    reason="未配置 API Key，按关键词匹配了内置场景：" +
                           env.scene_name)
            # 一个关键词都没命中 → 用默认场景，并且**改名成用户给的描述**，
            # 因为此时名字与几何的不一致是已知的、也是最不坏的取舍。
            env = geo.default_environment()
            env.scene_name = "（未生成）" + desc[:24]
            env.description = desc[:400]
            env.source = "fallback"
            return self._env_result(
                env, fallback=True,
                reason="未配置 API Key，且描述里没有可识别的场景关键词，"
                       "已用默认布局")
        try:
            msgs = [{"role": "user",
                     "content": "生成这个场景的配置：\n" + desc}]
            client = self.llm_pool.get("env")
            spec = client.chat_json(msgs,
                                    schema_hint=geo.spec_schema_hint(),
                                    max_tokens=1200, temperature=0.4)
            env = geo.build_from_spec(spec, source="llm_generated")
            # 模型常把描述写得很短，用用户的原文兜底
            if len(env.description) < 12:
                env.description = desc[:400]
            return self._env_result(env, fallback=False)
        except Exception as e:                                   # noqa: BLE001
            log.warning("场景生成失败：%s", e)
            # ★ 大模型挂了也别直接扔默认场景：描述里的关键词往往还能
            #   指到一个像样的内置场景（"教室"→教室、"机房"→机房）。
            env = geo.match_builtin(desc)
            if env is not None:
                env.description = desc[:400]
                env.source = "fallback"
                return self._env_result(env, fallback=True,
                                        reason=str(e)[:160])
            env = geo.default_environment()
            env.description = desc[:200]
            env.source = "fallback"
            return self._env_result(env, fallback=True,
                                    reason=str(e)[:160])

    # ==================================================================
    def test_api_key(self, api_key: str = "", api_base: str = "",
                     model: str = "") -> Dict[str, Any]:
        """真的测一次连通性（第5代前端的 `#set-test` 是假的）。"""
        key = str(api_key or "").strip() or str(self.config.get("api_key") or "")
        if not key:
            return {"ok": False, "error": "未提供 API Key"}
        c = llm_mod.DeepSeekClient(
            api_key=key,
            base_url=str(api_base or self.config.get("api_base")
                         or llm_mod.DEFAULT_BASE_URL),
            model=str(model or self.config.get("chat_model")
                      or llm_mod.DEFAULT_MODEL))
        try:
            r = c.ping()
            models = [m.id for m in c.list_models(refresh=True)]
            return {"ok": True, "echo": r.text.strip()[:40],
                    "model": r.model, "elapsed": round(r.elapsed, 2),
                    "models": models}
        except Exception as e:                                   # noqa: BLE001
            return {"ok": False, "error": str(e)[:200]}

    def list_models(self) -> Dict[str, Any]:
        c = self.llm_pool.get("language")
        out = []
        for m in c.list_models(refresh=True):
            out.append({"id": m.id, "name": m.name or m.id,
                        "context": m.context_text,
                        "max_output": m.max_output_tokens,
                        "modalities": m.input_modalities,
                        "effort_levels": m.effort_levels,
                        "supports_image": m.supports_image})
        return {"ok": True, "models": out,
                "current": c.model, "enabled": c.enabled}

    # ==================================================================
    # 桥接（QQ / OneBot）
    # ==================================================================
    def apply_bridge_config(self, bridge: str = "", qq: Optional[Dict] = None
                            ) -> Dict[str, Any]:
        """切换接入方式（第2代 `apply_bridge_config`）。"""
        with self.lock:
            if bridge:
                self.bridge = bridge if bridge in ("internal", "qq") \
                    else "internal"
                self.config["bridge"] = self.bridge
            if isinstance(qq, dict):
                self.qq = {**(self.config.get("qq") or {}), **qq}
                self.config["qq"] = self.qq
            self._config_dirty = True
        self.save_config()
        return {"ok": True, "bridge": self.bridge, "qq": dict(self.qq)}

    def to_client_bridge(self) -> Dict[str, Any]:
        ob = self.onebot
        st = ob.status() if ob is not None else {
            "connected": False, "url": self.qq.get("ws_url", ""),
            "group_id": self.qq.get("group_id", ""),
            "has_token": bool(self.qq.get("access_token")),
            "queued": 0, "messages_received": 0, "messages_sent": 0,
            "errors": 0}
        return {"ok": True, "bridge": self.bridge, "qq": dict(self.qq),
                "status": st}


__all__ = [
    "Runtime", "WorldClock", "LLMPool", "atomic_write",
    "TICK_INTERVAL_SEC", "SAVE_INTERVAL_SEC", "BACKUP_INTERVAL_SEC",
    "CONFIG_SAVE_INTERVAL_SEC", "MAX_BACKUPS", "MAX_CHAT_HISTORY",
    "WEATHER_LIGHT", "WEATHER_TEMP", "WEATHER_LABEL", "WEATHER_CHOICES",
    "STATE_VERSION",
]
