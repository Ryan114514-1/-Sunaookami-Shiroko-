# -*- coding: utf-8 -*-
"""
Shiroko β —— 大模型接入层（DeepSeek 现行 API）

为什么不用 openai SDK
---------------------
1. 现行 DeepSeek API 有自己的字段（`thinking`、`reasoning_content`），
   用原生 HTTP 比在 SDK 上打补丁更可控；
2. 少一个重量级依赖 —— openai 会连带 httpx / pydantic / anyio 等，
   打包后体积差出几十 MB；
3. 只需要「发 POST、读 JSON、读 SSE」三件事，标准库足够。

实测确认的接口事实（2026-10，实测于本机）
----------------------------------------
    base_url             https://api.deepseek.com   ← 注意：不带 /v1
    GET  /models         返回可用模型与元数据
    POST /chat/completions
    model                deepseek-flash | deepseek-v4-pro
    thinking             {"type":"enabled"|"disabled", "reasoning_effort":"low"|"high"|"max"}
    reasoning_effort     顶层也接受（文档示例里就是这么写的）
    response_format      {"type":"json_object"} 启用 JSON 模式
    stream               SSE，以 "data: [DONE]" 结束
    思维链               choices[0].message.reasoning_content
    deepseek-flash       支持图像输入（modalities: text,image）
    deepseek-v4-pro      仅文本

注意：`frequency_penalty` / `presence_penalty` 已废弃，传了也没效果，本模块不发。
"""

from __future__ import annotations

import json
import logging
import re
import threading
import time
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, Iterable, Iterator, List, Optional

log = logging.getLogger("shiroko.llm")

DEFAULT_BASE_URL = "https://api.deepseek.com"
DEFAULT_MODEL = "deepseek-flash"
MODEL_FLASH = "deepseek-flash"
MODEL_PRO = "deepseek-v4-pro"
KNOWN_MODELS = (MODEL_FLASH, MODEL_PRO)

# 思考强度档位（文档：none 关闭；low/high/max 开启）
EFFORT_LEVELS = ("none", "low", "high", "max")


class LLMError(RuntimeError):
    """调用大模型失败。"""

    def __init__(self, message: str, status: int = 0, body: str = "") -> None:
        super().__init__(message)
        self.status = status
        self.body = body


@dataclass
class ChatResult:
    """一次对话调用的结果。"""

    text: str = ""
    reasoning: str = ""              # 思维链（思考模式下才有）
    model: str = ""
    finish_reason: str = ""
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0
    cached_tokens: int = 0
    elapsed: float = 0.0
    raw: Dict[str, Any] = field(default_factory=dict)

    @property
    def usage_line(self) -> str:
        if not self.total_tokens:
            return "无用量信息"
        return ("prompt %d（缓存命中 %d） · completion %d · 合计 %d"
                % (self.prompt_tokens, self.cached_tokens,
                   self.completion_tokens, self.total_tokens))


@dataclass
class ModelInfo:
    """模型元数据（来自 GET /models）。"""

    id: str = ""
    name: str = ""
    context_window: int = 0
    max_output_tokens: int = 0
    input_modalities: List[str] = field(default_factory=list)
    effort_levels: List[str] = field(default_factory=list)
    default_effort: str = ""

    @property
    def supports_image(self) -> bool:
        return "image" in self.input_modalities

    @property
    def context_text(self) -> str:
        if not self.context_window:
            return "未知"
        if self.context_window >= 1024 * 1024:
            return "%.0f 万" % (self.context_window / 10000)
        return "%d K" % (self.context_window // 1024)


class DeepSeekClient:
    """DeepSeek 对话补全客户端（线程安全，标准库实现）。

    用法：
        c = DeepSeekClient(api_key="sk-...")
        r = c.chat([{"role":"user","content":"在吗"}])
        print(r.text, r.reasoning)
    """

    def __init__(self, api_key: str = "", base_url: str = DEFAULT_BASE_URL,
                 model: str = DEFAULT_MODEL, timeout: float = 120.0,
                 max_retries: int = 2, proxy: str = "") -> None:
        self._lock = threading.RLock()
        self.api_key = (api_key or "").strip()
        self.base_url = (base_url or DEFAULT_BASE_URL).strip().rstrip("/")
        # 容错：用户常把 /v1 或 /chat/completions 粘进来
        for suffix in ("/chat/completions", "/v1"):
            if self.base_url.endswith(suffix):
                self.base_url = self.base_url[: -len(suffix)].rstrip("/")
        self.model = model or DEFAULT_MODEL
        self.timeout = timeout
        self.max_retries = max(0, int(max_retries))
        self.proxy = proxy or ""
        self._models: List[ModelInfo] = []
        self._models_at: float = 0.0

    # ------------------------------------------------------------------
    # 状态
    # ------------------------------------------------------------------
    @property
    def enabled(self) -> bool:
        return bool(self.api_key)

    def reconfigure(self, api_key: Optional[str] = None,
                    base_url: Optional[str] = None,
                    model: Optional[str] = None) -> bool:
        """改配置。返回 True 表示"实际发生了变化"。"""
        with self._lock:
            changed = False
            if api_key is not None and api_key.strip() != self.api_key:
                self.api_key = api_key.strip()
                changed = True
            if base_url is not None:
                b = base_url.strip().rstrip("/")
                for suffix in ("/chat/completions", "/v1"):
                    if b.endswith(suffix):
                        b = b[: -len(suffix)].rstrip("/")
                if b and b != self.base_url:
                    self.base_url = b
                    changed = True
            if model is not None and model.strip() and model.strip() != self.model:
                self.model = model.strip()
                changed = True
            if changed:
                self._models, self._models_at = [], 0.0
                log.info("大模型配置已更新：model=%s base=%s key=%s",
                         self.model, self.base_url,
                         "已设置" if self.api_key else "未设置")
            return changed

    # ------------------------------------------------------------------
    # 底层 HTTP
    # ------------------------------------------------------------------
    def _request(self, path: str, payload: Optional[dict] = None,
                 method: str = "", stream: bool = False,
                 timeout: Optional[float] = None):
        url = self.base_url + path
        data = None
        if payload is not None:
            data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        req = urllib.request.Request(
            url, data=data, method=method or ("POST" if data else "GET"))
        req.add_header("Content-Type", "application/json")
        req.add_header("Accept", "text/event-stream" if stream
                       else "application/json")
        req.add_header("User-Agent", "ShirokoBeta/1.0")
        if self.api_key:
            req.add_header("Authorization", "Bearer " + self.api_key)

        handlers: List[Any] = []
        if self.proxy:
            handlers.append(urllib.request.ProxyHandler(
                {"http": self.proxy, "https": self.proxy}))
        opener = urllib.request.build_opener(*handlers) if handlers \
            else urllib.request.build_opener()

        last: Optional[Exception] = None
        for attempt in range(self.max_retries + 1):
            try:
                return opener.open(req, timeout=timeout or self.timeout)
            except urllib.error.HTTPError as e:
                body = ""
                try:
                    body = e.read().decode("utf-8", "replace")
                except Exception:                            # noqa: BLE001
                    pass
                # 4xx（除 429）不重试 —— 重试也不会变好
                if 400 <= e.code < 500 and e.code != 429:
                    raise LLMError(self._explain_http(e.code, body),
                                   status=e.code, body=body) from None
                last = LLMError(self._explain_http(e.code, body),
                                status=e.code, body=body)
            except urllib.error.URLError as e:
                last = LLMError("网络不可达：%s" % (e.reason,))
            except Exception as e:                           # noqa: BLE001
                last = LLMError("%s: %s" % (type(e).__name__, e))
            if attempt < self.max_retries:
                delay = 0.8 * (2 ** attempt)
                log.warning("调用失败（第 %d 次），%.1fs 后重试：%s",
                            attempt + 1, delay, last)
                time.sleep(delay)
        raise last or LLMError("调用失败")

    @staticmethod
    def _explain_http(code: int, body: str) -> str:
        """把 HTTP 错误翻译成人能看懂的话。"""
        hint = {
            400: "请求格式有误",
            401: "API Key 无效或已失效 —— 请到 platform.deepseek.com 重新申请",
            402: "账户余额不足",
            403: "无权访问该模型",
            404: "接口路径不存在 —— 检查 base_url 是否是 https://api.deepseek.com",
            422: "参数不合法",
            429: "请求过于频繁，被限速",
            500: "服务端内部错误",
            503: "服务端过载，请稍后重试",
        }.get(code, "请求失败")
        detail = ""
        try:
            d = json.loads(body)
            detail = (d.get("error") or {}).get("message") or d.get("message") or ""
        except Exception:                                    # noqa: BLE001
            detail = (body or "")[:200]
        return "HTTP %d · %s%s" % (code, hint,
                                   ("　→ " + detail) if detail else "")

    # ------------------------------------------------------------------
    # 模型列表
    # ------------------------------------------------------------------
    def list_models(self, refresh: bool = False, ttl: float = 600.0
                    ) -> List[ModelInfo]:
        """取可用模型。失败时回落到已知模型常量，不抛异常。"""
        with self._lock:
            fresh = (time.time() - self._models_at) < ttl
            if self._models and fresh and not refresh:
                return list(self._models)
        if not self.enabled:
            return [ModelInfo(id=m) for m in KNOWN_MODELS]
        try:
            with self._request("/models", timeout=20.0) as r:
                d = json.loads(r.read().decode("utf-8", "replace"))
            out: List[ModelInfo] = []
            for m in d.get("data") or []:
                eff = m.get("effort") or {}
                out.append(ModelInfo(
                    id=str(m.get("id") or ""),
                    name=str(m.get("name") or m.get("id") or ""),
                    context_window=int(m.get("context_window") or 0),
                    max_output_tokens=int(m.get("max_output_tokens") or 0),
                    input_modalities=list(m.get("input_modalities") or []),
                    effort_levels=list(eff.get("supported_levels") or []),
                    default_effort=str(eff.get("default_level") or ""),
                ))
            out = [m for m in out if m.id]
            if out:
                with self._lock:
                    self._models, self._models_at = out, time.time()
                log.info("模型列表已获取：%s",
                         ", ".join("%s(%s)" % (m.id, m.context_text) for m in out))
                return list(out)
        except Exception as e:                               # noqa: BLE001
            log.warning("获取模型列表失败，回落内置列表：%s", e)
        return [ModelInfo(id=m) for m in KNOWN_MODELS]

    # ------------------------------------------------------------------
    # 对话
    # ------------------------------------------------------------------
    def build_payload(self, messages: List[Dict[str, Any]],
                      model: str = "", temperature: float = 1.0,
                      max_tokens: int = 0, json_mode: bool = False,
                      thinking: str = "", effort: str = "",
                      stream: bool = False,
                      stop: Optional[Iterable[str]] = None) -> Dict[str, Any]:
        """按现行 API 组装请求体。

        thinking / effort 的语义（实测确认）：
            都不传          → 服务端默认 enabled，思维链会占用 token 预算
            effort="none"   → 关闭思考，正文立即可得、延迟最低
            effort="low/high/max" → 开启思考并指定强度

        所以**要立刻拿正文的场合（JSON、短回复、自检）一定传 effort="none"**，
        否则 max_tokens 会被思维链吃光，正文变成空字符串、finish_reason=length。
        """
        p: Dict[str, Any] = {
            "model": model or self.model,
            "messages": messages,
            "stream": bool(stream),
        }
        if temperature is not None:
            p["temperature"] = max(0.0, min(2.0, float(temperature)))
        if max_tokens:
            p["max_tokens"] = int(max_tokens)
        if json_mode:
            p["response_format"] = {"type": "json_object"}
        # thinking：type 与 reasoning_effort 按语义发
        if thinking == "disabled" or effort == "none":
            p["thinking"] = {"type": "disabled"}
        elif thinking == "enabled" or effort in ("low", "high", "max"):
            p["thinking"] = {"type": "enabled"}
            if effort in ("low", "high", "max"):
                p["reasoning_effort"] = effort
        if stop:
            s = [x for x in stop if x]
            if s:
                p["stop"] = s
        return p

    def chat(self, messages: List[Dict[str, Any]], **kw) -> ChatResult:
        """一次性对话（非流式）。抛 LLMError 表示失败。"""
        if not self.enabled:
            raise LLMError("未配置 API Key")
        payload = self.build_payload(messages, stream=False, **kw)
        t0 = time.time()
        with self._request("/chat/completions", payload) as r:
            body = r.read().decode("utf-8", "replace")
        try:
            d = json.loads(body)
        except ValueError as e:
            raise LLMError("返回不是合法 JSON：%s" % body[:200]) from e
        ch = (d.get("choices") or [{}])[0]
        msg = ch.get("message") or {}
        u = d.get("usage") or {}
        det = u.get("prompt_tokens_details") or {}
        return ChatResult(
            text=msg.get("content") or "",
            reasoning=msg.get("reasoning_content") or "",
            model=str(d.get("model") or payload["model"]),
            finish_reason=str(ch.get("finish_reason") or ""),
            prompt_tokens=int(u.get("prompt_tokens") or 0),
            completion_tokens=int(u.get("completion_tokens") or 0),
            total_tokens=int(u.get("total_tokens") or 0),
            cached_tokens=int(det.get("cached_tokens")
                              or u.get("prompt_cache_hit_tokens") or 0),
            elapsed=time.time() - t0,
            raw=d,
        )

    def chat_stream(self, messages: List[Dict[str, Any]],
                    on_delta: Optional[Callable[[str, str], None]] = None,
                    **kw) -> ChatResult:
        """流式对话。

        每收到一段就回调 on_delta(kind, text)：
            kind='reasoning' 思维链；kind='text' 正文
        返回完整的 ChatResult（含思维链与用量）。
        """
        if not self.enabled:
            raise LLMError("未配置 API Key")
        payload = self.build_payload(messages, stream=True, **kw)
        t0 = time.time()
        text_parts: List[str] = []
        reason_parts: List[str] = []
        model = str(payload["model"])
        finish = ""
        usage: Dict[str, Any] = {}

        with self._request("/chat/completions", payload, stream=True,
                           timeout=self.timeout) as r:
            for raw in r:
                line = raw.decode("utf-8", "replace").strip()
                if not line or not line.startswith("data:"):
                    continue
                payload_s = line[5:].strip()
                if payload_s == "[DONE]":
                    break
                try:
                    d = json.loads(payload_s)
                except ValueError:
                    continue
                if d.get("model"):
                    model = str(d["model"])
                if d.get("usage"):
                    usage = d["usage"] or {}
                for ch in d.get("choices") or []:
                    if ch.get("finish_reason"):
                        finish = str(ch["finish_reason"])
                    delta = ch.get("delta") or {}
                    rc = delta.get("reasoning_content")
                    if rc:
                        reason_parts.append(rc)
                        if on_delta:
                            on_delta("reasoning", rc)
                    c = delta.get("content")
                    if c:
                        text_parts.append(c)
                        if on_delta:
                            on_delta("text", c)

        det = usage.get("prompt_tokens_details") or {}
        return ChatResult(
            text="".join(text_parts), reasoning="".join(reason_parts),
            model=model, finish_reason=finish,
            prompt_tokens=int(usage.get("prompt_tokens") or 0),
            completion_tokens=int(usage.get("completion_tokens") or 0),
            total_tokens=int(usage.get("total_tokens") or 0),
            cached_tokens=int(det.get("cached_tokens")
                              or usage.get("prompt_cache_hit_tokens") or 0),
            elapsed=time.time() - t0, raw={"usage": usage},
        )

    # ------------------------------------------------------------------
    # 结构化输出（场景生成等要用）
    # ------------------------------------------------------------------
    @staticmethod
    def _strip_code_fence(txt: str) -> str:
        t = (txt or "").strip()
        if t.startswith("```"):
            t = t.split("\n", 1)[-1] if "\n" in t else t
            if t.rstrip().endswith("```"):
                t = t.rstrip()[:-3]
            t = t.strip()
            if t.lower().startswith("json"):
                t = t[4:].strip()
        return t

    @staticmethod
    def _has_toplevel_pair(s: str) -> bool:
        """文本里有没有**顶层键值对**（depth 1 处在字符串外见到 `:`）。

        ★ 为什么需要这个：补括号的修复会把 `"{"` 补成 `"{}"` ——
        凭空造出一个空对象。调用方拿到 `{}` 会当作合法结果，
        然后生成一个空场景（实测踩到：`_repair_json("{")` 返回 `"{}"`）。
        没有任何键值对就不该"修"，直接返回 None 让调用方回落。
        """
        depth = 0
        in_str = False
        esc = False
        for ch in s:
            if esc:
                esc = False
                continue
            if ch == "\\" and in_str:
                esc = True
                continue
            if ch == '"':
                in_str = not in_str
                continue
            if in_str:
                continue
            if ch in "{[":
                depth += 1
            elif ch in "}]":
                depth -= 1
            elif ch == ":" and depth == 1:
                return True
        return False

    @staticmethod
    def _repair_json(txt: str) -> Optional[str]:
        """尽量把半截/带散文的 JSON 修成可解析的。

        模型偶尔会：在 JSON 前后加一句解释、留尾逗号、
        或者被 `max_tokens` 截断（最后一项写了一半）。
        这三种都实测遇到过 —— `test_llm.py` 有一次就是被截断。

        括号配平**必须区分"在字符串里"**：值里出现 `{` `}` `"` 都很常见，
        直接数字符会把 `{"a": "}"}` 这种判错。
        """
        s = (txt or "").strip()
        if not s:
            return None
        # 1) 从第一个 { 到最后一个 } 之间截取（去掉前后的散文）
        i, j = s.find("{"), s.rfind("}")
        if i >= 0 and j > i:
            cand = s[i:j + 1]
            if cand != s:
                try:
                    json.loads(cand)
                    return cand
                except ValueError:
                    s = cand
        # 2) 去掉尾逗号
        t = re.sub(r",(\s*[}\]])", r"\1", s)
        try:
            json.loads(t)
            return t
        except ValueError:
            pass
        # 3) 补上被截断的括号。
        #    ★ 这一步才需要"至少有一个顶层键值对"的检查 ——
        #      否则 `"{"` 会被补成 `"{}"`，凭空造出一个空对象，
        #      调用方会把它当成合法结果去生成空场景。
        #      （第 1、2 步不加这个检查：`{}` 是模型显式给出的合法输出。）
        if not DeepSeekClient._has_toplevel_pair(t):
            return None
        stack: List[str] = []
        in_str = False
        esc = False
        for ch in t:
            if esc:
                esc = False
                continue
            if ch == "\\" and in_str:
                esc = True
                continue
            if ch == '"':
                in_str = not in_str
                continue
            if in_str:
                continue
            if ch in "{[":
                stack.append("}" if ch == "{" else "]")
            elif ch in "}]":
                if stack:
                    stack.pop()
        if not stack:
            return None
        fixed = t
        if in_str:
            fixed += '"'            # 字符串写到一半
        fixed = re.sub(r",\s*$", "", fixed.rstrip())
        fixed += "".join(reversed(stack))
        try:
            json.loads(fixed)
            return fixed
        except ValueError:
            return None

    def chat_json(self, messages: List[Dict[str, Any]],
                  schema_hint: str = "", **kw) -> Dict[str, Any]:
        """要模型输出 JSON 并解析。

        模型有时会包 ```json 代码块，这里会剥掉。
        解析不出来时会尝试**修复**（抠出 JSON / 去尾逗号 / 补截断的括号），
        仍然不行才抛 LLMError（调用方负责回落）。
        """
        msgs = list(messages)
        if schema_hint:
            msgs = [{"role": "system",
                     "content": "只输出 JSON，不要任何解释或代码块标记。"
                                "严格符合以下结构：\n" + schema_hint}] + msgs
        kw.setdefault("json_mode", True)
        # 关键：JSON 模式必须关闭思考模式。
        # 实测过 —— 思考默认 enabled，思维链会先吃掉整个 token 预算，
        # 于是正文（也就是我们要的 JSON）被截断成半截，解析必然失败。
        kw["thinking"] = "disabled"
        kw["effort"] = "none"
        r = self.chat(msgs, **kw)
        raw = r.text or ""
        txt = self._strip_code_fence(raw)

        d: Any = None
        try:
            d = json.loads(txt)
        except ValueError:
            fixed = self._repair_json(txt)
            if fixed is not None:
                try:
                    d = json.loads(fixed)
                    log.info("JSON 被修复后解析成功（原长 %d，修后 %d）",
                             len(txt), len(fixed))
                except ValueError:
                    d = None
        if d is None:
            raise LLMError("模型输出不是合法 JSON：%s" % raw[:300])
        if not isinstance(d, dict):
            raise LLMError("模型输出的 JSON 不是对象：%s" % raw[:200])
        return d

    # ------------------------------------------------------------------
    def ping(self) -> ChatResult:
        """连通性自检：一次最小调用，用来在 UI 上点「测试连接」。"""
        return self.chat(
            [{"role": "user", "content": "回复两个字：收到"}],
            max_tokens=16, temperature=0.0, effort="none")


__all__ = [
    "DeepSeekClient", "ChatResult", "ModelInfo", "LLMError",
    "DEFAULT_BASE_URL", "DEFAULT_MODEL", "MODEL_FLASH", "MODEL_PRO",
    "KNOWN_MODELS", "EFFORT_LEVELS",
]
